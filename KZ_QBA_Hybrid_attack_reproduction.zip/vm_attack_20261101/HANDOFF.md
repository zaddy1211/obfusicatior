# Reproduce the hybrid-build VM extraction

This package contains the exact attack scripts and baseline artifacts used in the ten-minute attempt. No obfuscator source was used. The added `run_attack.js` only orchestrates those existing scripts and avoids PowerShell output-encoding differences.

## Prerequisites and execution

Install Node.js and the stock Luau CLI. No npm packages are required. Extract the ZIP to a writable directory, open that directory in a terminal, and run:

```powershell
node .\run_attack.js
```

If `luau` is not on PATH:

```powershell
node .\run_attack.js 'C:\path\to\luau.exe'
```

The runner rebuilds the extractor, captures its JSONL output as UTF-8, generates recovered Luau, checks payload structure, and checks that the recovered module loads. It does not execute the application's entry point.

## Exact scripts

- `build.js`: reads the supplied `input.luau`; copies the public VM runtime and payload into an instrumented extractor. It patches the closure factory to return decoded metadata rather than a callable function and substitutes the extraction traversal for the original root return.
- `extract.luau`: extraction hook. Recursively walks child closures, decodes constants and instructions, and emits JSONL. It uses the decoder and key-derivation routines shipped in the input itself.
- `extractor.luau`: generated, standalone extractor used for the attack. Run directly with `luau extractor.luau`; its standard output is the recovered JSONL.
- `render.js` and `runtime_helpers.luau`: translate the decoded records into explicit Luau operations and control-flow dispatchers.
- `verify.js`: validates prototype coverage, instruction boundaries, branch targets, child references, and generic-for latch sentinels. Also generates an isolated original-VM reference module.
- `differential_test.luau`: selected behavioral comparisons. The earlier attempt timed out; `differential_result.json` preserves that outcome. Do not treat this as a passing behavioral test suite.

## Expected baseline

- Input SHA-256: `8ada8aea25f6c99632813c3f41a26cbe6c07433efd110d62097b8224fd9be19e`.
- Payload: 505,488 bytes including its 32-byte header.
- Prototypes: 1,449.
- Instruction records: 47,090, including 285 generic-for latch sentinels.
- Constant entries: 15,373.
- Structural errors: zero.
- Generated recovered module: compiles and loads. Complete semantic equivalence remains unverified.

## Use against architectural changes

The attack is specific to the submitted hybrid build. `build.js` identifies generated function names, wrapper text, and metadata layout by exact strings; `extract.luau` references that build's decoder identifiers, opcode mapping, and operand formats. A renamed or reformatted build can therefore break the script without preventing the underlying attack.

For a meaningful retest, distinguish an adaptation failure from a security improvement. Adapt changed names, markers, layouts, and instruction semantics before concluding that recovery is blocked. The architectural question is whether an attacker can still reuse the shipped decoder, replace the closure-factory execution path with metadata extraction, and recursively recover every dormant child function without running the application.

Keep the supplied baseline and its outputs for comparison before replacing `input.luau`. The runner overwrites generated artifacts in its directory. See `REPORT.md` for target-function offsets, scope, evidence, and limitations.
