// Reproduce the original artifact-specific attack with Node.js and stock Luau.
// Usage: node run_attack.js [path-to-luau-executable]
const fs = require('fs');
const path = require('path');
const {spawnSync} = require('child_process');
const luau = process.argv[2] || process.env.LUAU_BIN || 'luau';
function run(exe,args,output) {
  const result = spawnSync(exe,args,{cwd:__dirname,encoding:'utf8',timeout:120000,maxBuffer:64*1024*1024});
  if(result.error || result.status!==0) throw new Error(`${path.basename(exe)} ${args.join(' ')} failed: ${result.error?.message || result.stderr || result.stdout}`);
  if(output) fs.writeFileSync(path.join(__dirname,output),result.stdout,'utf8');
  else if(result.stdout) process.stdout.write(result.stdout);
  if(result.stderr) process.stderr.write(result.stderr);
}
run(process.execPath,['build.js']);
run(luau,['extractor.luau'],'vm_dump.jsonl');
run(process.execPath,['render.js']);
run(process.execPath,['verify.js'],'verification.log');
const result=JSON.parse(fs.readFileSync(path.join(__dirname,'verification.json'),'utf8'));
if(result.errors.length) throw new Error(JSON.stringify(result.errors));
run(luau,['recovered_vm.luau']);
console.log(JSON.stringify({prototypes:result.prototypes,instructions:result.instructions,constants:result.constants,structuralErrors:result.errors.length,moduleLoads:true},null,2));
console.log('Behavioral equivalence is NOT checked by this runner. differential_test.luau is separate; its prior attempt timed out.');
