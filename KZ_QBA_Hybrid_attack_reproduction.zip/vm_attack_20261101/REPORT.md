# Ten-minute black-box VM analysis

Input: `KZ_QBA_Hybrid.luau`, SHA-256 `8ada8aea25f6c99632813c3f41a26cbe6c07433efd110d62097b8224fd9be19e`.

Only the supplied file, Node.js, PowerShell, and a stock Luau CLI were used. No obfuscator source, existing workspace reconstructions, or remote application code was consulted. No Roblox application entry point was executed. Work began at 14:52:52 UTC on November 1, 2026, with a ten-minute limit.

## Result

Recovered 1,449 function prototypes, 47,090 instruction records, and 15,373 constant-pool entries from inside the VM. Of the instruction records, 285 are generic-loop latch sentinels. Recovered string operands and constants are plaintext. The reconstructed program no longer needs encrypted bytecode, key derivation, opcode masks, or the original opcode interpreter.

`recovered_vm.luau` is a mechanically devirtualized Luau module. Each recovered function has explicit operations and control-flow addresses. It retains register storage and a control-flow dispatcher; it is not an idiomatic reconstruction of the original source or original local names. Loading the module defines functions without starting the application. Its `create(environment)` method creates the recovered entry point, which still expects the original hybrid program's native-helper argument when invoked.

`readable_vm_ir.luau` is a commented, searchable listing of every decoded operation with inlined constants. `prototype_index.json` indexes each function and its strings. `recovered_examples.luau` contains a few manually simplified functions recovered from VM code.

## Substantial VM targets recovered

These are not the plaintext native helpers:

| VM prototype offset | Instructions | Role / evidence |
| --- | ---: | --- |
| 105577 | 460 | Advanced solver `compute`, assigned to the module's `compute` member at instruction 111320 |
| 112539 | 896 | SmartFit `compute`, assigned at instruction 120210 |
| 95714 | 749 | Solver context construction, passed into Advanced `compute` as its first captured dependency |
| 92424 | 410 | Defender/trajectory margin calculations, including gravity, reaction, dive reach, and safety margin |
| 88866 | 357 | Candidate scoring, including flight time, defender coverage, height, angle, and lead |

## Attack route

The public artifact supplies its own 32-bit mixing, domain-separated key derivation, root-header decoding, prototype decryption, constant decoding, opcode mapping, and operand decoding. Rather than guessing keys, the extractor reuses those shipped decoder routines and replaces the closure factory's execution path with a metadata return. It then walks every child closure and decodes instructions according to the shipped handlers. This avoids needing application inputs or a Roblox environment to expose dormant VM functions.

The recovered payload seed is `3808712860`; the root prototype is at offset `500725`. Both values are independently recoverable from the public artifact's runtime logic. The parser preserves its original initial integrity check; no secret or source-only material is needed to obtain them.

The runtime cache/integrity machinery does not prevent editing a local copy of the artifact to emit decrypted metadata. This particular artifact selects runtime mode `1`, while many additional integrity checks are conditional on mode `2`. That observation is specific to this file.

## Verification and limits

`verification.json` records zero structural errors: prototype ranges cover every payload byte from offset 32 through 505488 without gaps or overlap; every instruction stream ends at its prototype boundary; every branch destination is an instruction boundary; all 1,448 child-closure references resolve; and all 285 otherwise-invalid opcode records correspond exactly to generic-for latch addresses.

The generated Luau module compiles and loads with the stock Luau CLI. `differential_test.luau` compares selected functions against the original VM without invoking the application; the comparison attempt timed out without producing a pass/fail result (see differential_result.json). Semantic equivalence is therefore unverified. These checks do not establish complete semantic equivalence or Roblox execution compatibility. Function identity, environment behavior, executor-specific globals, and external native-helper integration need broader validation. Original source formatting, comments, and local variable names were not recovered.

## Reproduction

From the parent workspace, run:

```powershell
node .\vm_attack_20261101\build.js
luau .\vm_attack_20261101\extractor.luau > .\vm_attack_20261101\vm_dump.jsonl
node .\vm_attack_20261101\render.js
node .\vm_attack_20261101\verify.js
luau .\vm_attack_20261101\differential_test.luau
```

The build script embeds only the supplied public artifact and the extraction hook. `reference_vm.luau` retains the public VM as the behavioral comparison baseline and returns its closure factory rather than executing its entry point.
