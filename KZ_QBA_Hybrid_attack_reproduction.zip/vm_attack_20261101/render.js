const fs=require('fs');
const rows=fs.readFileSync(__dirname+'/vm_dump.jsonl','utf8').trim().split(/\r?\n/).map(JSON.parse);
const header=rows[0], protos=new Map(rows.filter(x=>x.record==='proto').map(x=>[x.offset,{...x,code:[]} ]));
rows.filter(x=>x.record==='instruction').forEach(x=>protos.get(x.proto).code.push({...x,args:Object.values(x.args)}));
const q=s=>JSON.stringify(s).replace(/\\u([0-9a-f]{4})/g,(_,h)=>'\\'+String(parseInt(h,16)).padStart(3,'0'));
function lit(v,t){if(t==='nil'||v===undefined||v===null)return'nil';if(t==='vector')return 'vector.create('+v.replace(/[()]/g,'')+')'; if(typeof v==='string')return q(v);if(typeof v==='number'||typeof v==='boolean')return String(v);return '{'+Object.entries(v).map(([k,x])=>'['+q(k)+']='+lit(x)).join(', ')+'}';}
const bin=['+','-','*','/','%','^','and','or','//'], unary=['not ','-','#'];
function expr(x,p){if(x.reg!==undefined)return`R[${x.reg}]`;if(x.constant!==undefined)return lit(p.constants[x.constant].value,p.constants[x.constant].type);if(x.upvalue!==undefined)return`U[${x.upvalue+1}].value`;if(x.nilvalue)return'nil';if(x.boolean!==undefined)return String(x.boolean);if(x.number!==undefined)return lit(x.number);throw Error(JSON.stringify(x));}
function line(i,p){let a=i.args, A=a[0]?.reg, e=x=>expr(x,p), set=v=>`S(${A}, ${v})`, t=i.next, end=false, s='';
switch(i.op){
case'NOP':s='-- no operation';break;case'INVALID':s='error("unreachable generic-for latch")';end=true;break;
case'LOAD':s=set(e(a[1]));break;
case'GETGLOBAL':s=set(`getfenv(F)[${q(a[1])}]`);break;
case'SETGLOBAL':s=`getfenv(F)[${q(a[1])}] = R[${A}]`;break;
case'GETTABLE':s=set(`${e(a[1])}[${e(a[2])}]`);break;
case'SETTABLE':s=`${e(a[1])}[${e(a[2])}] = R[${A}]`;break;
case'BINARY':s=set(`(${e(a[1])} ${bin[a[3]]} ${e(a[2])})`);break;
case'UNARY':s=set(`(${unary[a[2]]}${e(a[1])})`);break;
case'GETUPVAL':s=set(e(a[1]));break;
case'SETUPVAL':s=`putcell(U[${a[1].upvalue+1}], R[${A}])`;break;
case'NEWTABLE':s=set(`table.create(${a[1]})`);break;
case'CLONETABLE':s=set(`table.clone(K[${p.offset}][${a[1].constant}])`);break;
case'CLOSE':s=`for j=${A},${p.slots} do if O[j] then O[j].r=nil; O[j]=nil end end`;break;
case'CONCAT':s=`local v=R[${a[2]}]; for j=${a[2]-1},${a[1]},-1 do v=R[j]..v end; ${set('v')}`;break;
case'VARARG':s=`local n=${a[1]}; if n<0 then n=V.n; top=${A}+n end; for j=1,n do S(${A}+j-1,V[j]) end`;break;
case'RETURN':s=`local n=${a[1]}; if n<0 then n=top-${A} end; local out={n=n}; for j=1,n do out[j]=R[${A}+j-1] end; return "return",out`;end=true;break;
case'CALL':s=`local n=${a[1]}; if n<0 then n=top-${A}-1 end; local args={}; for j=1,n do args[j]=R[${A}+j] end; local out=call(R[${A}],args,n,E,F); local count=${a[2]}; if count<0 then count=out.n; top=${A}+count else top=${p.slots} end; for j=1,count do S(${A}+j-1,out[j]) end`;break;
case'NAMECALL':s=`local receiver=${e(a[1])}; S(${A+1},receiver); ${set(`function(receiver,...) return receiver[${q(a[2])}](receiver,...) end`)}`;break;
case'SETLIST':s=`local n=${a[2]}; if n<0 then n=top-${a[1]} end; for j=1,n do R[${A}][${a[3]}-1+j]=R[${a[1]}+j-1] end`;break;
case'CLOSURE': {let caps=Object.values(a[3]).map(c=>`{${c.kind},${c.index}}`).join(',');s=set(`closure(${a[1]}, {${caps}}, ${a[2]}, ${p.pid}, U,getfenv(F),R,O)`);break;}
case'JUMP':s=`pc=${a[0]}`;end=true;break;
case'TEST_JUMP':s=`if ${a[1]?'':'not '}(${e(a[0])}) then pc=${a[2]} else pc=${t} end`;end=true;break;
case'COMPARE_JUMP':{let x=e(a[0]),y=e(a[1]);let cond=[`${x}==${y}`,`${x}<=${y}`,`${x}<${y}`,`${x}~=${y}`,`not (${x}<=${y})`,`not (${x}<${y})`,`${x}>${y}`,`${x}>=${y}`][a[2]];s=`if ${cond} then pc=${a[3]} else pc=${t} end`;end=true;break;}
case'FORPREP':s=`local init=tonumber(R[${A+2}]); local limit=tonumber(R[${A}]); local step=tonumber(R[${A+1}]); assert(init and limit and step,"invalid numeric for"); S(${A},limit); S(${A+1},step); S(${A+2},init); if (step>0 and init<=limit) or (step<=0 and limit<=init) then pc=${t} else pc=${a[1]} end`;end=true;break;
case'FORLOOP':s=`local v=R[${A+2}]+R[${A+1}]; S(${A+2},v); if (R[${A+1}]>0 and v<=R[${A}]) or (R[${A+1}]<=0 and R[${A}]<=v) then pc=${a[1]} else pc=${t} end`;end=true;break;
case'GENERIC_FOR':s=`local signal,escaped; for v1,v2 in R[${A}],R[${A+1}],R[${A+2}] do top=${p.slots}; S(${A+3},v1); ${a[2]>1?`S(${A+4},v2);`:''} S(${A+2},v1); local kind,value=run(${a[3]},${a[3]},${a[1]}); if kind~="latch" then signal,escaped=kind,value; break end end; top=${p.slots}; if signal=="return" then return signal,escaped elseif signal=="escape" then pc=escaped else pc=${a[4]} end`;end=true;break;
default:throw Error(i.op);
}return {s,end};}
let ir=[],out=[fs.readFileSync(__dirname+'/runtime_helpers.luau','utf8')];
for(const p of protos.values()){
ir.push(`\n-- FUNCTION ${p.offset}: params=${p.params}, upvalues=${p.upvalues}, slots=${p.slots}`);
out.push(`\nK[${p.offset}]={${Object.entries(p.constants).filter(([k,v])=>v.type==='table').map(([k,v])=>`[${k}]=${lit(v.value)}`).join(',')}}`);
out.push(`P[${p.offset}]=function(U,E)\nlocal F\nF=function(...)\nlocal R,O={},{}\nlocal args=table.pack(...)\nlocal top=${p.slots}\nlocal V={n=math.max(0,args.n-${p.params})}\nfor j=1,${p.params} do R[j-1]=args[j] end\nfor j=1,V.n do V[j]=args[${p.params}+j] end\nlocal function S(i,v) R[i]=v; if O[i] then O[i].value=v end end\nlocal run\nrun=function(pc,first,latch)\nwhile true do\nif latch then if pc==latch then return "latch" end; if pc<first or pc>latch then return "escape",pc end end`);
// Keep every instruction address explicit for exact branch and loop boundaries.
p.code.forEach((i,n)=>{let x=line(i,p);ir.push(`-- L${i.pc}  ${x.s}`);out.push(`${n?'elseif':'if'} pc==${i.pc} then -- ${i.op}\n${x.s}${x.end?'':`; pc=${i.next}`}`);});
out.push(`else error("bad recovered program counter "..pc) end\nend\nend\nlocal kind,values=run(${p.start})\nassert(kind=="return")\nreturn table.unpack(values,1,values.n)\nend\nsetfenv(F,E)\nreturn F\nend`);
}
out.push(`return {root=${header.root}, factories=P, create=function(environment) return P[${header.root}]({},environment or getfenv()) end}`);
fs.writeFileSync(__dirname+'/recovered_vm.luau',out.join('\n'));
fs.writeFileSync(__dirname+'/readable_vm_ir.luau',ir.join('\n'));
fs.writeFileSync(__dirname+'/prototype_index.json',JSON.stringify([...protos.values()].map(p=>({offset:p.offset,params:p.params,upvalues:p.upvalues,instructions:p.code.length,strings:Object.values(p.constants).filter(c=>c.type==='string').map(c=>c.value)})),null,2));
console.log('generated',protos.size,'functions');

