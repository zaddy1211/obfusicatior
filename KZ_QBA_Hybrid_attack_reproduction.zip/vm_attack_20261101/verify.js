const fs=require('fs'),crypto=require('crypto');
const rows=fs.readFileSync(__dirname+'/vm_dump.jsonl','utf8').trim().split(/\r?\n/).map(JSON.parse);
const h=rows[0],ps=rows.filter(r=>r.record==='proto'),ins=rows.filter(r=>r.record==='instruction');
let errors=[],latches=new Set(),count={};
for(let i of ins)if(i.op==='GENERIC_FOR')latches.add(i.args['2']);
for(let p of ps){let code=ins.filter(i=>i.proto===p.offset),starts=new Set(code.map(i=>i.pc)),pos=p.start;
for(let i of code){if(i.pc!==pos)errors.push(`gap ${p.offset}:${pos}`);pos=i.next;count[i.op]=(count[i.op]||0)+1;
let a=i.args,targets=[];if(['JUMP'].includes(i.op))targets=[a['1']];if(['FORPREP','FORLOOP'].includes(i.op))targets=[a['2']];if(i.op==='COMPARE_JUMP')targets=[a['4']];if(i.op==='TEST_JUMP')targets=[a['3']];if(i.op==='GENERIC_FOR')targets=[a['2'],a['4'],a['5']];for(let t of targets)if(!starts.has(t))errors.push(`bad target ${i.pc}->${t}`);
if(i.op==='INVALID'&&!latches.has(i.pc))errors.push(`unexpected invalid ${i.pc}`);
if(i.op==='CLOSURE'&&!ps.some(p=>p.offset===a['2']))errors.push(`missing child ${i.pc}`);
}if(pos!==p.finish)errors.push(`bad end ${p.offset}`);}
const sorted=ps.slice().sort((a,b)=>a.offset-b.offset);let pos=32;for(let p of sorted){if(p.offset!==pos)errors.push(`payload gap/overlap at ${pos} to ${p.offset}`);pos=p.finish;}
let constants=ps.reduce((n,p)=>n+Object.keys(p.constants).length,0);
const report={sha256:crypto.createHash('sha256').update(fs.readFileSync(__dirname+'/input.luau')).digest('hex'),payloadBytes:h.length,root:h.root,seed:h.seed,prototypes:ps.length,instructions:ins.length,constants,latches:latches.size,coveredThrough:pos,errors,opcodes:count};
fs.writeFileSync(__dirname+'/verification.json',JSON.stringify(report,null,2));console.log(report);
const s=fs.readFileSync(__dirname+'/input.luau','utf8'),a=s.indexOf('return function(x_ef76'),b=s.indexOf('end end)())({bytecode=buffer.fromstring');
const blob=s.match(/bytecode=buffer\.fromstring\(("(?:\\.|[^"\\])*")\)/)[1];
let runtime=s.slice(a,b).replace('return c_1cdc(q_dba0,{})','return {make=c_1cdc,root=q_dba0}');
fs.writeFileSync(__dirname+'/reference_vm.luau','local factory=(function() '+runtime+' end end)()\nreturn factory({bytecode=buffer.fromstring('+blob+')},nil,nil,nil,{[1]=function(g,s,i,b) for a in g,s,i do if b(a) then return end end end,[2]=function(g,s,i,b) for a,c in g,s,i do if b(a,c) then return end end end},vector.create)\n');
