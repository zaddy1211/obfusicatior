const fs=require('fs');
const s=fs.readFileSync(__dirname+'/input.luau','utf8');
const a=s.indexOf('return function(x_ef76');
const b=s.indexOf('end end)())({bytecode=buffer.fromstring');
const blob=s.match(/bytecode=buffer\.fromstring\(("(?:\\.|[^"\\])*")\)/)[1];
let runtime=s.slice(a,b).replace('local x_72e4 x_72e4=function(...)','do return {_sl,_pa,_va,meta[4],_pconsts,code_start,_pid,nil,meta[9],meta[10]} end local x_72e4 x_72e4=function(...)');
runtime=runtime.replace('return c_1cdc(q_dba0,{})',fs.readFileSync(__dirname+'/extract.luau','utf8'));
fs.writeFileSync(__dirname+'/extractor.luau','local factory=(function() '+runtime+' end end)()\n factory({bytecode=buffer.fromstring('+blob+')})\n');
console.log({a,b,literal:blob.length});
