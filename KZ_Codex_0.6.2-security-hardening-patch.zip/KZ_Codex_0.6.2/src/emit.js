/**
 * KZ Codex 0.6 — Emitter
 * Staged keys + ephemeral constants + sliding instruction windows
 */
import { randomBytes, createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { OPS } from './bytecode.js';
import { xorshift } from './codec.js';
import { fuse } from './fusion.js';
import { packageSegments, schema as schemaOf } from './segments.js';
import { payloadKey } from './aead.js';
import { emitWindowRuntime, DEFAULT_WINDOW } from './ephemeral-constants.js';
import { handlers, diversify, specializedCall } from './handlers.js';
import { dispatch, probes } from './diversity.js';
import { flatten } from './control-flow.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

export function random(seed) {
  let state = seed === undefined
    ? randomBytes(4).readUInt32LE()
    : createHash('sha256').update(String(seed)).digest().readUInt32LE();
  if (!state) state = 1;
  return () => { state = xorshift(state); return state / 4294967296; };
}

function shuffle(values, rng) {
  const a = [...values];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function loadTemplate(name) {
  try {
    return readFileSync(join(__dirname, name), 'utf8');
  } catch {
    return null;
  }
}

export function emit(program, options = {}) {
  const {
    seed,
    profile = 'balanced',
    fusion = true,
    maxBytes = 1_700_000,
    hardMaxBytes = 1_900_000,
    vmVariants = 3,
    readable = false,
  } = options;

  const rng = random(seed);
  const cryptoKey = payloadKey();

  const alphabetChars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz!#$%&()*+-;<=>?@^_`{|}~';
  const alphabet = shuffle([...alphabetChars], rng).join('').slice(0, 85);
  const constantTags = shuffle([0, 1, 2, 3, 4, 5, 6, 7], rng);
  const magic = Array.from({ length: 3 }, () => Math.floor(rng() * 256));
  const buildNonce = seed !== undefined
    ? createHash('sha256').update(String(seed)).digest().subarray(0, 8)
    : randomBytes(8);

  const fusionResult = fuse(program, {
    enabled: fusion,
    rng,
    maxKinds: profile === 'max' ? 72 : 56,
  });

  // Control-flow flattening for heavy/max profiles
  let flowStats = { insertedJumps: 0 };
  if (profile === 'heavy' || profile === 'max') {
    try {
      const flow = flatten(program, rng, { heavyOnly: profile === 'heavy' });
      if (flow && flow.stats) flowStats = flow.stats;
      if (flow && flow.program) program = flow.program;
    } catch (e) {
      // Control-flow is best-effort; synthetic programs may lack full CFG
      flowStats = { skipped: true, reason: String(e.message || e) };
    }
  }

  const nVariants = Math.min(Math.max(vmVariants, 1), 4);
  const engines = Array.from({ length: nVariants }, (_, i) => ({
    id: i + 1,
    slots: shuffle([0, 1, 2, 3, 4, 5], rng),
    opcodes: Object.fromEntries(OPS.map(name => [name, Math.floor(rng() * 256)])),
  }));

  // Assign engine, heavy flag, and dispatch mode to each prototype
  const dispatchStyles = profile === 'max' ? [0, 1, 2] : profile === 'heavy' ? [0, 1] : [0];
  program = {
    ...program,
    protos: program.protos.map((p, i) => ({
      ...p,
      engine: nVariants === 1 ? 1 : (1 + (i + Math.floor(rng() * nVariants)) % nVariants),
      heavy: p.heavy || profile === 'heavy' || profile === 'max',
      dispatchMode: dispatchStyles[Math.floor(rng() * dispatchStyles.length)],
    })),
  };

  // Explicit name -> canonical id map (OPS is an array; never index by name)
  const opcodeIds = Object.create(null);
  OPS.forEach((name, i) => { opcodeIds[name] = i; });
  // Ensure unique fused names get ids if present later
  for (const g of fusionResult.groups || []) {
    if (opcodeIds[g.name] === undefined) opcodeIds[g.name] = 256 + (fusionResult.groups.indexOf(g));
  }

  const config = {
    opcodes: opcodeIds,
    fusion: fusionResult,
    cryptoKey,
    constantTags,
    magic,
    alphabet,
    profile,
    buildNonce,
    engines,
  };

  const packaged = packageSegments(program, config, rng);

  const shareAWords = Array.from({ length: 8 }, (_, i) =>
    packaged.shareA.readUInt32LE(i * 4)
  );
  // Hardened Share A presentation (0.6.3):
  // - Two interleaved tables (even/odd indices) so a single m={}/x={} regex fails
  // - Secondary mask derived from the build magic bytes (already in the binary)
  // - Per-word rotate-left by a build-constant amount before the final XOR
  // Offline recovery is still possible; the documented Codex v6 extractor no longer
  // matches. A new extractor must re-implement the interleave + rotate + secondary mask.
  function bit32_lrotate(v, n) {
    n = n & 31;
    return ((v << n) | (v >>> (32 - n))) >>> 0;
  }
  // Identical secondary-mask PRF used at emit time and at runtime
  function secondaryWord(seed, index) {
    let s = (seed ^ Math.imul(index, 0x9e3779b9)) >>> 0;
    s = Math.imul(s ^ (s >>> 16), 0x85ebca6b) >>> 0;
    s = Math.imul(s ^ (s >>> 13), 0xc2b2ae35) >>> 0;
    s = (s ^ (s >>> 16)) >>> 0;
    return s || 1;
  }
  const shareMask = Array.from({ length: 8 }, () => (Math.floor(rng() * 0xffffffff) >>> 0) || 1);
  const rotAmount = 1 + Math.floor(rng() * 15); // 1..15
  const secondarySeed = ((magic[0] << 16) ^ (magic[1] << 8) ^ magic[2] ^ 0x4b5a3633) >>> 0;
  const secondaryMask = Array.from({ length: 8 }, (_, i) => secondaryWord(secondarySeed, i));
  // Apply rotate then dual-XOR; store even/odd indices in separate tables
  const rotated = shareAWords.map((w) => bit32_lrotate(w, rotAmount));
  const finalMasked = rotated.map((w, i) => (w ^ shareMask[i] ^ secondaryMask[i]) >>> 0);
  const even = finalMasked.filter((_, i) => i % 2 === 0);
  const odd  = finalMasked.filter((_, i) => i % 2 === 1);
  const maskEven = shareMask.filter((_, i) => i % 2 === 0);
  const maskOdd  = shareMask.filter((_, i) => i % 2 === 1);
  // Runtime reconstruction (unmask with both masks → unrotate → interleave)
  // The secondary PRF is recomputed from the same magic bytes already present.
  const shareALiteral = `(function()
local me={${maskEven.join(',')}} local mo={${maskOdd.join(',')}}
local xe={${even.join(',')}} local xo={${odd.join(',')}}
local sec=bit32.bxor(bit32.lshift(${magic[0]},16),bit32.lshift(${magic[1]},8),${magic[2]},0x4b5a3633)
local o={} local r=${rotAmount}
-- Luau bit32 has no imul; multiply via 16-bit limbs modulo 2^32.
local function mul32(a,b)
  a=bit32.band(a,0xffffffff) b=bit32.band(b,0xffffffff)
  local al=bit32.band(a,0xffff) local ah=bit32.rshift(a,16)
  local bl=bit32.band(b,0xffff) local bh=bit32.rshift(b,16)
  local low=al*bl
  local cross=(ah*bl+al*bh)%65536
  return bit32.band(low+cross*65536,0xffffffff)
end
local function sw(seed,idx)
  local s=bit32.bxor(seed,mul32(idx,0x9e3779b9))
  s=mul32(bit32.bxor(s,bit32.rshift(s,16)),0x85ebca6b)
  s=mul32(bit32.bxor(s,bit32.rshift(s,13)),0xc2b2ae35)
  s=bit32.bxor(s,bit32.rshift(s,16))
  if s==0 then s=1 end
  return s
end
for i=0,3 do
  local ve=bit32.bxor(xe[i+1],me[i+1],sw(sec,i*2))
  local vo=bit32.bxor(xo[i+1],mo[i+1],sw(sec,i*2+1))
  o[i*2+1]=bit32.bor(bit32.lshift(ve,32-r),bit32.rshift(ve,r))
  o[i*2+2]=bit32.bor(bit32.lshift(vo,32-r),bit32.rshift(vo,r))
end
return table.freeze(o)
end)()`;

  const windowSource = emitWindowRuntime(DEFAULT_WINDOW);
  const cryptoSource = loadTemplate('crypto.luau') || '';
  let runtime = loadTemplate('runtime.luau');
  if (!runtime) throw new Error('runtime.luau template missing');

  // Build schema + recipes for used opcodes
  const used = [...program.used];
  const shapes = used.map(name => {
    const s = schemaOf(name);
    const id = opcodeIds[name];
    if (id === undefined) throw new Error(`Unknown opcode in schema: ${name}`);
    return `[${id}]={${s.join(',')}}`;
  }).join(',');
  const recipes = fusionResult.groups.map(g => {
    const id = opcodeIds[g.name];
    if (id === undefined) return '';
    return `[${id}]={${g.ops.map(n => opcodeIds[n]).join(',')}}`;
  }).filter(Boolean).join(',');

  // Record field order (can be randomized later)
  const slots = [0, 1, 2, 3, 4, 5];
  const record = slots.map(n => `ins[${n + 1}]`).join(',');

  // Build handler dispatch from handlers.js
  function bindOperands(body, name = 'ins') {
    const tokens = body.match(/\b[a-e]\b/g) || [];
    const needed = [...new Set(tokens.filter(t => 'abcde'.includes(t)))];
    if (!needed.length) return body;
    const assigns = needed.map(v => `${v}=${name}[${'abcde'.indexOf(v) + 2}]`).join(',');
    // a=ins[2], b=ins[3], ... already extracted in run loop as locals
    return body;
  }
  function constants(body) {
    // constant(p,x) already works via the constant() helper in runtime
    return body;
  }

  const usedNames = [...program.used];
  // Ensure RETURN is present
  if (!usedNames.includes('RETURN')) usedNames.push('RETURN');
  if (!usedNames.includes('LOADN')) usedNames.push('LOADN');

  const choiceLog = [];
  const entries = usedNames.map(name => {
    if (handlers[name] === undefined) {
      console.warn('Missing handler for', name);
      return [OPS.indexOf(name), `do error('KZ Codex: missing handler',0) end`];
    }
    // Per-build handler diversification
    let body = diversify(name, rng, choiceLog);
    body = constants(body);
    // Always wrap in do...end so multi-statement handlers are valid inside if/else trees
    body = `do ${body || ''} end`;
    const opIndex = opcodeIds[name];
    if (opIndex === undefined) {
      console.warn('No opcode id for', name);
      return null;
    }
    return [opIndex, body];
  }).filter(Boolean);

  // Dispatch style: prefer inline; use blocks/table when profile asks for variety
  const primaryStyle = profile === 'fast' ? 'inline'
    : profile === 'max' ? (['inline', 'blocks', 'table'][Math.floor(rng() * 3)])
    : profile === 'heavy' ? (rng() < 0.5 ? 'inline' : 'blocks')
    : 'inline';
  const generated = dispatch(entries, rng, primaryStyle, profile === 'fast');

  // Startup integrity — keep lean on fast (FPS); fuller on balanced/heavy/max
  const probeModes = [...new Set(program.protos.map(p => p.dispatchMode ?? 0))];
  let checks;
  if (profile === 'fast') {
    // One mode, limited opcodes: enough to catch broken handlers without a probe storm
    const leanUsed = usedNames.filter(n => ['LOADN','ADD','MOVE','RETURN'].includes(n));
    checks = probes(opcodeIds, leanUsed.length ? leanUsed : ['LOADN','RETURN'], slots, rng, [0]);
  } else {
    checks = probes(opcodeIds, usedNames, slots, rng, probeModes.length ? probeModes : [0]);
  }
  const x = 2 + Math.floor(rng() * 31);
  const y = 2 + Math.floor(rng() * 7);
  const z = 3 + Math.floor(rng() * 11);
  // Structural anti-tamper (startup only). shareA is already cleared by this
  // point, so we checksum section descriptors + basic arithmetic integrity.
  const integrityBlocks = profile === 'fast'
    ? [
        `do local noise=bit32.bxor(${x},${y}) assert(bit32.bxor(noise,${y})==${x},0) end`,
        `do local _t={[${x}]=${y}} assert(_t[${x}]==${y},0) end`,
      ].join('\n')
    : [
        `do local noise=bit32.bxor(${x},${y}) assert(bit32.bxor(noise,${y})==${x},0) end`,
        `do local _r=bit32.lrotate(${x},7) assert(bit32.lrotate(_r,25)==${x},0) end`,
        `do local _t={[${x}]=${y}} assert(_t[${x}]==${y},0) end`,
        `do local _s=bit32.rrotate(${x},${z}) assert(bit32.lrotate(_s,${z})==${x},0) end`,
        `do local _a=${x} local _b=bit32.band(_a,${y}) assert(bit32.bor(_b,bit32.band(_a,bit32.bnot(${y})))==_a,0) end`,
        `do local _chk=0 for i=1,math.min(4,#sections) do _chk=bit32.bxor(_chk,sections[i][1] or 0,sections[i][3] or 0) end assert(_chk~=0 or #sections<1,0) end`,
      ].join('\n');


  // Native hybrid entry: init sealed string pool then hand off injected natives
  const nativeStringIds = program.nativeLiteralStringIds ?? [];
  const nativeCount = program.nativeCount ?? 0;
  const nativeArgs = Array.from({ length: nativeCount }, (_, i) => '_injected' + i);
  // Linked protected functions: each injection is the 0-based proto index of a
  // child main that RETURNS the protected function when executed once.
  // Build the closure and call it once at startup, then forward the resulting
  // function to the main proto in its declared argument position
  // (natives occupy positions 1..nativeCount, protected follow after).
  const injections = program.injections ?? [];
  const protectedArgs = injections.map((_, i) => '_protected' + i);
  const protectedDefs = injections.map((idx, i) => {
    if (!Number.isInteger(idx) || idx < 0 || idx >= program.protos.length) {
      throw new Error('Invalid protected injection index: ' + idx);
    }
    return `local _protected${i}=assert(make(protos[${idx + 1}],{},getfenv(0))(),0)`;
  }).join(' ');
  const makeArgs = [...nativeArgs, ...protectedArgs, '...'].join(',');
  const call = `local mainProto=protos[main] assert(mainProto and mainProto.words>0,0) return make(mainProto,{},getfenv(0))(${makeArgs})`;
  const nativeInit = nativeStringIds.length
    ? `_nativeInitialize({${nativeStringIds.map(id => `text(${id})`).join(',')}}) `
    : '';
  const invokeParams = [
    ...(nativeStringIds.length ? ['_nativeInitialize'] : []),
    ...nativeArgs,
    '...',
  ];
  const typeGuards = [];
  if (nativeStringIds.length) typeGuards.push(`assert(type(_nativeInitialize)=='function',0)`);
  for (const a of nativeArgs) typeGuards.push(`assert(type(${a})=='function',0)`);
  const guardSrc = typeGuards.length ? typeGuards.join(' ') + ' ' : '';
  const entry = (nativeArgs.length || nativeStringIds.length || protectedArgs.length)
    ? `local function invoke(${invokeParams.join(',')}) ${guardSrc}${nativeInit}${protectedDefs}${protectedDefs ? ' ' : ''}${call} end return invoke(...)`
    : call;

  const replacements = {
    SHARE_A: shareALiteral,  // reconstructed at runtime via mask
    SHARE_A_PLAIN_UNUSED: shareAWords.join(','),
    SECTIONS: packaged.literal,
    ALPHABET: alphabet,
    BOOTSTRAP_ID: String(packaged.bootstrapId),
    SHARE_C_ID: String(packaged.shareCId),
    MANIFEST: String(packaged.manifest),
    CRYPTOSOURCE: cryptoSource,
    EPHEMERAL_WINDOW: windowSource,
    MAGICCHECK: magic.map(n => `byte()==${n}`).join(' and '),
    CONSTANTTAGS: constantTags.map((wire, tag) => `[${wire}]=${tag}`).join(','),
    SCHEMA: shapes,
    RECIPES: recipes,
    RECORD: record,
    CAPTURE: String(opcodeIds.CAPTURE ?? 70),
    DISPATCH: generated.body,
    HELPERS: generated.declarations,
    PROBES: (checks && checks.source) ? checks.source : '',
    INTEGRITY: integrityBlocks || '',
    ENTRY: entry,
  };

  const templateTokens = [...runtime.matchAll(/@([A-Z0-9_]+)@/g)].map(match => match[1]);
  const unresolvedTemplateTokens = [...new Set(templateTokens.filter(key => !Object.hasOwn(replacements, key)))];
  if (unresolvedTemplateTokens.length) {
    throw new Error('Unknown runtime template tokens: ' + unresolvedTemplateTokens.join(', '));
  }
  for (const [key, value] of Object.entries(replacements)) {
    runtime = runtime.split(`@${key}@`).join(value);
  }
  if (!readable) {
    // Reduce forensic breadcrumbs in production
    runtime = runtime
      .replace(/'KZ Codex: handler integrity failed'/g, '0')
      .replace(/'KZ Codex: initialization integrity failed'/g, '0')
      .replace(/'KZ Codex: rotation integrity failed'/g, '0')
      .replace(/'KZ Codex: config integrity failed'/g, '0');
  }

  let source = runtime;
  if (!readable) {
    // Strip design-revealing comments and collapse excess blank lines for production
    source = source
      .replace(/^[ 	]*--.*$/gm, '')
      .replace(/\n{3,}/g, '\n\n');
  } else {
    source = `-- KZ Codex 0.6 Hardened (staged keys + ephemeral constants + sliding windows)\n` + source;
  }
  const outputBytes = Buffer.byteLength(source, 'utf8');

  if (outputBytes > hardMaxBytes) {
    throw new Error(
      `Hard size ceiling exceeded: ${outputBytes.toLocaleString()} > ${hardMaxBytes.toLocaleString()} bytes.`
    );
  }

  const stats = {
    ...packaged.stats,
    version: '0.6.0-dev',
    profile,
    vmVariants,
    outputBytes,
    preferredBudget: maxBytes,
    hardBudget: hardMaxBytes,
    underPreferred: outputBytes <= maxBytes,
    keySplit: true,
    shareAPresent: true,
    shareBInBootstrap: true,
    shareCSealed: true,
    stagedLoader: true,
    ephemeralWindowEmitted: true,
    slidingInstructionWindow: true,
    runtimeTemplate: true,
    handlerDiversification: choiceLog.length,
    dispatchStyle: primaryStyle,
    enginesAssigned: nVariants,
    handlerProbes: (checks && checks.count) || 0,
    integrityBlocks: true,
    controlFlow: flowStats,
  };

  return { source, stats, shares: packaged.shares };
}
