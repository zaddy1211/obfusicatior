/**
 * KZ Codex 0.6 — Segment packaging with staged keys + per-proto subkeys
 */
import { Writer, OPS, AUX } from './bytecode.js';
import { instructions, jumps } from './instructions.js';
import { compress, encode85 } from './codec.js';
import { createHash } from 'node:crypto';
import { packStrings } from './strings.js';
import { packConstants } from './constants.js';
import {
  seal, nonce, associatedData, stream,
  splitKey, deriveProtoSubkey
} from './aead.js';
import { classifyConstants } from './ephemeral-constants.js';

export function shuffle(values, rng) {
  const a = [...values];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export function storageOffset(index, lane, words, mode) {
  if (mode === 1) return lane * words + index;
  if (mode === 2) return (words - 1 - index) * 4 + lane;
  if (mode === 3) return (index % 2 === 1 ? index - 1 : index + 1 < words ? index + 1 : index) * 4 + lane;
  return index * 4 + lane;
}

export function schema(op) {
  let mask = 0;
  if (!new Set(['NOP', 'BREAK', 'JUMP', 'JUMPBACK', 'JUMPX', 'FASTCALL', 'FASTCALL1', 'FASTCALL2', 'FASTCALL2K', 'FASTCALL3', 'COVERAGE', 'PREPVARARGS', 'CAPTURE', 'CLOSEUPVALS', 'RETURN']).has(op)) mask |= 1;
  if (new Set('MOVE GETTABLE SETTABLE GETTABLEKS SETTABLEKS GETTABLEN SETTABLEN NAMECALL ADD SUB MUL DIV MOD POW ADDK SUBK MULK DIVK MODK POWK AND OR ANDK ORK CONCAT NOT MINUS LENGTH IDIV IDIVK'.split(' ')).has(op)) mask |= 2;
  if (new Set('GETTABLE SETTABLE ADD SUB MUL DIV MOD POW AND OR CONCAT SUBRK DIVRK IDIV'.split(' ')).has(op)) mask |= 4;
  let constant = 0;
  if (op === 'LOADK') constant = 1;
  if (op === 'LOADKX') constant = 2;
  if (['GETGLOBAL', 'SETGLOBAL', 'GETTABLEKS', 'SETTABLEKS', 'NAMECALL'].includes(op)) constant = 3;
  if (['ADDK', 'SUBK', 'MULK', 'DIVK', 'MODK', 'POWK', 'ANDK', 'ORK', 'IDIVK'].includes(op)) constant = 4;
  if (['SUBRK', 'DIVRK'].includes(op)) constant = 5;
  if (op === 'JUMPXEQKN') constant = 6;
  if (op === 'JUMPXEQKS') constant = 7;
  const flow = jumps.has(op) ? 1 : op === 'JUMPX' ? 2 : op === 'LOADB' ? 3 : 0;
  const special = { NEWCLOSURE: 1, DUPCLOSURE: 2, CAPTURE: 3, GETUPVAL: 4, SETUPVAL: 4, GETIMPORT: 5, CALL: 6, RETURN: 7, FORGLOOP: 8, FORNPREP: 9, FORNLOOP: 9 }[op] ?? 0;
  return [AUX.has(op) ? 1 : 0, mask, constant, flow, special];
}

/**
 * Package all sections using staged key material.
 * Returns shares + sealed sections ready for the staged loader.
 */
export function packageSegments(program, config, rng) {
  // Accept either OPS array or name->id map; always build a reliable name->id map
  let opcodes = config.opcodes;
  if (Array.isArray(opcodes)) {
    const map = Object.create(null);
    opcodes.forEach((name, i) => { map[name] = i; });
    opcodes = map;
  }
  const fusion = config.fusion;

  // 1. Split the master key
  const master = config.cryptoKey;
  const { shareA, shareB, shareC } = splitKey(master);

  // Build nonce for subkey derivation (stable for seeded builds)
  const buildNonce = config.buildNonce || Buffer.alloc(8);

  const sections = [];
  const add = (kind, owner, raw) => {
    const section = { kind, owner, raw };
    sections.push(section);
    return section;
  };

  // Strings still use master (or a derived stream key)
  const stringPackage = packStrings(program.strings, master, rng, shuffle);
  const strings = add(1, 0, stringPackage.raw);
  const functions = [];

  program.protos.forEach((p, pi) => {
    const list = instructions(p);
    const names = new Set(list.map(ins => fusion.positions[pi].get(ins.pc) ?? ins.op));
    const wires = shuffle(Array.from({ length: 256 }, (_, i) => i), rng);
    const mapping = Object.fromEntries([...names].map((name, i) => [name, wires[i]]));
    const layout = shuffle([0, 1, 2, 3], rng);
    const auxKey = Math.floor(rng() * 4294967296);
    const code = new Writer();

    for (const ins of list) {
      const name = fusion.positions[pi].get(ins.pc) ?? ins.op;
      const bytes = [mapping[name], ins.a, ins.b, ins.c];
      let encoded = 0;
      for (let j = 0; j < 4; j++) encoded = (encoded | (bytes[j] << (layout[j] * 8))) >>> 0;
      code.u32(encoded);
      if (ins.size === 2) code.u32((ins.aux ^ auxKey) >>> 0);
    }

    // Per-prototype subkey for heavy functions
    const subkey = p.heavy ? deriveProtoSubkey(master, pi + 1, buildNonce) : master;

    const constants = packConstants(p.constants, subkey, pi + 1, config.constantTags, rng, shuffle);
    const closures = new Writer();
    for (const id of p.children) closures.u32(id + 1);
    const closureData = stream(closures.finish(), subkey, 3, pi + 1);

    const mode = Math.floor(rng() * 4);
    const raw = code.finish();
    const formatted = Buffer.alloc(raw.length);
    const words = raw.length / 4;
    for (let i = 0; i < words; i++)
      for (let lane = 0; lane < 4; lane++)
        formatted[storageOffset(i, lane, words, mode)] = raw[i * 4 + lane];

    // Heavy functions encrypt under their own subkey (domain 4)
    const instructionData = p.heavy
      ? stream(formatted, subkey, 4, pi + 1)
      : formatted;

    // Classify constants for ephemeral window
    const { windowed, predecoded } = classifyConstants(p, config.profile || 'balanced');

    functions.push({
      p,
      mapping,
      layout,
      auxKey,
      mode,
      code: add(2, pi + 1, instructionData),
      constants: add(3, pi + 1, constants),
      closures: add(4, pi + 1, closureData),
      captures: list.some(ins => ['NEWCLOSURE', 'DUPCLOSURE', 'CLOSEUPVALS'].includes(ins.op)),
      instructionCount: list.length,
      subkey: p.heavy ? subkey : null,
      windowed: [...windowed],
      predecoded: [...predecoded],
    });
  });

  // Bootstrap + Share C must exist BEFORE final ID assignment
  const bootstrapPayload = Buffer.concat([shareB, Buffer.alloc(16)]);
  const bootstrap = add(5, 0, bootstrapPayload);
  const shareCSection = add(6, 0, shareC);
  const manifest = add(0, 0, null);

  // Single shuffle + final IDs — never reassign after this
  const ordered = shuffle(sections, rng);
  ordered.forEach((section, i) => { section.id = i + 1; });

  const w = new Writer();
  w.bytes(config.magic);
  w.var(strings.id);
  w.var(program.strings.length);
  w.var(program.protos.length);
  w.var(program.main + 1);

  // Engine / runner info (kept compatible)
  const engines = config.engines ?? [{ id: 1 }];
  w.u8(engines.length);
  if (engines.length > 1) {
    for (const engine of engines) {
      for (const slot of engine.slots) w.u8(slot + 1);
      const used = new Set([...program.used, ...fusion.groups.map(g => g.name)]);
      w.var(used.size);
      for (const name of used) {
        w.u8(opcodes[name]);
        w.u8(engine.opcodes[name]);
      }
    }
  }

  functions.forEach(({ p, mapping, layout, auxKey, mode, code, constants, closures, captures, windowed, subkey }) => {
    w.u8(p.engine ?? 1);
    w.u8(p.stack);
    w.u8(p.params);
    w.u8(p.ups);
    w.u8(p.vararg | (captures ? 2 : 0));
    w.var(p.code.length);
    w.var(p.constants.length);
    w.var(code.id);
    w.var(constants.id);
    layout.forEach(x => w.u8(x * 8));
    w.u32(auxKey);
    w.u8(mode);
    w.u8(p.dispatchMode ?? 0);
    w.u8(p.heavy ? 1 : 0);
    w.var(Object.keys(mapping).length);
    for (const [name, wire] of Object.entries(mapping)) {
      w.u8(wire);
      w.u8(opcodes[name]);
    }
    w.var(p.children.length);
    w.var(closures.id);
    // 0.6: windowed constant indices
    w.var(windowed.length);
    for (const idx of windowed) w.var(idx + 1);
    // 0.6: stream key — 8×u32 subkey for heavy, or 0 length for ordinary (use section master)
    if (subkey) {
      w.u8(1);
      for (let i = 0; i < 8; i++) w.u32(subkey.readUInt32LE(i * 4));
    } else {
      w.u8(0);
    }
  });
  manifest.raw = w.finish();

  // Seal under staged keys — IDs already final
  let rawBytes = 0, compressedBytes = 0, payloadBytes = 0;
  const allSections = ordered;

  // Key selection (staged):
  //   kind 5 (bootstrap / Share B) → sealed under Share A
  //   kind 6 (Share C)             → sealed under A⊕B (materialAB)
  //   everything else              → sealed under full master (A⊕B⊕C)
  const materialAB = Buffer.alloc(32);
  for (let i = 0; i < 32; i++) materialAB[i] = shareA[i] ^ shareB[i];

  const literals = allSections.map(section => {
    const zipped = compress(section.raw);
    let sectionKey = master;
    if (section.kind === 5) sectionKey = shareA;
    else if (section.kind === 6) sectionKey = materialAB;
    const sealed = seal(
      zipped,
      sectionKey,
      nonce(0, section.id),
      associatedData(section.id, section.kind, section.owner, section.raw.length, zipped.length)
    );
    const padded = Buffer.alloc(Math.ceil(sealed.ciphertext.length / 4) * 4);
    sealed.ciphertext.copy(padded);
    const encoded = encode85(padded, config.alphabet);
    rawBytes += section.raw.length;
    compressedBytes += zipped.length;
    payloadBytes += encoded.length;
    const tag = Array.from({ length: 4 }, (_, i) => sealed.tag.readUInt32LE(i * 4));
    return '{' + [section.kind, section.owner, section.raw.length, zipped.length, ...tag].join(',') + ',"' + encoded + '"}';
  });

  return {
    literal: literals.join(',\n'),
    manifest: allSections.find(s => s.kind === 0).id,
    bootstrapId: allSections.find(s => s.kind === 5).id,
    shareCId: allSections.find(s => s.kind === 6).id,
    shareA, // only Share A goes into the earliest stage of the emitted source
    shares: { shareA, shareB, shareC },
    stats: {
      authenticatedCipher: 'ChaCha20-Poly1305 (RFC 8439) + staged shares',
      keySplit: true,
      perProtoSubkeys: functions.filter(f => f.subkey).length,
      plaintextConstantCache: false,
      ephemeralWindows: functions.filter(f => f.windowed.length > 0).length,
      closureSections: functions.length,
      stringFragments: stringPackage.fragmentCount,
      plaintextStringCache: false,
      rawBytes,
      compressedBytes,
      payloadBytes,
      segmentCount: allSections.length,
      functionFormats: functions.map((f, i) => ({
        id: i + 1,
        executionEngine: f.p.engine ?? 1,
        protection: f.p.heavy ? 'heavy' : 'ordinary',
        instructionCache: f.p.heavy ? 'sliding-window' : 'predecoded',
        constantMode: f.windowed.length > 0 ? 'ephemeral' : 'predecoded',
        dispatchStyle: ['inline', 'blocks', 'table'][f.p.dispatchMode ?? 0],
        instructionFormat: ['interleaved', 'planes', 'reversed', 'pair-swap'][f.mode],
        parameters: f.p.params,
        upvalues: f.p.ups,
        vararg: !!f.p.vararg,
        instructions: f.instructionCount,
        words: f.p.code.length,
        constants: f.p.constants.length,
        windowedConstants: f.windowed.length,
        codeBytes: f.code.raw.length,
        constantBytes: f.constants.raw.length,
        opcodeKinds: Object.keys(f.mapping).length,
        formatFingerprint: createHash('sha256')
          .update(JSON.stringify([f.mapping, f.layout, f.auxKey, f.mode]))
          .digest('hex')
          .slice(0, 16),
      })),
      stringCount: program.strings.length,
      stringBytes: program.strings.reduce((n, s) => n + s.length, 0),
      constantCount: program.protos.reduce((n, p) => n + p.constants.length, 0),
    },
  };
}
