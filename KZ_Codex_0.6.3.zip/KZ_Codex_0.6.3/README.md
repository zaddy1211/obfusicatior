# KZ Codex 0.6 (Hardened)

Improved Luau/Roblox obfuscator built on the 0.5.4 foundation with a focus on **harder dynamic analysis**, **staged keys**, and a **1.7 MB preferred / 1.9 MB hard** size budget.

> Obfuscation raises analysis cost. It cannot make client code impossible to recover.
> Keep secrets and authoritative decisions on the server.

## What’s new vs 0.5.4

| Feature | 0.5.4 | 0.6 |
|---------|-------|-----|
| Master key | Single contiguous 32-byte key | **3-way XOR split** (A / B / C) |
| Key lifetime | Present for whole run | **Stage-gated**; never all three at once |
| Per-function keys | Shared master stream | **32-byte subkey per prototype** |
| Constants | Long-lived decoded values | **Ephemeral rotating window** (12 slots) |
| Heavy instructions | On-demand full stream | **Sliding window** (~6 instructions) |
| Loader | Single stage | **3-stage** (bootstrap → sections → heavy) |
| Handler diversity | Present | **Per-build diversification** |
| Multi-runner | Present | **Engine assignment + manifest tables** |
| Size budget | 1.5 MB | **Preferred 1.7 MB / hard 1.9 MB** |

## Requirements

- Node.js 22+
- Official **Luau 0.694** CLI tools (`luau`, `luau-compile`, and `luau-ast`) for real builds
- `--synthetic` is test-only; it does not produce a real protected build

## Quick start

```bash
# Self-test cryptographic foundations
node src/selftest-keys.js

# Full test suite (runtime tests run when Luau 0.694 tools are installed)
npm test

# Build the demo with its function kept native
node src/cli.js examples/demo.luau -o output/demo.kz.luau \
  --profile fast -O 2 --vm-variants 1 --seed dev --force --readable \
  --native add --report output/demo.report.json
```

With Luau 0.694 installed and on `PATH` (or under `tools/luau/`), builds compile-check the generated output before writing it. **They do not run the supplied program by default.** `--execute-test` opts into running the generated output—which also runs the input program—so use it only with code you trust. For performance-sensitive code, profile first; `--profile fast` alone does not keep hot functions out of the VM.

The CLI validates build settings before compiler discovery: profile and optimization ranges, VM variant count, size-budget ordering, function-selection arrays, and destination paths. It rejects missing option values and extra input paths; output and report files require `--force` to replace existing files. `--seed` controls transform layout and public derivation context; it is not secret key material. The payload key is always generated from OS randomness, so seeded builds are not byte-for-byte reproducible. See `docs/BUILD-VALIDATION.md`.

## Profiles

| Profile | Behavior |
|---------|----------|
| `balanced` | Default. Staged keys, selective heavy, inline dispatch |
| `heavy` | All protos heavy, control-flow flatten, blocks dispatch option |
| `max` | Maximum protection within budget; more variants |
| `fast` | Faster VM paths; less diversification |

### Roblox FPS / per-frame code

`--profile fast` does **not** make script functions native. With no `--native`
selections, hot code still runs through Codex's custom VM and can be dramatically
slower than the original. Keep per-frame callbacks, solvers, targeting, and
prediction functions native; use `--protect` only for low-frequency functions.

```bash
# Find top-level local function names first
node scripts/list-natives.mjs "input.luau"

# Replace HotUpdate with the exact hot function name from your script
node src/cli.js "input.luau" -o output/protected.luau \
  --profile fast -O 2 --vm-variants 1 --one-line --force \
  --native HotUpdate --report output/protected.report.json
```

`--native NAME` currently requires a top-level `local function NAME` with no
outer-local captures. Pass needed state as parameters or keep the function in
the VM. Confirm `nativeFunctions` in the JSON report lists every hot function.
Use Roblox's Script Profiler/MicroProfiler for the final FPS check; command-line
benchmarks do not predict device-specific frame rates.

## Security model (honest)

Still **client-side**. A skilled attacker who fully controls the Luau executor can eventually recover the program. See `docs/BUILD-SECURITY-REVIEW.md` for build-tool safeguards and remaining limitations.

Hard facts, no marketing:

- **Embedded keys remain recoverable.** Share A and the bootstrap chain ship in the output; offline recovery of the master key and all sections is expected. `tests/recovery.test.js` is the regression baseline proving the documented extractor still recovers everything.
- **Authentication ≠ modification resistance.** ChaCha20-Poly1305 rejects *unsigned* corruption (bit-flips fail tag checks). Someone who recovers the embedded key **can** generate valid modified payloads.
- Native functions are renamed ordinary Luau — recoverable once the startup string pool opens. That is the FPS tradeoff, intentional.
- Constant/instruction windows shorten *live memory* lifetime; they do not hinder offline bulk extraction.

The staged keys, windows, and per-prototype subkeys are **design choices intended to add analysis work**, not a measured security guarantee. The documented offline extractor currently recovers all sections, and no blind, head-to-head assessment against the public tools has been done. There is no supported estimate for how long analysis takes.

## Project layout

```
src/
  key-material.js      Staged split keys, subkeys, AEAD helpers
  ephemeral-constants.js  Rotating constant window
  segments.js          Packaging with staged seal hierarchy
  emit.js              Emitter (runtime template + handlers)
  runtime.luau         Generated runtime template
  build.js / cli.js    Build entry + CLI
  handlers.js          Opcode handlers
  diversity.js         Dispatch tree generation
  …                    bytecode, fusion, control-flow, etc.
tests/
  keys.test.js         Key, encoding, and AEAD unit tests
docs/
  DESIGN-0.6.md        Design rationale
  STATUS.md            Implementation status
```

## Size discipline

1. Prefer algorithmic complexity over data size  
2. No large decoy tables  
3. No second full interpreter  
4. Window sizes stay small (≤16 constants, ≤6 instructions)  
5. Share C only materialized for heavy functions  

## License / heritage

Built as a hardened evolution of KZ Codex 0.5.x ideas.  
Crypto is standard RFC 8439 ChaCha20-Poly1305.  
No claim of unprecedented reverse-engineering resistance.
