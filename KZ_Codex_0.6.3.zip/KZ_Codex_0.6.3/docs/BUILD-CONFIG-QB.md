# QB Smart Fit — build configuration (0.6.2)

## Intended split (verified)

| Function | Treatment | Reason |
|----------|-----------|--------|
| Solver (Smart Fit core) | `--native` | Per-frame; VM dispatch = ~1 FPS |
| Track (cut / predict) | `--native` | Called every frame with solve |
| Targeting (select WR/DB) | `--native` | Hot path |
| Routes (frequent calls) | `--native` | Hot if called per throw |
| Field | `--protect` | **Only after** the protected path passes the execution test |
| Beam | `--protect` | Visual only; **only after** the protected path passes |

Names must be exact top-level `local function` names in your source:

```powershell
node scripts/list-natives.mjs "kz ff3 better rewrite.lua"
```

## Build command

```powershell
node src/cli.js "kz ff3 better rewrite.lua" -o output/protected.luau `
  --profile fast -O 2 --vm-variants 1 --one-line --force `
  --native Solver --native Track --native Targeting --native Routes `
  --protect Field --protect Beam `
  --report output/protected.report.json
```

(Replace names with the real ones from `list-natives`.)

## Validation and execution safety

1. **Compile validation is automatic.** If generated output does not compile,
   the build exits non-zero and releases no output file or report.
2. **Runtime execution is opt-in.** Normal builds do not run the supplied
   program. `--execute-test` runs the generated chunk, including the source
   program, under the local Luau interpreter. Use that flag only with code you
   trust and whose side effects are safe in that environment. For a pure game
   script that depends on Roblox services, prefer a neutral, trusted smoke-test
   fixture and verify the real place in Roblox Studio.
3. **Protected-path coverage is still required.** A compile pass does not prove
   `--protect Field --protect Beam` will work at runtime. Cover forwarding and
   protected calls with the existing safe execution fixture or a trusted test
   fixture, then perform the in-game smoke test.
4. **Report checks.** `nativeFunctions` must list the intended hot functions;
   `protectedFunctions` must list protected functions with entry proto ids;
   `executionTest` should be `pass` only when explicitly tested (otherwise it
   reports an opt-in skip); `outputBytes` must remain below 1,900,000.

## What NOT to do

- Do not drop `--native` from the four hot paths to "add protection" — that is
  the ~1 FPS regression.
- Do not `--protect` the solver.
- Do not pad output toward the 1.9 MB ceiling; current overhead is ~36 KB of
  runtime for a 1.2 KB script and scales with program size, not with budget.
- Do not re-enable fusion until real e2e coverage exists for it.
