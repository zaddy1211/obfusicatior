# Response to Codex 0.6 review — P0 fixes applied

Codex verdict accepted: 0.6 was a development fork, not a 0.5.4 replacement.
The following **P0 correctness** items from the review are fixed in this tree.

| # | Defect | Fix |
|---|--------|-----|
| 1 | Wrong compiler discovery, silent synthetic | Fail-closed unless `--synthetic` / `allowSynthetic:true`. Searches `luau-compile` then `luau`, local tools dirs, PATH. Official args `--binary -ON -g0`. |
| 2 | Compress 3-byte vs runtime 2-byte match | Runtime expand now reads `u16 distance + u8 (length-3)` (matches `codec.js` and 0.5.4 decoder). Roundtrip test added. |
| 3 | `OPS[name]` always undefined → opcode 0 | Explicit `name → id` map from OPS array; engines use `OPS.map(name => …)`; schema/dispatch/CAPTURE use the map. |
| 4 | Second section shuffle stale IDs | Bootstrap + Share C created **before** single shuffle; IDs assigned once; no reassignment after manifest serialization. |
| 5 | Empty first instruction window | Refill on miss/empty slot; assert non-nil result. |
| 6 | Windowed strings returned integer IDs | Shared `decodeSemantic` applies `text()` for tag 3 on both windowed and ordinary paths. |
| 7 | Blocks/table helpers missing operands | Helpers now `(ins,op,a,b,c,d,e)`; call sites pass locals. |
| 8 | decode ignored kind/owner | `decode(id, kind, owner)` asserts section kind/owner when provided. |

## Still open (Codex P0 #8 partial + P1)

- Fusion pass ordering / fused opcode emission (source-level; needs real e2e)
- Full 0.5.4 `prepare()` validator parity
- Native/hybrid pipeline restore
- RETURN/error window wipe
- Real AEAD open of tampered ciphertext in Lua tests
- Seeded builds still use OS random for `splitKey` (document or fix for reproducible mode)
- Multi-runner dispatch still unused metadata
- **No real Luau e2e in this environment** — still required

## Verify

```bash
node --test tests/keys.test.js          # 14/14
node src/cli.js examples/demo.luau -o out.luau --force
# → must fail without compiler
node src/cli.js examples/demo.luau -o out.luau --synthetic --force --profile heavy
# → test-only synthetic OK
```

With official `luau-compile` on PATH or in `tools/luau/`, real compiles should work. Re-run Codex e2e harness after that.
