# Build-tool security review

Review scope: the local build pipeline and crypto helper API. This is not a
claim that client-side obfuscation can keep code secret. The shipped client
contains the material needed to run and decrypt itself; the documented offline
recovery test proves that an extractor can recover the payload.

## Fixes in this update

- **No automatic execution of user source.** Default builds compile-check the
  output but do not run it. `--execute-test` explicitly opts into executing
  the generated program in the local Luau interpreter; use it only for trusted
  source. A requested execution test fails closed if no interpreter is found.
  `--synthetic` always emits a fixed test program and ignores the supplied
  source, regardless of toolchain availability.
- **Safer artifact writes.** Output and report destinations are preflighted
  before either is written. Existing files are preserved unless `--force` is
  given. Temporary files use random names, exclusive creation, mode `0600`,
  and atomic no-clobber publish (hard link) or replace (rename), reducing
  predictable-temp-file/symlink, race-to-clobber, and partial-write risks.
- **Fresh payload keys.** The transform seed no longer derives the master
  encryption key. Each payload key comes from Node's operating-system CSPRNG.
  The seed is not secret key material, though it can influence transform layout
  and public derivation context. Seeded builds are therefore not byte-for-byte
  reproducible. This does not make client payloads secret once distributed.
- **Crypto API input checks.** Key/share lengths, nonce fields, counters, tags,
  and associated-data integers are validated instead of silently truncating or
  wrapping malformed values. This prevents accidental nonce collisions from
  out-of-range identifiers at the helper boundary.
- **Claims narrowed.** No time-to-break estimate or competitor ranking is
  asserted without a blind, reproducible evaluation.

## Remaining limits

- Client-side encryption keys and code are recoverable by an analyst who
  controls the client; authentication does not prevent an attacker who has the
  key from resealing modified data.
- In-memory zeroing in Luau is best-effort. The runtime, garbage collector, or
  copies can retain data.
- The build process still invokes the Luau compiler and AST tool on supplied
  source. Those tools are not run inside an OS sandbox; use current trusted
  tool binaries and avoid building hostile files on a sensitive machine.
- This review did not audit every opcode handler, parser edge case, custom
  ChaCha20/Poly1305 runtime line, or third-party project. A pinned-toolchain
  regression run and independent cryptographic/security review are still
  needed before making stronger claims.
