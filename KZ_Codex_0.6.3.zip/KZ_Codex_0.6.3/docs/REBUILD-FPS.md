# Rebuild for Smart Fit FPS (0.6.1)

## Problem
All-VM builds (~925 KB, profile fast, no `--native`) put the QB solver in the
interpreter → ~1 FPS while holding the ball.

## Procedure

### 1. List candidates
```powershell
node scripts/list-natives.mjs "kz ff3 better rewrite.lua"
```
Or with AST (preferred):
```powershell
# requires tools/luau/luau-ast.exe
node scripts/list-natives.mjs "kz ff3 better rewrite.lua"
```

### 2. Script Profiler (holding ball)
Note the **exact** top-level `local function` names that dominate frame time
(Smart Fit / trajectory / aim solve / per-frame prediction).

### 3. Rebuild — native those names only
```powershell
node src/cli.js "kz ff3 better rewrite.lua" -o output/protected.luau `
  --profile fast -O 2 --vm-variants 1 --one-line --force `
  --native Name1 --native Name2 --native Name3 `
  --report output/protected.report.json
```

### 4. Verify report
`nativeFunctions` must list those names.  
`outputBytes` under 1,900,000.

### 5. Measure
Same place, hold ball: original vs protected Smart Fit FPS / frame ms.

### 6. Optional after FPS is good
```powershell
  --protect SensitiveNonHotFn
```
Do **not** `--native` everything (weakens protection) or `--protect` the solver (kills FPS).

## Constraints
- `--native NAME` requires top-level `local function NAME` with **no outer local captures**
- Fusion remains **off** until e2e is green
- Needs `luau-compile` + `luau-ast` in `tools/luau/`
