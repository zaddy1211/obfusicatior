# Remaining limitations — 0.6.3 (updated from 0.6.2)

## Security (claims kept accurate)

1. **Embedded keys remain recoverable (offline).** Share A is now interleaved
   (even/odd tables) + secondary magic-derived mask + rotate. The *old*
   Codex-v6 single `m={}/x={}` extractor no longer matches. The updated
   `tests/recovery.test.js` implements the new reconstruction and still
   recovers **everything**. This is expected — staged keys raise *live-dump*
   cost, not offline extraction cost beyond requiring a new parser.
2. **Authentication is not modification resistance.** ChaCha20-Poly1305
   rejects *unsigned* corruption (bit-flips without the key fail tag checks —
   tested). But anyone who recovers the embedded key can reseal valid,
   modified payloads. Do not rely on the seal to prevent tampering by a
   motivated analyst.
3. **Handler probes** check that VM handlers haven't been edited; they do not
   attest full program identity and can be bypassed by patching the probes.
   0.6.3 adds a cheap structural checksum of section descriptors at startup.
4. **Native functions are ordinary Luau.** Once the sealed string pool opens
   at startup, native bodies are recoverable as readable (renamed) Lua. That
   is the FPS tradeoff — intentional.
5. **Windows help live dumps, not offline extraction.** Ephemeral constant /
   sliding instruction windows shorten memory lifetime; a full offline decode
   is unaffected.
6. Keep authoritative decisions and real secrets **server-side**. No client
   protection is absolute against an analyst who fully controls the executor.

## Correctness / coverage gaps

- The optional `--execute-test` runs generated output under the stock `luau`
  interpreter, not a Roblox emulator; game-specific paths (Raycast, Players,
  RunService) still need an in-game smoke test. It executes the supplied code,
  so opt in only for trusted, side-effect-safe fixtures.
- No e2e coverage yet for: fusion (still off by default), multi-runner
  dispatch (engines assigned, one shared dispatch), control-flow flattening
  on large real programs.
- `--seed` does not supply key entropy; it can affect transform layout and
  public derivation context. Payload master keys and XOR shares use OS
  randomness, so seeded builds are not byte-for-byte reproducible. Never treat
  a seed as a secret.
- `prepare()` validator is not yet at full 0.5.4 parity (jump/const/fusion
  checks).
- Integrity probes are not ported to multi-runner metadata.

## Measurement gap

- Original-vs-protected Smart Fit frame time / FPS / freezes must be measured
  in your place per `docs/MEASURE-SMART-FIT.md`. No in-game numbers were
  produced in this session — none are claimed.

## Evidence gap

- Improvement against the known extractor is **not** evidence of real-world
  resistance. A separate blind assessment (analyst without this repo's docs)
  has not been obtained; treat all "harder" language as cost-raising only.
