# Math-heavy scripts — performance guidance (0.6.3)

## Why pure-math VMs are slow

The heavy path decrypts a sliding instruction window, decodes constants through
an ephemeral window, and dispatches through an if/else or helper table. On a
tight arithmetic loop this costs ~30–80× native Luau.

## Recommended split

| Code shape | Treatment | Flag |
|------------|-----------|------|
| Per-frame solvers, trajectory, pure numeric loops | **native** | `--native Name` |
| One-shot factories, config builders, rare math | **protect** (VM) | `--protect Name` |
| Everything else | balanced / heavy profile | default |

Exact top-level `local function` names are required:

```bash
node scripts/list-natives.mjs your-script.luau
```

Example for a math-heavy script:

```bash
node src/cli.js script.luau -o out.kz.luau \
  --profile fast -O 2 --vm-variants 1 --one-line --force \
  --native Solve --native Integrate --native Project \
  --protect BuildLookup --protect Validate \
  --report out.report.json
```

## What natives still receive

- Identifier renaming
- Sealed string pool (authenticated)
- Structurally varied numeric literal encoding (3-term split, double-xor, shift/bor)
- No full VM → FPS preserved

## Optimizer (0.6.3)

`optimize.js` now also folds small integer `POW` when the exponent is a
compile-time constant in 0..10. Constant folding of ADD/SUB/MUL/DIV/MOD/IDIV
was already present. Dead-code and redundant MOVE elimination remain active
under `-O 1` / `-O 2`.

## What not to do

- Do **not** put the hot solver in the heavy VM “for protection”.
- Do **not** increase window sizes to “speed up” (they only hurt live dumps).
- Do **not** pad toward the 1.9 MB ceiling.

## Measurement

Always compare:

1. Unobfuscated + your algorithm
2. Fast profile + the native list above
3. (Optional) All-native baseline

Use `scripts/measure-smart-fit.luau` (or your own frame-time harness) under
identical conditions. If the unobfuscated baseline is already the bottleneck,
obfuscation overhead is secondary.
