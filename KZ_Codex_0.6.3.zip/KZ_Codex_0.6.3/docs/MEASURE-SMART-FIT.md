# Smart Fit in-game measurement (0.6.2)

In-game FPS cannot be measured from the build environment — it has no Roblox
client. This is the procedure; the numbers must come from your place.

## Procedure

1. Insert `scripts/measure-smart-fit.luau` as a LocalScript (identical copy in
   both test places). It reports frames, average FPS, average frame time,
   worst frame, and freeze count (frames > 100 ms) over a 20-second window.
2. **Baseline A — original script.** Hold the football with Smart Fit ON,
   identical graphics quality, camera position and server population. Record
   the printed line. Repeat 3 times, take the median.
3. **Build B — protected script** built with `docs/BUILD-CONFIG-QB.md`
   (Solver/Track/Targeting/Routes native; Field/Beam protected).
4. **Baseline C — original + Smart Fit OFF**, same conditions. This separates
   algorithm cost from obfuscation overhead.
5. Also capture a MicroProfiler dump (`Ctrl+F6`, pause with `Ctrl+P`) for B
   during one held-ball throw; note the top 3 labels under the script.

## Decision rules

- If B's average frame time is within ~10% of A: the split is correct; keep it.
- If B is much slower than A and the MicroProfiler shows VM dispatch on a hot
  function: move that function to `--native`, rebuild, re-measure.
- If B is slower and the profiler shows the *native* Solver dominating (same
  label hot in A): the cost is algorithmic, not protection — do not move
  protection boundaries; optimize the algorithm or accept the cost.
- If Field/Beam protection measurably hurts (it should not — they are
  low-frequency), move them back to `--native` and note it in the report;
  protection of cold functions should be free.
- Report frame time (ms), FPS, and freeze count for A, B, C — not FPS alone.

## Sanity floor

From the v6 session: all-VM build ≈ 1 FPS (unplayable), selective-native
build ≈ 35 FPS with Smart Fit on vs ≈ 50 FPS with it off. Anything near 1 FPS
means a hot function fell back into the VM — check the report's
`nativeFunctions` list first.
