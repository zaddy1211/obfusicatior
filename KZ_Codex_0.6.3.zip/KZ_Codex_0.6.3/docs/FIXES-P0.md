# P0 Fixes Applied (pre-Codex review)

## Fixed

### 1. Master key lifetime
- **Before:** `local cryptoKey = fullMaster()` at startup — full key always present after load.
- **After:** `cryptoKey = nil` until first outer section open via `ensureMaster()`.
- After formation: `shareC` and `materialAB` are cleared.
- Inner streams prefer `p.streamKey` and do not need master per access for heavy protos.

### 2. Per-proto subkeys at runtime
- **Before:** Build encrypted under subkeys; runtime always decrypted with master.
- **After:** Manifest carries stream key (1 + 8×u32) for heavy protos.
- Runtime reads `p.streamKey` and uses it in `chachaRange` for constants, closures, instructions.
- Ordinary protos still fall back to `ensureMaster()`.

### 3. Dispatch handler wrapping
- Every handler body wrapped in `do ... end` before insertion into if/else dispatch trees.
- Prevents multi-statement RETURN/CALL bodies from breaking the if/else structure.

### 4. Production output hygiene
- When `--readable` is not set, all `--` comment lines are stripped from the emitted source.
- Design stage comments are no longer present in production builds.

### 5. Share section cleanup
- Bootstrap section descriptor cleared after Share B recovery.
- Share C section descriptor cleared when Share C is opened.
- `materialAB` nulled after master formation.

## Tests
- `node src/selftest-keys.js` — pass
- `node --test tests/keys.test.js` — 10/10 pass
- Synthetic build under budget — pass

## Still not fixed (for Codex / follow-up)

| Item | Severity | Notes |
|------|----------|-------|
| No real Luau e2e execution | P0 | Environment lacks Luau 0.694 binary |
| prepare() incomplete vs 0.5.4 | P1 | Missing full jump/const/fusion validation |
| Multi-runner dispatch bodies | P2 | Engines assigned; one shared dispatch |
| Integrity probes | P2 | Not ported |
| CAPTURE still uses global op index | P1 | Should use per-mapping wire value in capture path |
| Native path hardening | P2 | Not done |
| Mutation tests on sealed sections | P1 | Only key-math tests exist |

## Honest residual risk
Even with staged recovery, after the first `ensureMaster()` the full master exists in `cryptoKey` for the rest of the process if any outer section is opened (manifest always is). The main remaining gain is:
1. Shorter window where *shares* coexist
2. Heavy inner streams bound to per-proto `streamKey` (dumping one proto’s key does not decrypt all heavy protos’ inner ciphertext without those keys)

Outer AEAD sections still depend on master once formed.

## Additional fixes (pre-Codex handoff)

### decodeOneInstruction RECORD bug (CRITICAL)
- **Before:** `return table.freeze({ins[1],...})` without defining `ins` → all heavy sliding-window instructions would be wrong/nil.
- **After:** Builds `local ins={op,a,b,c,d,e}` then freezes RECORD fields, clears scratch.

### Heavy-path AUX word scan
- Heavy/ephemeral prepare now scans the encrypted stream once to mark auxiliary follower words so sliding-window decode handles 2-word instructions.

### prepare() entry check
- Ordinary path asserts `code[1]` exists; freezes `auxiliaryWords`.

### Production comment strip
- Regex now matches indented `--` comments (`^[ \t]*--`), not only column-0.

### Tests
- 13/13 passing (added streamKey marker, production strip, AEAD tamper tag checks).

## invalid table key (runtime crash on football)

**Cause:** prepare() validation used 1-based bounds (`key>=1 and key<=constantCount`).
Luau DUPTABLE keys are **0-based** constant indices; 0.5.4 uses `key < constantCount`.

**Fix:** `assert(type(key)=='number' and key>=0 and key<p.constantCount, ...)`.

Rebuild the protected football script with the updated runtime template (same native flags).
