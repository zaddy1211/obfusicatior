# FPS + protection strategy (0.6)

## Goal
Playable Smart Fit FPS **and** higher recovery cost than plain source — without claiming unbreakable client IP.

## Split (recommended)

Keep **per-frame** code native. Put **lower-frequency** factories in the VM via `--protect`.

| Role | Treatment | Why |
|------|-----------|-----|
| Solver (Smart Fit core) | `--native` | Frame-critical; VM = ~1 FPS |
| Track (cut / predict) | `--native` | Called every frame with solve |
| Targeting (select WR/DB) | `--native` | Hot path |
| Routes classify | `--native` or `--protect` | Hot if every throw; protect if rare |
| Field constants/helpers | `--protect` | Cheap, less frame-critical |
| Beam visual | `--protect` | Visual only; good VM candidate |

Exact names must match top-level `local function` names:

```powershell
node scripts/list-natives.mjs "kz ff3 better rewrite.lua"
```

Example (replace with your names):

```powershell
node src/cli.js "kz ff3 better rewrite.lua" -o output/protected.luau `
  --profile fast -O 2 --vm-variants 1 --one-line --force `
  --native SolverFactory --native TrackFactory --native TargetingFactory `
  --protect FieldFactory --protect BeamFactory `
  --report output/protected.report.json
```

If Routes is on the hot path, keep it `--native`. Measure FPS after each change.

## What natives still get

- Renamed locals
- Sealed string pool (authenticated at startup)
- **Numeric constant encoding** (e.g. `180` → `bit32.bxor(...)` / `(x+k)-k`) so recovered source is not a clean table of magic numbers
- No full VM on those bodies (FPS preserved)

## What this does *not* do

- Stop a determined analyst from recovering native algorithms (Codex proved that)
- Replace server-side validation
- Make Share A / master unavailable offline

## Measure

1. Unobfuscated + Smart Fit FPS (baseline)
2. This split build + Smart Fit FPS
3. Optional: all-six-native build FPS (max speed, min protection on those regions)

Stay under 1.9 MB; do not pad.
