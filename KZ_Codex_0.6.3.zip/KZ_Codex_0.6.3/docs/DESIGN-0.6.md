# KZ Codex 0.6 — Hardened Design

## Goals
- A: Maximum practical protection strength
- B: Performance close to 0.5.4
- C: Significantly harder dynamic analysis
- Size: preferred ≤ 1.7 MB, hard ceiling 1.9 MB

## Core Security Upgrades

### 1. Staged Key Material (Split Key)
The 256-bit master key is never present as a single contiguous value in the final binary for long.
It is split into 3 shares at build time using a simple XOR secret-sharing scheme:

- Share A (bootstrap) — present early, used only to authenticate Stage-0 and recover Share B
- Share B (loader) — recovered after Stage-0, used to open main sections and derive per-prototype material
- Share C (late) — recovered only when the first heavy / protected function is entered

At any single point in time an attacker dumping memory obtains at most 2 of the 3 shares.

### 2. Per-Prototype Subkeys
Each prototype receives a 128-bit subkey derived as:

```
subkey = HMAC-SHA256(master_material, "proto" || proto_id || build_nonce)[0:16]
```

Heavy instruction streams and constant streams are encrypted under this subkey (or a further derived key).
Stealing the subkey of one function does not immediately give every other function.

### 3. Ephemeral Constant Windows
Constants are no longer decoded into a long-lived table that can be dumped wholesale.
Instead:

- A small rotating window (default 8–16 slots) holds currently live decoded values.
- On access, if the constant is not in the window it is decoded, inserted, and the oldest entry is cleared.
- After a configurable number of accesses or on function return the window is wiped.

A memory dump therefore only ever contains a handful of live constants, not the entire pool.

### 4. Sliding Instruction Window (Heavy Functions)
For heavy prototypes the instruction stream stays encrypted.
Only a small sliding window (e.g. 4–8 instructions) around the current PC is decrypted into a temporary buffer.
The previous window is cleared before the next is materialized.
This forces an attacker to either single-step or write a more sophisticated tracer.

### 5. Staged Loader
The loader itself is split:

Stage 0 – Minimal bootstrap (authenticates first section, recovers Share B)
Stage 1 – Opens remaining authenticated sections, builds prototype metadata, recovers Share C on first heavy use
Stage 2 – Main multi-runner interpreter (improved from 0.5.4)

Dumping the main interpreter no longer gives the complete decryption capability.

### 6. Light Native Hardening
Even regions marked native receive:
- Constant literal blinding (same authenticated pool)
- Simple expression rewriting for arithmetic chains
- Identifier length and declaration order variation (already present, strengthened)

### 7. Size Discipline
All new structures are designed to stay inside the 1.7–1.9 MB envelope.
No large decoy tables, no second full VM, no per-instruction AEAD.

## Compatibility
- Still targets official Luau 0.694 bytecode
- Same CLI surface as much as possible
- Generated scripts remain self-contained (no external loaders)

## Threat Model Reminder
This still cannot stop a determined attacker who fully controls the executor.
It raises the cost of writing a reliable automated dumper and of recovering a clean source from a single memory snapshot.
