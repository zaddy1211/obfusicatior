# Response to Codex recovery report (v6)

## Agreement

Codex’s measured recovery is accurate for this architecture:

1. **Native QB regions are recoverable as readable Lua** once the string pool is opened. That is the FPS tradeoff: native = ordinary Luau, not VM-hidden.
2. **Masked Share A is not a secrecy boundary.** A and the bootstrap chain are in the client binary; offline XOR recovery is expected.
3. **Per-proto opcode maps normalize** to standard Luau. Layout diversity raises decoder cost; it does not create a new ISA.
4. **AEAD authenticates holders of the embedded key.** A key-holder can reseal; unsigned bit-flips are rejected. Probes check handlers, not full program identity.
5. **Windows help live memory lifetime, not offline bulk extract.**

Documentation must not claim “practically impossible to recover.” Client protection raises cost and frustrates casual dumps; it is not a trusted authority.

## FPS (your numbers)

| Condition | Approx FPS |
|-----------|------------|
| Script running, Smart Fit off | ~50 (cap 120) |
| Smart Fit on | ~35 |

That is a large improvement over the all-VM ~1 FPS path. The remaining ~15 FPS gap is largely **Smart Fit algorithm cost in native Luau**, not VM dispatch. Confirm by measuring **unobfuscated** source with Smart Fit on under the same conditions. If original is also ~35–40, obfuscation overhead is small.

Fast-profile changes in this pass:
- Fewer startup handler probes (LOADN/ADD/MOVE/RETURN only, one mode)
- RETURN only wipes windows when they were actually used (`instrWindowStart` / `clearOnReturn`)

## What to strengthen without killing Smart Fit

| Do | Don’t |
|----|--------|
| Keep Smart Fit / trajectory **native** | Put solver back in heavy VM |
| `--protect` small **non-hot** sensitive pieces | Virtualize all 6 native factories |
| Measure FPS after every change | Pad toward 1.9 MB |
| Honest reports: cost-raising, not unbreakable | Claim key-holder cannot rewrite |

## Rebuild

Same native list as v6, fast profile:

```powershell
node src/cli.js "kz ff3 better rewrite.lua" -o output/protected.luau `
  --profile fast -O 2 --vm-variants 1 --one-line --force `
  --native <same 6 names> `
  --report output/protected.report.json
```

Compare FPS to v6 under identical conditions. Also time unobfuscated + Smart Fit once for a true baseline.
