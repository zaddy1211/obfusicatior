# Open-source Lua/Luau obfuscator review

Reviewed 2026-10-13. I downloaded shallow source snapshots for comparison and
checked their READMEs, license files, and pipeline structure. I did **not** run
or vendor the third-party projects. No third-party code is copied into this
patch. Source snapshots are provided separately in `lua-obfuscator-reference-pack.zip`
for independent review; they are not project dependencies.

| Project | License / target | Relevant design | Decision for KZ Codex |
|---|---|---|---|
| [Prometheus](https://github.com/prometheus-lua/Prometheus) | Prometheus License (modified MIT-style); Lua 5.1 and basic/incomplete Luau support | AST passes, renaming, string/constant transforms, control-flow flattening | Reference for AST-pass organization only. Its license requires visible attribution and a derivative-work statement if incorporated/distributed. Not a drop-in Luau runtime. |
| [Obscura by vo3pal](https://github.com/vo3pal/obscura) | MIT; designed for Luau | Separate lightweight/native/VM modes; its VM mode defaults to rolling bytecode reads | The mode separation is a useful design lesson. Do not layer its VM on KZ's VM; rolling decoding adds execution work. |
| [Obscura by p4inz-code](https://github.com/p4inz-code/obscura) | MIT; Luau source toolkit | AST/binding pipeline for safe local renaming, string and constant transforms, and dead-code insertion; README describes runtime/golden-corpus checks | Reference for conservative transforms and semantic tests. It is not a second VM to put in the hot path. |
| [Clyde Luau Obfuscator](https://github.com/sfr-development/Lua-Obfuscator-Clyde-Protection) | MIT; Luau | Advertises stack- and register-based VM backends plus control-flow scrambling | Reviewed as an architectural comparison; not combined with another VM because that would add interpreter overhead and compatibility risk. |
| [Bill's Lua Obfuscator](https://github.com/BillChirico/LUA-Obfuscator) | MIT; general Lua/web tool | Name mangling, string/number transforms, and control-flow flattening; its README labels flattening CPU-intensive | Reference for making transforms individually selectable. Not treated as Luau-compatible without testing its parser/generator on Luau syntax. |

## What was reused

Only high-level engineering lessons were applied: keep transformations
selectable, preserve a native/source path for hot code, and verify generated
outputs with the real target compiler/runtime. **No code, algorithms, VM
handlers, or dependencies were copied from these repositories.**

Combining all five obfuscators as sequential passes would not make the result
reliably "stronger": it would duplicate transforms, inflate output, make
compatibility harder to reason about, and—most importantly for this bug—could
put more interpreters/decoders on every frame. The right comparison is
feature-by-feature, with one runtime and measured tradeoffs.

## Licensing note

KZ Codex's public repository did not include a top-level license file. Before
redistributing a derivative, decide and document KZ Codex's own license. If
Prometheus code is ever copied or integrated, preserve its license notice and
meet its additional attribution/derivative-statement conditions. If code from
any MIT project is ever copied, keep that project's copyright and license
notice with the redistributed copy.
