# Build configuration validation

KZ Codex validates options before checking for Luau binaries or creating temporary
build files. Invalid settings fail with an actionable message instead of being
silently clamped or accidentally interpreted as another CLI option.

## Validated settings

- Profiles: `fast`, `balanced`, `heavy`, or `max`.
- Luau and VM optimization levels: integer `0`, `1`, or `2`.
- VM variants: integer from `1` through `4`.
- Preferred and hard size budgets: positive safe integers, with the preferred
  budget no larger than the hard ceiling.
- `--native`, `--protect`, and `--native-region`: arrays of non-empty,
  single-line values. A function cannot be selected as both native and
  protected.
- Seed: string or finite number. It is not secret key material, though it may
  influence transform layout and public derivation context. Payload master keys
  use OS randomness. Boolean flags must be actual booleans when using the
  JavaScript build API.
- Paths: output and report must differ; a report cannot target the input source.
  Existing output/report files are preserved unless `--force` is supplied.

The CLI now catches missing values (for example, `--output --force`) before
one flag can be mistaken for another flag's value. It also rejects multiple
positional input paths.

## Build-time execution safety

Normal builds compile-check but **do not execute** the supplied program.
`--execute-test` is an explicit opt-in that runs the generated output in the
local Luau interpreter, which also runs the input program. Use it only for
source you trust. If an execution test is requested but no interpreter is
available, the build fails rather than claiming the test passed. The old
`--no-execute` flag remains as a compatibility alias for the default.
`--synthetic` always emits a fixed test program and ignores the provided input,
even when the real Luau toolchain is installed.

## Regression coverage

`tests/options.test.js` covers defaults, boundary values, invalid settings,
path collisions, missing CLI values, and extra input paths. The tests use a
neutral Luau placeholder name and do not read or transform user gameplay
scripts.

Run:

```bash
npm test
```

Compiler/runtime integration tests still require the pinned official Luau
0.694 tools; when they are absent, the four tool-dependent tests are reported
as skipped rather than counted as passes.
