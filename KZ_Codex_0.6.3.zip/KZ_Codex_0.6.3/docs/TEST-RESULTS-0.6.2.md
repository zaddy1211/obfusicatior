

## Build safety update (2026-10-13)

The runtime-execution results above are historical results from the earlier
build behavior. Normal builds now compile-check only; `--execute-test` is an
explicit opt-in because it runs the supplied Luau program. Use it only with
trusted, side-effect-safe source. `--synthetic` now always builds the fixed
synthetic fixture and ignores the input, regardless of whether Luau tools are
installed.
