# QB Smart Fit FPS — selective native (0.6)

## Cause of ~1 FPS

`--profile fast` only lightens VM flags. **If the Smart Fit solver / trajectory /
per-frame callbacks stay virtualized, every frame pays full VM dispatch cost.**
That matches ~1 FPS with the ball held. Size (~925 KB) is not the problem;
**VM path on hot math is.**

0.5.4 avoided this with explicit `--native` on those functions.

## Fix

1. In Studio MicroProfiler / Script Profiler, find the top cost while holding the
   ball (Smart Fit). Note the **top-level local function names** in your source
   (must be `local function Name(...)` at file scope, no outer local captures).

2. Rebuild with those names native (fusion still off):

```powershell
node src/cli.js "kz ff3 better rewrite.lua" -o output/protected.luau `
  --profile fast -O 2 --vm-variants 1 --one-line --force `
  --native ExactName1 --native ExactName2 `
  --report output/protected.report.json
```

3. Report must list those names under `nativeFunctions`.

4. In the same game conditions: original vs protected Smart Fit frame time / FPS.

## Rules (from 0.5.4)

- `--native NAME` requires a **top-level** `local function NAME`.
- No outer-local captures (use `--native-region` for self-contained blocks).
- Names must be unique across `--native` and `--protect`.
- Needs `luau-ast` + `luau-compile` in `tools/luau/`.

## What stays virtualized

Everything not listed stays in the staged VM (good for protection). Only the
measured hot solvers should be native.

## What we cannot report from this environment

Original/protected Smart Fit FPS — must be measured in your Roblox place.
