# Performance triage: Roblox Luau

## What the test found

The main runtime cost is executing frequently-called code through the custom VM.
The `fast` profile changes VM settings; it does **not** move functions out of the
VM. A synthetic workload was run with the official Luau 0.694 CLI tools, using
five runs per variant and the median time measured inside the hot function:

| Variant | Median time | Checksum |
|---|---:|---:|
| Original Luau | 0.018 s | 258868.601120 |
| `--profile fast`, no native functions | 3.870 s | 258868.601120 |
| Same build, `--native runHotWork` | 0.047 s | 258868.601120 |

That is about **215× slower** for the all-VM version versus the original in
this synthetic CLI benchmark; selecting the hot function as native made the
workload about **82× faster than all-VM**. This is not a Roblox FPS result. It
shows why per-frame work should not be virtualized; measure the actual place on
the target device.

A second fixture caches stable `math.sin` / `math.cos` references once before
the inner loop. In this separate test, medians were 0.018 s original, 1.410 s
all-VM, and 0.034 s with the hot function native. Local caching helped this
particular workload but did not make the VM suitable for hot loops.

Run the fixtures yourself:

```bash
node src/cli.js benchmarks/hot-function.luau -o /tmp/hot-vm.luau \
  --profile fast -O 2 --vm-variants 1 --force --report /tmp/hot-vm.json
node src/cli.js benchmarks/hot-function.luau -o /tmp/hot-native.luau \
  --profile fast -O 2 --vm-variants 1 --force --native runHotWork \
  --report /tmp/hot-native.json

tools/luau/luau /tmp/hot-vm.luau
tools/luau/luau /tmp/hot-native.luau
```

The fixtures should produce the same checksum. For accurate comparisons, keep
Luau version, machine, optimization flags, input, and number of repetitions
constant. The project expects official Luau 0.694 tools (`luau`,
`luau-compile`, and `luau-ast`).

## Recommended build for a real script

1. Get exact top-level local function names:

   ```bash
   node scripts/list-natives.mjs "input.luau"
   ```

2. Use Roblox's Script Profiler while reproducing the slowdown. Select the
   functions that run every frame or dominate frame time, not just functions
   with names that sound important.

3. Keep those functions native; protect only code that runs infrequently:

   ```bash
   node src/cli.js "input.luau" -o output/protected.luau \
     --profile fast -O 2 --vm-variants 1 --one-line --force \
     --native HotUpdate --native SolveTrajectory \
     --protect RareFactory --report output/protected.report.json
   ```

4. Verify `nativeFunctions` in the report contains all hot functions. `--native`
   currently requires a top-level `local function NAME` that does not capture
   outer locals. Pass state into the function as arguments or refactor the hot
   code into a self-contained top-level function. If the hot code remains in an
   anonymous callback or is marked `--protect`, it can still be slow.

5. Compare original and output in the same Roblox place, device, server load,
   graphics setting, and camera state. Record median frame time (ms), FPS, and
   freezes; use MicroProfiler to confirm that VM dispatch is no longer on the
   hot path. The existing `scripts/measure-smart-fit.luau` harness can collect
   a basic frame-time summary.

## Runtime compatibility fix in this patch

Generated output used `bit32.imul`, which is **not** part of Luau's `bit32`
API. On official Luau 0.694 this made even a tiny output crash with
`attempt to call a nil value` before user code ran. The emitter now uses a
small 16-bit-limb multiplication helper to produce the same low 32 bits using
standard `bit32` operations. The real-output regression tests now pass under
Luau 0.694.

## Avoid stacking VM obfuscators

Running several virtualizers/rolling decoders one after another adds runtime
work and makes correctness/performance harder to diagnose. Compare other
projects for specific ideas, but keep one runtime and make expensive transforms
opt-in. A lighter AST/source pass is a better fit for code that must run every
frame.
