# Hardening added (0.6.1 anti-tamper pass)

## Automatic (no CLI flags)

| Feature | Effect |
|---------|--------|
| Handler integrity probes | Startup mini-runs of LOADN/ADD/… assert correct results; failed if handlers edited |
| Arithmetic/config self-tests | bit32.bxor / lrotate / table integrity asserts before entry |
| Share A / sections asserts | Refuse trivial zeroed key material or empty section table |
| Share B ≠ Share A check | After bootstrap open |
| Protos freeze + count assert | Manifest list frozen; count must match |
| Window wipe on RETURN | Constant window + instruction window cleared on function return (harder mid-run dumps) |
| Production string scrub | Probe failure messages reduced to `0` (less forensic text) |
| Table-key bounds fix | 0-based DUPTABLE keys (fixes Football Fusion crash) |
| Staged keys + streamKeys | Unchanged foundation |
| Selective native | Still required for FPS on hot paths |

## Rebuild command (keep your natives)

```powershell
node src/cli.js "kz ff3 better rewrite.lua" -o output/protected.luau `
  --profile fast -O 2 --vm-variants 1 --one-line --force `
  --native <same list as kz06-qb-native-v2> `
  --report output/protected.report.json
```

Report should show `handlerProbes` > 0 when those opcodes are used.

## Honest limits

- Offline analyst can still recover staged master from Share A in source + section opens.
- Native bodies are renamed Luau (weaker than VM) — intentional for FPS.
- Probes catch *handler* edits, not every possible memory patch.
- No client protection is absolute for elite targets; server authority remains required for true secrets.

## Do not

- Drop `--native` on Smart Fit paths to “add protection”
- Pad file to 1.9 MB
- Re-enable fusion until e2e is clean
