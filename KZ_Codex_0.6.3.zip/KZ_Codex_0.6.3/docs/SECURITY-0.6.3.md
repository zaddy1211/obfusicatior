# Security hardening — 0.6.3

## Added in this pass

| Feature | Effect | FPS impact |
|---------|--------|------------|
| **Decoy AEAD sections** | 3–7 fake kind 2/3/4 sections sealed under random keys, shuffled into the section table | None (never opened at runtime) |
| **Native opaque predicates** | Always-false branches injected at sealed native body entry | Negligible (one check per factory init) |
| **Boolean constant encoding** | `true`/`false` → equivalent expressions in sealed natives | Negligible |
| **Stronger numeric forms** | Already in 0.6.2 (3-term, double-xor, shift/bor) | Small in hot natives |
| **Structural integrity (all profiles)** | Section table shape + descriptor XOR self-check at startup | Startup only |
| **Share A interleaved mask** | From 0.6.2/0.6.3 prior pass | Startup only |

## Still true (do not overclaim)

- Offline recovery of master from embedded Share A material remains possible once an extractor is updated.
- Native bodies remain ordinary Luau after the string pool opens — **FPS tradeoff**.
- AEAD rejects unsigned corruption; a key-holder can reseal.
- Server-side validation is required for real authority.

## Recommended build (FPS + this hardening)

```powershell
node src/cli.js game.luau -o out.luau --profile fast -O 2 --vm-variants 1 --one-line --force `
  --native <Solver> --native <Track> --native <Targeting> `
  --protect <Field> --protect <Beam> `
  --report out.json
```

Decoys and native transforms apply automatically; no extra flags.
