import {spawnSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {random} from './emit.js';
import {nativeLiterals} from './native-literals.js';
// AST locations are UTF-8 byte columns, not JS UTF-16 string offsets.
export function prepareNative(input,names,astExecutable,{seed,nativeStringProtection=true,sealNames=names}={}) {
  const source=readFileSync(input),lines=[0];
  for(let i=0;i<source.length;i++)if(source[i]===10)lines.push(i+1);
  const range=location=>{
    const match=location.match(/^(\d+),(\d+) - (\d+),(\d+)$/);
    if(!match)throw Error('Invalid AST location');
    return [lines[Number(match[1])]+Number(match[2]),lines[Number(match[3])]+Number(match[4])];
  };
  const result=spawnSync(astExecutable,[input],{encoding:'utf8',maxBuffer:128*1024*1024,timeout:120000});
  if(result.error)throw result.error;if(result.status!==0)throw Error(result.stderr||result.stdout||'Luau AST parse failed');
  const ast=JSON.parse(result.stdout),rng=random(seed===undefined?undefined:'native-'+seed);
  const seen=new Set();
  const identifier=()=>{
    let value;
    do {value=`_${Array.from({length:7+Math.floor(rng()*9)},()=>String.fromCharCode(97+Math.floor(rng()*26))).join('')}`;}
    while(seen.has(value)||source.includes(Buffer.from(value)));
    seen.add(value);return value;
  };
  const declarations=[],replacements=[],args=[],nativeNames=[];
  const selected=new Set(names);
  if(selected.size!==names.length)throw Error('Duplicate --native function name');
  const sealed=new Set(sealNames);
  const literals=nativeStringProtection?nativeLiterals(ast.root.body.filter(n=>n.type==='AstStatLocalFunction'&&sealed.has(n.name.name)),source,range,astExecutable):new Map();
  const unique=new Map();for(const value of literals.values())unique.set(value.toString('base64'),value);
  const literalStrings=[...unique.values()];
  for(let i=literalStrings.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[literalStrings[i],literalStrings[j]]=[literalStrings[j],literalStrings[i]];}
  const literalIds=new Map(literalStrings.map((value,i)=>[value.toString('base64'),i+1]));
  const literalPool=literalStrings.length?identifier():null,initializer=literalStrings.length?identifier():null;
  for(const name of names) {
    const statement=ast.root.body.find(n=>n.type==='AstStatLocalFunction'&&n.name.name===name);
    if(!statement)throw Error(`--native ${name}: requires a top-level local function declaration`);
    const [start,end]=range(statement.location);
    const rename=new Map(),edits=new Map();
    const loopAliases=new Map(),functionCaches=new Map();
    if(sealed.has(name)) {
      function cacheWalk(node,owner=null,depth=0) {
        if(!node||typeof node!=='object')return;
        if(node.type==='AstExprFunction'){owner=node;depth=0;}
        if(['AstStatFor','AstStatForIn','AstStatWhile','AstStatRepeat'].includes(node.type))depth++;
        if(owner&&depth&&node.type==='AstExprConstantString'&&literals.has(node.location)) {
          let cached=functionCaches.get(owner);
          if(!cached){cached=new Map();functionCaches.set(owner,cached);}
          const id=literalIds.get(literals.get(node.location).toString('base64'));
          if(!cached.has(id)&&cached.size<16)cached.set(id,identifier());
          if(cached.has(id))loopAliases.set(node.location,cached.get(id));
        }
        for(const value of Object.values(node))if(Array.isArray(value))value.forEach(v=>cacheWalk(v,owner,depth));
        else if(value&&typeof value==='object')cacheWalk(value,owner,depth);
      }
      cacheWalk(statement);
      for(const [func,cached] of functionCaches) {
        const [bodyStart]=range(func.body.location);
        const text=' '+[...cached].map(([id,alias])=>`local ${alias}=${literalPool}[${id}];`).join(' ')+' ';
        edits.set(`cache:${bodyStart}`,{start:bodyStart,end:bodyStart,text});
      }
    }
    const addLocal=local=>{
      const [a,b]=range(local.location);
      if(a<start||b>end)throw Error(`--native ${name}: captures outer local '${local.name}'. Pass it as a function argument instead.`);
      if(!rename.has(local.location))rename.set(local.location,identifier());
      edits.set(`${a}:${b}`,{start:a,end:b,text:rename.get(local.location)});
      return rename.get(local.location);
    };
    // Encode select numeric literals so recovered natives are not plain tables of magic numbers.
    // Skip tiny values (0/1/2/-1) to limit hot-path arithmetic noise.
    // Forms are chosen to be *structurally* different (multi-term splits, shift/bor
    // decomposition, double-xor), not just re-masked single terms — pure number
    // masking alone is trivially simplified by an analyst. Every form is an exact
    // identity for integer n (Luau doubles are exact for |n| <= 2^53; bit32 forms
    // are kept to non-negative n <= 1e7 so unsigned semantics cannot change values).
    const encodeNumber = (n) => {
      if(!Number.isFinite(n) || !Number.isInteger(n)) return null;
      if(n >= -2 && n <= 2) return null;
      if(Math.abs(n) > 1e7) return null;
      const k = (1 + Math.floor(rng() * 97)) | 0;
      const j = (1 + Math.floor(rng() * 251)) | 0;
      const b = (1 + Math.floor(rng() * 4093)) | 0;
      const forms = [
        `(${n + k}-${k})`,
        `(${n - k}+${k})`,
        `(${k}*1+${n - k})`,
        // 3-term additive split: a + b - (a + b - n) == n
        // (inner term parenthesized: a bare negative would emit `--` = comment)
        `(${k}+${b}-(${k + b - n}))`,
        // subtract-back: k - (k - n) == n
        `(${k}-(${k - n}))`,
      ];
      if(n >= 0) {
        forms.push(
          `bit32.bxor(${(n ^ k) >>> 0},${k})`,
          // double-xor: bxor(bxor(n^j,k), j^k) == n
          `bit32.bxor(bit32.bxor(${(n ^ j) >>> 0},${k}),${(j ^ k) >>> 0})`,
        );
        if(n >= 256) {
          // shift/bor decomposition: bor(lshift(hi,8),lo) == n
          const hi = n >>> 8, lo = n & 255;
          forms.push(`bit32.bor(bit32.lshift(${hi},8),${lo})`);
        }
        return forms[Math.floor(rng() * forms.length)];
      }
      // Prefer non-bit32 forms for negative results (bit32 is unsigned)
      return forms[Math.floor(rng() * forms.length)];
    };
    function walk(node) {
      if(!node||typeof node!=='object')return;
      if(sealed.has(name)&&node.type==='AstExprConstantString'&&literals.has(node.location)) {
        const [a,b]=range(node.location),id=literalIds.get(literals.get(node.location).toString('base64'));
        edits.set(`${a}:${b}`,{start:a,end:b,text:`(${loopAliases.get(node.location)??`${literalPool}[${id}]`})`});return;
      }
      if(sealed.has(name)&&node.type==='AstExprConstantNumber'&&node.value!=null) {
        const enc = encodeNumber(Number(node.value));
        if(enc) {
          const [a,b]=range(node.location);
          edits.set(`${a}:${b}`,{start:a,end:b,text:enc});
          return;
        }
      }
      if(sealed.has(name)&&node.type==='AstExprConstantBool') {
        const [a,b]=range(node.location);
        const v = !!(node.value);
        const forms = v
          ? ['(1==1)','(0==0)','(true)','(not false)','(bit32.band(1,1)~=0)']
          : ['(1==0)','(0~=0)','(false)','(not true)','(bit32.band(1,0)~=0)'];
        edits.set(`${a}:${b}`,{start:a,end:b,text:forms[Math.floor(rng()*forms.length)]});
        return;
      }
      if(node.type==='AstLocal') {addLocal(node);return;}
      if(node.type==='AstExprLocal') {
        const text=addLocal(node.local),[a,b]=range(node.location);
        edits.set(`${a}:${b}`,{start:a,end:b,text});return;
      }
      for(const value of Object.values(node))if(Array.isArray(value))value.forEach(walk);else if(value&&typeof value==='object')walk(value);
    }
    walk(statement);
    if(sealed.has(name) && statement.body?.location) {
      try {
        const [bodyStart] = range(statement.body.location);
        const k = 3 + Math.floor(rng() * 200);
        const j = 1 + Math.floor(rng() * 50);
        // Always-false / always-true noise: zero effect on semantics, confuses linear reads
        const opaque = ` do local _o=${k} if bit32.bxor(_o,_o)~=0 then error(0) end if bit32.band(_o,0)~=0 then _o=${j} end end `;
        edits.set(`opaque:${bodyStart}`,{start:bodyStart,end:bodyStart,text:opaque});
      } catch (_) { /* ignore */ }
    }
    nativeNames.push(rename.get(statement.name.location));
    for(const comment of ast.commentLocations) {
      const [a,b]=range(comment.location);
      if(a>=start&&b<=end)edits.set(`${a}:${b}`,{start:a,end:b,text:''});
    }
    const chunks=[];let pos=start;
    for(const edit of [...edits.values()].sort((a,b)=>a.start-b.start||a.end-b.end)) {
      if(edit.start<pos)continue;
      chunks.push(source.subarray(pos,edit.start),Buffer.from(edit.text));pos=edit.end;
    }
    chunks.push(source.subarray(pos,end));
    declarations.push(Buffer.concat(chunks).toString());
    const arg=identifier();args.push(arg);
    replacements.push({start,end,text:`local ${name}=${arg}`});
  }
  const chunks=[];let pos=0;
  for(const edit of replacements.sort((a,b)=>a.start-b.start)) {chunks.push(source.subarray(pos,edit.start),Buffer.from(edit.text));pos=edit.end;}
  chunks.push(source.subarray(pos));
  const transformed=`return (function(${args.join(',')},...)\n${Buffer.concat(chunks).toString()}\nend)(...)\n`;
  const declarationOrder=Array.from({length:sealNames.length},(_,i)=>i);
  for(let i=declarationOrder.length-1;i>0;i--){const j=Math.floor(rng()*(i+1));[declarationOrder[i],declarationOrder[j]]=[declarationOrder[j],declarationOrder[i]];}
  return {transformed,declarations,nativeNames,entry:identifier(),literalStrings,literalPool,initializer,declarationOrder};
}
export function wrapNative(source,native) {
  const setup=native.literalStrings?.length?`local ${native.literalPool}\nlocal function ${native.initializer}(values) assert(${native.literalPool}==nil,0) ${native.literalPool}=table.freeze(values) end\n`:'';
  const order=native.declarationOrder?.length===native.declarations.length?native.declarationOrder:native.declarations.map((_,i)=>i);
  return `return (function(...)\n${setup}${order.map(i=>native.declarations[i]).join('\n')}\nlocal function ${native.entry}(...)\n${source}\nend\nreturn ${native.entry}(${[...(native.literalStrings?.length?[native.initializer]:[]),...native.nativeNames,'...'].join(',')})\nend)(...)\n`;
}

// Lift an explicitly marked, self-contained local value into the native wrapper.
// AST local references are checked against the original source before moving it.
export function prepareNativeRegions(input,markers,astExecutable) {
  const source=readFileSync(input),lineStarts=[0],regions=[];
  for(let i=0;i<source.length;i++)if(source[i]===10)lineStarts.push(i+1);
  const lines=lineStarts.map((start,i)=>({start,end:i+1<lineStarts.length?lineStarts[i+1]:source.length,
    text:source.subarray(start,i+1<lineStarts.length?lineStarts[i+1]:source.length).toString().trim()}));
  const position=location=>{
    const match=location?.match(/^(\d+),(\d+) - (\d+),(\d+)$/);
    if(!match)throw Error('Invalid AST location in native region');
    return [lineStarts[Number(match[1])]+Number(match[2]),lineStarts[Number(match[3])]+Number(match[4])];
  };
  const result=spawnSync(astExecutable,[input],{encoding:'utf8',maxBuffer:128*1024*1024,timeout:120000});
  if(result.error)throw result.error;
  if(result.status!==0)throw Error(result.stderr||result.stdout||'Luau AST parse failed');
  const ast=JSON.parse(result.stdout);
  for(const [index,spec] of markers.entries()) {
    if(!spec||spec.includes('\n')||spec.includes('\r'))throw Error('Invalid native region marker');
    const pieces=spec.split('@');
    if(pieces.length>2)throw Error('Invalid native region capture list');
    const marker=pieces[0],allowed=new Set(pieces[1]?.split(',').map(s=>s.trim())??[]);
    if(!marker||[...allowed].some(name=>!/^[A-Za-z_][A-Za-z_0-9]*$/.test(name)))throw Error('Invalid native region capture list');
    const begins=lines.filter(line=>line.text===`-- BEGIN ${marker}`);
    const ends=lines.filter(line=>line.text===`-- END ${marker}`);
    if(begins.length!==1||ends.length!==1||ends[0].start<=begins[0].end)
      throw Error(`--native-region ${marker}: expected one BEGIN/END comment pair`);
    const start=begins[0].end,end=ends[0].start,body=source.subarray(start,end).toString();
    const declaration=body.match(/^\s*local\s+([A-Za-z_][A-Za-z_0-9]*)\s*=/);
    if(!declaration)throw Error(`--native-region ${marker}: region must begin with a local value declaration`);
    let captured;
    const captures=new Map();
    function walk(node) {
      if(!node||typeof node!=='object')return;
      if(node.type==='AstExprLocal') {
        const [a,b]=position(node.location);
        if(a>=start&&b<=end) {
          const [defStart,defEnd]=position(node.local.location);
          if(defStart<start||defEnd>end) {
            if(!allowed.has(node.local.name)||defEnd>start)captured=node.local.name;
            else captures.set(node.local.name,node.local.location);
          }
        }
      }
      for(const value of Object.values(node))if(Array.isArray(value))value.forEach(walk);
      else if(value&&typeof value==='object')walk(value);
    }
    walk(ast.root);
    if(captured)throw Error(`--native-region ${marker}: captures outer local '${captured}'`);
    for(const name of allowed)if(!captures.has(name))throw Error(`--native-region ${marker}: unused capture '${name}'`);
    for(const [name,definition] of captures) {
      let reassigned=false,declarationOwner,hasInitializer=true,initialFunctionWrites=0;
      const declaration=(node,owner=null)=>{
        if(!node||typeof node!=='object')return;
        if(node.type==='AstExprFunction')owner=node;
        if(node.type==='AstStatLocal')for(const [i,local] of node.vars.entries())if(local.location===definition) {
          declarationOwner=owner;hasInitializer=Boolean(node.values?.[i]);
        }
        for(const value of Object.values(node))if(Array.isArray(value))value.forEach(v=>declaration(v,owner));
        else if(value&&typeof value==='object')declaration(value,owner);
      };
      declaration(ast.root);
      const writes=(node,owner=null,branchDepth=0)=>{
        if(!node||typeof node!=='object')return;
        if(node.type==='AstExprFunction'){owner=node;branchDepth=0;}
        if(['AstStatFor','AstStatForIn','AstStatWhile','AstStatRepeat','AstStatIf'].includes(node.type))branchDepth++;
        const targets=node.type==='AstStatAssign'?node.vars:
          node.type==='AstStatCompoundAssign'?[node.var]:
          node.type==='AstStatFunction'?[node.name]:[];
        for(const target of targets??[])if(target?.type==='AstExprLocal'&&target.local.location===definition) {
          const [writeAt]=position(node.location);
          // One straight-line local-function initialization is allowed for
          // `local dependency; function dependency(...) ... end`. A write in a
          // nested closure may run later even when its source is above the region.
          const initialization=node.type==='AstStatFunction'&&writeAt<start&&!hasInitializer&&owner===declarationOwner&&branchDepth===0;
          if(initialization)initialFunctionWrites++;
          else reassigned=true;
        }
        for(const value of Object.values(node))if(Array.isArray(value))value.forEach(v=>writes(v,owner,branchDepth));
        else if(value&&typeof value==='object')writes(value,owner,branchDepth);
      };
      writes(ast.root);
      if(reassigned||initialFunctionWrites>1)throw Error(`--native-region ${marker}: captured local '${name}' is reassigned after extraction or from another scope`);
    }
    const name=`__kz_native_region_${index}`;
    if(source.includes(Buffer.from(name)))throw Error(`--native-region ${marker}: internal name collision`);
    regions.push({marker,start,end,body,variable:declaration[1],name,captures:[...allowed]});
  }
  regions.sort((a,b)=>a.start-b.start);
  for(let i=1;i<regions.length;i++)if(regions[i].start<regions[i-1].end)throw Error('Native regions overlap');
  const parts=[],wrappers=[];let cursor=0;
  for(const region of regions) {
    parts.push(source.subarray(cursor,region.start),Buffer.from(`local ${region.variable}=${region.name}(${region.captures.join(',')})\n`));
    wrappers.push(`local function ${region.name}(${region.captures.join(',')})\n${region.body}\nreturn ${region.variable}\nend\n`);
    cursor=region.end;
  }
  parts.push(source.subarray(cursor));
  return {source:wrappers.join('')+Buffer.concat(parts).toString(),names:regions.map(r=>r.name),labels:regions.map(r=>r.marker)};
}
