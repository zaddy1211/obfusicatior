import {Writer} from './bytecode.js';
import {stream} from './aead.js';

export function packConstants(constants,key,id,tagMap,rng,shuffle) {
  const records=constants.map(({tag,value},index)=>{
    const writer=new Writer();
    if(tag===1)writer.u8(value);
    else if(tag===2||tag===7)writer.bytes(value);
    else if(tag===3||tag===6)writer.var(value);
    else if(tag===4)writer.u32(value);
    else if(tag===5){writer.var(value.length);value.forEach(n=>writer.var(n));}
    return {tag,index,raw:writer.finish()};
  });
  let length=0;const pieces=[];
  for(const record of shuffle(records,rng)){record.offset=length;pieces.push(record.raw);length+=record.raw.length;}
  const writer=new Writer();
  for(const record of records){writer.u8(tagMap[record.tag]);writer.var(record.offset);writer.var(record.raw.length);}
  const encrypted=stream(Buffer.concat(pieces),key,1,id);writer.var(encrypted.length);writer.bytes(encrypted);
  return writer.finish();
}
