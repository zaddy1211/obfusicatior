/**
 * KZ Codex 0.6 — AEAD + Key facade
 * Re-exports the staged key system and provides the classic seal/stream API.
 */
export {
  payloadKey,
  splitKey,
  combineShares,
  deriveProtoSubkey,
  deriveWindowKey,
  nonce,
  associatedData,
  seal,
  open,
  stream,
} from './key-material.js';
