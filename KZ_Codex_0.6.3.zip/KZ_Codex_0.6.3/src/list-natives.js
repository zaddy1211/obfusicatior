/**
 * List top-level local function names eligible for --native / --protect.
 * Prefers luau-ast when available; falls back to a conservative regex scan.
 */
import { readFileSync, existsSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { resolve } from 'node:path';
import { executable } from './build.js';

export function listTopLevelLocals(inputPath, { astExecutable } = {}) {
  const input = resolve(inputPath);
  const source = readFileSync(input);
  const text = source.toString('utf8');

  const astPath = astExecutable || executable('luau-ast');
  if (existsSync(astPath) || !String(astPath).includes('tools')) {
    try {
      const result = spawnSync(astPath, [input], {
        encoding: 'utf8',
        maxBuffer: 128 * 1024 * 1024,
        timeout: 120000,
      });
      if (!result.error && result.status === 0 && result.stdout) {
        const ast = JSON.parse(result.stdout);
        const names = [];
        for (const n of ast.root?.body || []) {
          if (n.type === 'AstStatLocalFunction' && n.name?.name) {
            names.push({
              name: n.name.name,
              location: n.location,
              kind: 'local-function',
            });
          }
        }
        return { method: 'ast', names };
      }
    } catch {
      /* fall through */
    }
  }

  // Conservative regex: top-level "local function Name(" only (column 0-ish)
  const names = [];
  const lines = text.split(/\r?\n/);
  const re = /^local\s+function\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(/;
  for (let i = 0; i < lines.length; i++) {
    const m = lines[i].match(re);
    if (m) names.push({ name: m[1], location: `${i + 1},1`, kind: 'local-function-regex' });
  }
  return { method: 'regex', names, note: 'Regex fallback — verify with luau-ast before production native marks' };
}

// CLI
if (import.meta.url === `file://${process.argv[1]?.replace(/\\/g, '/')}` ||
    process.argv[1]?.endsWith('list-natives.js')) {
  const input = process.argv[2];
  if (!input) {
    console.error('Usage: node src/list-natives.js <input.luau>');
    process.exit(1);
  }
  const result = listTopLevelLocals(input);
  console.log(`Method: ${result.method}`);
  if (result.note) console.log(`Note: ${result.note}`);
  console.log(`Candidates (${result.names.length}):`);
  for (const n of result.names) {
    console.log(`  --native ${n.name}`);
  }
  console.log('\nPick Smart Fit / trajectory / per-frame names from Script Profiler, then:');
  console.log(`node src/cli.js "${input}" -o output/protected.luau --profile fast -O 2 --vm-variants 1 --one-line --force \\`);
  console.log('  ' + result.names.slice(0, 5).map(n => `--native ${n.name}`).join(' ') + ' \\');
  console.log('  --report output/protected.report.json');
}
