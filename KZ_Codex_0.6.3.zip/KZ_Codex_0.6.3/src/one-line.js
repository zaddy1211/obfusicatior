// Collapse layout outside Luau literals. A physical newline inside a literal is
// rejected rather than rewriting a value or producing output that spans lines.
export function oneLine(source) {
  let output='',i=0;
  const appendLiteral=(end)=>{
    const literal=source.slice(i,end);
    if(/[\r\n]/.test(literal))throw Error('One-line output cannot preserve a multiline literal');
    output+=literal;i=end;
  };
  const longOpen=at=>{
    if(source[at]!=='[')return null;
    let j=at+1;
    while(source[j]==='=')j++;
    return source[j]==='['?{end:j+1,close:']'+source.slice(at+1,j)+']'}:null;
  };
  while(i<source.length) {
    const c=source[i];
    if(/\s/.test(c)) {
      while(i<source.length&&/\s/.test(source[i]))i++;
      if(output&&!output.endsWith(' '))output+=' ';
      continue;
    }
    if(c==='-'&&source[i+1]==='-') {
      const open=longOpen(i+2);
      if(open) {
        const end=source.indexOf(open.close,open.end);
        if(end<0)throw Error('Unterminated Luau block comment');
        appendLiteral(end+open.close.length);
      } else {
        i=source.indexOf('\n',i+2);
        if(i<0)break;
        if(output&&!output.endsWith(' '))output+=' ';
      }
      continue;
    }
    const open=longOpen(i);
    if(open) {
      const end=source.indexOf(open.close,open.end);
      if(end<0)throw Error('Unterminated Luau long string');
      appendLiteral(end+open.close.length);
      continue;
    }
    if(c==='\''||c==='"'||c==='`') {
      let end=i+1;
      for(;end<source.length;end++) {
        if(source[end]==='\\') {end++;continue;}
        if(source[end]===c) {end++;break;}
      }
      if(end>source.length||source[end-1]!==c)throw Error('Unterminated Luau string');
      appendLiteral(end);
      continue;
    }
    output+=c;i++;
  }
  return output.trim();
}
