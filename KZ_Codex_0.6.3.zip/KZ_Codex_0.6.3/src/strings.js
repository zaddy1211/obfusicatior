import {Writer} from './bytecode.js';
import {stream} from './aead.js';

// Preserve each string's fragment order in its reference list. The global
// fragment storage order is shuffled; references restore the original text.
export function packStrings(strings,key,rng,shuffle) {
  const fragments=[],references=[];
  for(const bytes of strings) {
    const parts=[];
    for(let offset=0;offset<bytes.length;) {
      const length=Math.min(bytes.length-offset,24+Math.floor(rng()*41));
      const part={bytes:bytes.subarray(offset,offset+length)};
      fragments.push(part);parts.push(part);offset+=length;
    }
    references.push(parts);
  }
  const ordered=shuffle(fragments,rng);
  let offset=0;
  ordered.forEach((p,i)=>{p.id=i+1;p.offset=offset;offset+=p.bytes.length;});
  const writer=new Writer();
  writer.var(references.length);
  for(const parts of references){writer.var(parts.length);for(const part of parts)writer.var(part.id);}
  writer.var(ordered.length);
  for(const part of ordered){writer.var(part.offset);writer.var(part.bytes.length);}
  const encrypted=stream(Buffer.concat(ordered.map(p=>p.bytes)),key,2,0);
  writer.var(encrypted.length);writer.bytes(encrypted);
  return {raw:writer.finish(),fragmentCount:ordered.length};
}
