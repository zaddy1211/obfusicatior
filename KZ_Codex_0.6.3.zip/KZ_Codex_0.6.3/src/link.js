// Link selected functions into one runtime. Each retains its own encoded
// prototypes and dispatch policy; loaders and cipher implementations are shared.
export function linkProtected(main,selected,nativeCount) {
  const program={...main,strings:[...main.strings],protos:main.protos.map(p=>({...p,heavy:false})),used:new Set(main.used),injections:[],nativeCount};
  const known=new Map(program.strings.map((s,i)=>[s.toString('base64'),i+1]));
  const groups=[];
  for(const {name,program:child} of selected) {
    const offset=program.protos.length;
    const strings=child.strings.map(s=>{const key=s.toString('base64');if(!known.has(key)){program.strings.push(s);known.set(key,program.strings.length);}return known.get(key);});
    for(const proto of child.protos)program.protos.push({...proto,heavy:true,protectionGroup:name,children:proto.children.map(i=>i+offset),constants:proto.constants.map(c=>({...c,value:c.tag===3?strings[c.value-1]:c.tag===6?c.value+offset:c.value}))});
    for(const op of child.used)program.used.add(op);
    const entry=offset+child.main;program.injections.push(entry);
    groups.push({name,entry:entry+1,prototypeIds:child.protos.map((_,i)=>offset+i+1)});
  }
  return {program,groups};
}
