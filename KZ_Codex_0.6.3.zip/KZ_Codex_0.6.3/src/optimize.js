import {OPS} from './bytecode.js';
import {instructions,leaders,successors,target,jumps} from './instructions.js';
const noop=new Set(['NOP','COVERAGE','PREPVARARGS','FASTCALL','FASTCALL1','FASTCALL2','FASTCALL2K','FASTCALL3']);
// Extended constant-fold table: ADD/SUB/MUL/DIV (integer-exact)/MOD/IDIV + unary
const arithmetic={
  ADD:(a,b)=>a+b,
  SUB:(a,b)=>a-b,
  MUL:(a,b)=>a*b,
  // DIV: fold only when result is an integer (no fractional part)
  DIV:(a,b)=>b!==0&&Number.isInteger(a/b)?a/b:undefined,
  MOD:(a,b)=>b!==0?((a%b)+b)%b:undefined,
  IDIV:(a,b)=>b!==0?Math.floor(a/b):undefined,
  // POW only for small non-negative integer exponents to avoid precision loss
  POW:(a,b)=>Number.isInteger(b)&&b>=0&&b<=10? a**b : undefined,
};
const exact=n=>n!==undefined&&Number.isInteger(n)&&!Object.is(n,-0)&&n>=-32768&&n<=32767;
export function optimize(program,{enabled=true}={}) {
  const stats={enabled,constantFolds:0,deadInstructions:0,redundantRegisterWrites:0,removedDispatchHints:0,wordsBefore:0,wordsAfter:0};
  const protos=program.protos.map(original=>{
    const p={...original,code:[...original.code]},list=instructions(p);stats.wordsBefore+=p.code.length;
    if(!enabled){stats.wordsAfter+=p.code.length;return p;}
    const starts=leaders(list),known=new Map(),remove=new Set();
    const number=index=>p.constants[index]?.tag===2?p.constants[index].value.readDoubleLE():undefined;
    for(const ins of list) {
      if(starts.has(ins.pc))known.clear();
      if(noop.has(ins.op)){remove.add(ins.pc);stats.removedDispatchHints++;continue;}
      if(ins.op==='MOVE'&&ins.a===ins.b){remove.add(ins.pc);stats.redundantRegisterWrites++;continue;}
      let value;
      if(ins.op==='LOADN')value=ins.d;
      else if(ins.op==='LOADK')value=number(ins.d);
      else if(ins.op==='MOVE')value=known.get(ins.b);
      else if(arithmetic[ins.op]||arithmetic[ins.op.slice(0,-1)]&&ins.op.endsWith('K')) {
        const opName=ins.op.endsWith('K')&&ins.op!=='IDIVK'?ins.op.slice(0,-1):ins.op;
        const operator=arithmetic[opName]??arithmetic[ins.op];
        if(operator) {
          const left=known.get(ins.b),right=ins.op.endsWith('K')?number(ins.c):known.get(ins.c);
          if(exact(left)&&exact(right)) {
            const result=operator(left,right);
            if(exact(result)){value=result;ins.op='LOADN';ins.word=(OPS.indexOf('LOADN')|(ins.a<<8)|((result&65535)<<16))>>>0;stats.constantFolds++;}
          } else known.clear();
        } else {known.clear();continue;}
      } else {known.clear();continue;}
      if(value!==undefined&&exact(value)) {
        if(known.has(ins.a)&&Object.is(known.get(ins.a),value)){remove.add(ins.pc);stats.redundantRegisterWrites++;}
        known.set(ins.a,value);
      } else known.delete(ins.a);
    }
    const byPC=new Map(list.map(ins=>[ins.pc,ins])),reachable=new Set(),queue=[0];
    while(queue.length) {
      const pc=queue.pop();if(reachable.has(pc))continue;
      const ins=byPC.get(pc);if(!ins)throw Error(`Invalid control-flow target ${pc}`);
      reachable.add(pc);for(const next of successors(ins))queue.push(next);
    }
    for(const ins of list)if(!reachable.has(ins.pc)){remove.add(ins.pc);stats.deadInstructions++;}
    const kept=list.filter(ins=>!remove.has(ins.pc)),map=new Map();let length=0;
    for(const ins of kept){map.set(ins.pc,length);length+=ins.size;}
    let next=length;for(let i=list.length-1;i>=0;i--){if(map.has(list[i].pc))next=map.get(list[i].pc);else map.set(list[i].pc,next);}
    p.code=[];
    for(const ins of kept) {
      let word=ins.word;const to=target(ins);
      if(to!==undefined) {
        const delta=map.get(to)-map.get(ins.pc)-1;
        if(!Number.isInteger(delta))throw Error('Optimizer lost a jump target');
        if(jumps.has(ins.op)){if(delta<-32768||delta>32767)throw Error('Optimizer jump overflow');word=((word&65535)|((delta&65535)<<16))>>>0;}
        else if(ins.op==='JUMPX')word=((word&255)|((delta&16777215)<<8))>>>0;
        else {if(delta<0||delta>255)throw Error('Optimizer skip overflow');word=((word&16777215)|(delta<<24))>>>0;}
      }
      p.code.push(word);if(ins.size===2)p.code.push(ins.aux);
    }
    stats.wordsAfter+=p.code.length;return p;
  });
  const used=new Set(protos.flatMap(p=>instructions(p).map(i=>i.op)));
  return {program:{...program,protos,used},stats};
}
