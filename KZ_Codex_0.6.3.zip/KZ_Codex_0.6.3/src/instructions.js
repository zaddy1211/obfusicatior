import {OPS,AUX} from './bytecode.js';
export const jumps=new Set(`JUMP JUMPBACK JUMPIF JUMPIFNOT JUMPIFEQ JUMPIFLE JUMPIFLT JUMPIFNOTEQ JUMPIFNOTLE JUMPIFNOTLT FORNPREP FORNLOOP FORGLOOP FORGPREP FORGPREP_NEXT FORGPREP_INEXT JUMPXEQKNIL JUMPXEQKB JUMPXEQKN JUMPXEQKS`.split(' '));
const unconditional=new Set(['JUMP','JUMPBACK','JUMPX','FORGPREP','FORGPREP_NEXT','FORGPREP_INEXT']);
export function instructions(p) {
  const result=[];
  for(let pc=0;pc<p.code.length;) {
    const word=p.code[pc],op=OPS[word&255],size=AUX.has(op)?2:1;
    result.push({pc,word,op,size,a:(word>>>8)&255,b:(word>>>16)&255,c:word>>>24,d:word>>16,e:word>>8,aux:size===2?p.code[pc+1]:undefined});pc+=size;
  }
  return result;
}
export function target(ins) {
  if(jumps.has(ins.op))return ins.pc+1+ins.d;
  if(ins.op==='JUMPX')return ins.pc+1+ins.e;
  if(ins.op==='LOADB'&&ins.c)return ins.pc+1+ins.c;
}
export function successors(ins) {
  if(ins.op==='RETURN')return [];
  const to=target(ins);
  if(unconditional.has(ins.op)||(ins.op==='LOADB'&&ins.c))return [to];
  return to===undefined?[ins.pc+ins.size]:[to,ins.pc+ins.size];
}
export function leaders(list) {
  const result=new Set([0]);
  for(const ins of list)if(target(ins)!==undefined||ins.op==='RETURN') {for(const pc of successors(ins))result.add(pc);result.add(ins.pc+ins.size);}
  return result;
}
