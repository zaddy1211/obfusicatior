export function xorshift(s) { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return s >>> 0; }
export function encode85(data, alphabet) {
  let result='';
  for (let i=0;i<data.length;i+=4) {
    let n=data.readUInt32LE(i); const chars=Array(5);
    for(let j=4;j>=0;j--) { chars[j]=alphabet[n%85]; n=Math.floor(n/85); }
    result+=chars.join('');
  }
  return result;
}
// Bounded hash-chain LZSS: groups of 8 tokens, 16-bit distance, 8-bit length.
// Bounded search keeps build time predictable.
export function compress(data) {
  const heads=new Map(), previous=new Int32Array(data.length).fill(-1), out=[];
  const hash=i=>data[i]*65536+data[i+1]*256+data[i+2];
  const add=i=>{ if(i+2>=data.length)return; const h=hash(i); previous[i]=heads.get(h)??-1; heads.set(h,i); };
  let pos=0;
  while(pos<data.length) {
    const fi=out.length;out.push(0);let flags=0;
    for(let bit=0;bit<8&&pos<data.length;bit++) {
      let best=0,distance=0;
      if(pos+3<data.length) {
        let candidate=heads.get(hash(pos))??-1;
        for(let chain=0;candidate>=0&&pos-candidate<=65535&&chain<128;chain++,candidate=previous[candidate]) {
          let n=0;while(n<258&&pos+n<data.length&&data[candidate+n]===data[pos+n])n++;
          if(n>best) {best=n;distance=pos-candidate;if(n===258)break;}
        }
      }
      if(best>=4) { flags|=1<<bit;out.push(distance&255,distance>>>8,best-3);for(let n=0;n<best;n++)add(pos++); }
      else {out.push(data[pos]);add(pos++);}
    }
    out[fi]=flags;
  }
  return Buffer.from(out);
}
