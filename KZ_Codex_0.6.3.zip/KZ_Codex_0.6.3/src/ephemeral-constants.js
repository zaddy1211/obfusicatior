/**
 * KZ Codex 0.6 — Ephemeral Constant Window System
 *
 * Instead of decoding every constant into a long-lived table that can be
 * dumped in one shot, we keep a small rotating window of live values.
 *
 * Design goals:
 * - A single memory dump only ever sees a handful of decoded constants.
 * - Window is wiped on function return / after N accesses.
 * - Fast path for the most recent values (performance).
 * - Compatible with the existing constant tag / offset / length metadata.
 */

/**
 * Configuration for the constant window.
 * Tunable so we can stay inside the size budget.
 */
export const DEFAULT_WINDOW = {
  size: 12,          // max live decoded constants at once
  wipeEvery: 64,     // wipe the whole window after this many accesses
  clearOnReturn: true,
};

/**
 * Build-time helper: decide which constants of a prototype should be
 * marked as "windowed" (ephemeral) vs pre-decoded (fast path).
 *
 * Heavy / protected prototypes → almost everything windowed.
 * Ordinary prototypes → only large or sensitive constants windowed.
 */
export function classifyConstants(proto, profile = 'balanced') {
  const windowed = new Set();
  const predecoded = new Set();

  for (let i = 0; i < proto.constants.length; i++) {
    const c = proto.constants[i];
    const tag = c.tag; // 0=nil, 1=bool, 2=number, 3/6=integer, 4=import, 5=table keys, 7=vector

    // Always window large structures and strings (handled separately)
    if (tag === 5) {
      windowed.add(i);
      continue;
    }

    if (profile === 'max' || proto.heavy) {
      // Almost everything goes through the window
      if (tag === 2 || tag === 3 || tag === 6 || tag === 7) {
        windowed.add(i);
      } else {
        predecoded.add(i); // nil / bool can stay cheap
      }
    } else if (profile === 'heavy') {
      if (tag === 2 || tag === 7) windowed.add(i);
      else predecoded.add(i);
    } else {
      // balanced / fast – keep most numbers fast, window only selected ones
      predecoded.add(i);
    }
  }

  return { windowed, predecoded };
}

/**
 * Generate the Luau source fragment that implements the ephemeral window
 * for a single prototype.  This is injected into the runtime.
 *
 * The generated code is intentionally compact to stay inside size budget.
 */
export function emitWindowRuntime(windowConfig = DEFAULT_WINDOW) {
  const { size, wipeEvery, clearOnReturn } = windowConfig;

  // Compact, mangled-friendly implementation
  return `
-- Ephemeral constant window (KZ 0.6)
local function makeWindow(p)
  local slots = table.create(${size})
  local ages  = table.create(${size}, 0)
  local nextAge = 1
  local accesses = 0
  local function wipe()
    for i = 1, ${size} do
      slots[i] = nil
      ages[i] = 0
    end
    nextAge = 1
    accesses = 0
  end
  local function lookup(index)
    accesses = accesses + 1
    if accesses >= ${wipeEvery} then wipe() end
    for i = 1, ${size} do
      if ages[i] ~= 0 and slots[i] and slots[i].idx == index then
        ages[i] = nextAge
        nextAge = nextAge + 1
        return slots[i].val
      end
    end
    return nil
  end
  local function insert(index, value)
    -- find free or oldest slot
    local best, bestAge = 1, ages[1]
    for i = 2, ${size} do
      if ages[i] == 0 then best = i; break end
      if ages[i] < bestAge then best, bestAge = i, ages[i] end
    end
    slots[best] = { idx = index, val = value }
    ages[best] = nextAge
    nextAge = nextAge + 1
    return value
  end
  return {
    get = function(index, decoder)
      local hit = lookup(index)
      if hit ~= nil then return hit end
      local value = decoder(index)
      return insert(index, value)
    end,
    wipe = wipe,
    ${clearOnReturn ? 'clearOnReturn = true,' : ''}
  }
end
`.trim();
}

/**
 * Size estimate helper so the build can decide whether to enable
 * full windowing or fall back to lighter protection.
 */
export function estimateWindowOverhead(protoCount, avgConstants, config = DEFAULT_WINDOW) {
  // Rough bytes added to the emitted runtime
  const runtimeCode = 420; // approximate size of makeWindow + helpers
  const perProto = 48;     // window object + a few fields
  return runtimeCode + protoCount * perProto;
}
