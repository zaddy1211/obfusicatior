import {shuffle} from './segments.js';

export function dispatchTree(entries,rng,fast=false) {
  if(entries.length===1)return entries[0][1]||'do end';
  const mid=Math.max(1,Math.min(entries.length-1,Math.floor(entries.length*(.35+rng()*.3))));
  const low=dispatchTree(entries.slice(0,mid),rng,fast),high=dispatchTree(entries.slice(mid),rng,fast);
  // Vary tree shape: plain if/else, nested bit32, or arithmetic guard
  const style=Math.floor(rng()*3);
  if(fast||style===0) return rng()<.5?`if op<${entries[mid][0]} then ${low} else ${high} end`:`if op>=${entries[mid][0]} then ${high} else ${low} end`;
  if(style===1) return `if bit32.band(op,255)<${entries[mid][0]} then ${low} else ${high} end`;
  return `if bit32.rshift(op,0)<${entries[mid][0]} then ${low} else ${high} end`;
}

export function dispatch(entries,rng,style,fast=false) {
  if(style==='inline')return {declarations:'',body:dispatchTree([...entries].sort((a,b)=>a[0]-b[0]),rng,fast),blocks:0};
  if(style==='table')return {
    declarations:'local helpers={}\n'+shuffle(entries,rng).map(([op,body])=>`helpers[${op}]=function(ins,op,a,b,c,d,e) ${body||'do end'} end`).join('\n')+'\ntable.freeze(helpers)',
    body:'local outcome=helpers[op](ins,op,a,b,c,d,e) if outcome~=nil then return outcome end',
    blocks:entries.length
  };
  // 'blocks' style: split into 3-6 groups, each with its own dispatch tree
  const count=3+Math.floor(rng()*4),groups=Array.from({length:count},()=>[]);
  for(const entry of entries)groups[entry[0]%count].push(entry);
  const order=shuffle(groups.map((group,id)=>({group,id})),rng);
  const declarations='local helpers={}\n'+order.map(({group,id})=>`helpers[${id}]=function(ins,op,a,b,c,d,e) ${group.length?dispatchTree(group.sort((a,b)=>a[0]-b[0]),rng,fast):"error('KZ Codex: invalid dispatch',0)"} end`).join('\n')+'\ntable.freeze(helpers)';
  return {declarations,body:`local outcome=helpers[op%${count}](ins,op,a,b,c,d,e) if outcome~=nil then return outcome end`,blocks:count};
}

// Reorder decoder stages randomly
export function reorderDecoder(template,rng) {
  const start=template.indexOf('decodeStages['),end=template.indexOf('table.freeze(decodeStages)');
  const chunks=template.slice(start,end).match(/decodeStages\[@[A-Z0-9]+@\]=function\(frame\)[\s\S]*?\nend\n/g);
  if(chunks?.length!==4)throw Error('Decoder stage template changed');
  return template.slice(0,start)+shuffle(chunks,rng).join('')+template.slice(end);
}

// Exercise every emitted dispatch style, not just the inline implementation.
export function probes(opcodes,used,slots,rng,modes=[0]) {
  const x=2+Math.floor(rng()*31),y=2+Math.floor(rng()*7),z=1+Math.floor(rng()*5);
  const cases={ADD:x+y,SUB:x-y,MUL:x*y,DIV:x/y,MOD:x%y,POW:x**y,IDIV:Math.floor(x/y),MOVE:x,MINUS:-x,NOT:false,LOADN:z,LOADB:true,LOADNIL:null};
  const record=fields=>'{'+slots.map(index=>fields[index]).join(',')+'}';;
  const chosen=shuffle(Object.keys(cases).filter(op=>used.includes(op)),rng);
  if(!used.includes('RETURN'))return {source:'',count:0};
  const source=chosen.flatMap(op=>modes.flatMap(mode=>[2,0].map(destination=>{
    const ins=[opcodes[op],destination,0,1,0,0];
    if(op==='LOADN')ins[4]=z;
    if(op==='LOADB'){ins[2]=1;ins[3]=0;}
    const expected=cases[op]===null?'nil':String(cases[op]);
    return `do local probe={loaded=true,dispatchMode=${mode},params=2,ups=0,vararg=0,captures=false,words=2,codeSection=0,constantSection=0,seal=0,pool={},values={},code={${record(ins)},${record([opcodes.RETURN,destination,2,0,0,0])}}} local probeResult={} run(probe,{},getfenv(0),nil,probeResult,1,1,{${x},${y}},1,2) assert(probeResult[1]==${expected},'KZ Codex: handler integrity failed') end`;
  }))).join('\n');
  return {source,count:chosen.length*modes.length*2};
}
