import {instructions,leaders,target} from './instructions.js';
const unsafe=new Set(`BREAK NATIVECALL NEWCLOSURE DUPCLOSURE CAPTURE CLOSEUPVALS FORNPREP FORNLOOP FORGLOOP FORGPREP FORGPREP_NEXT FORGPREP_INEXT JUMP JUMPBACK JUMPX JUMPIF JUMPIFNOT JUMPIFEQ JUMPIFLE JUMPIFLT JUMPIFNOTEQ JUMPIFNOTLE JUMPIFNOTLT JUMPXEQKNIL JUMPXEQKB JUMPXEQKN JUMPXEQKS LOADB`.split(' '));
export function fuse(program,{enabled=true,rng=()=>.5,maxKinds=56,maxSpan=8}={}) {
  const positions=program.protos.map(()=>new Map());
  if(!enabled)return {groups:[],positions,count:0,instructionsFused:0,dispatchesSaved:0};
  const candidates=[],patterns=new Map();
  for(let pi=0;pi<program.protos.length;pi++) {
    const list=instructions(program.protos[pi]),starts=leaders(list);
    const loops=list.map(i=>[target(i),i.pc]).filter(([t,pc])=>t!==undefined&&t<=pc);
    for(let i=0;i<list.length;i++) {
      const sequence=[];
      for(let j=i;j<Math.min(list.length,i+maxSpan);j++) {
        const ins=list[j];if(unsafe.has(ins.op)||(j>i&&starts.has(ins.pc)))break;
        sequence.push({op:ins.op,...(ins.op==='CALL'?{b:ins.b,c:ins.c}:{})});
        if(sequence.length>=2||ins.op==='CALL') {
          const signature=sequence.map(x=>x.op+(x.op==='CALL'?`:${x.b}:${x.c}`:'')).join('/');
          const hot=(loops.some(([from,to])=>list[i].pc>=from&&list[i].pc<=to)?8:1)*(program.protos[pi].heavy?3:1);
          const item={pi,start:list[i].pc,end:ins.pc+ins.size,sequence:[...sequence],signature,hot};candidates.push(item);
          const pattern=patterns.get(signature)??{frequency:0,weight:0,sequence:item.sequence,tie:rng()};
          pattern.frequency++;pattern.weight+=hot;patterns.set(signature,pattern);
        }
        if(ins.op==='RETURN')break;
      }
    }
  }
  const ranked=[...patterns].map(([signature,p])=>({signature,...p,score:p.weight*(p.sequence.length-1+p.sequence.filter(i=>i.op==='CALL').length*2)/(1+p.sequence.length*.08)})).sort((a,b)=>b.score-a.score||a.tie-b.tie);
  const occupied=program.protos.map(()=>new Set()),groups=[];let count=0,instructionsFused=0,dispatchesSaved=0;
  const bySignature=new Map();for(const c of candidates){if(!bySignature.has(c.signature))bySignature.set(c.signature,[]);bySignature.get(c.signature).push(c);}
  for(const pattern of ranked) {
    if(groups.length>=maxKinds)break;
    const available=bySignature.get(pattern.signature).filter(c=>{for(let i=c.start;i<c.end;i++)if(occupied[c.pi].has(i))return false;return true;});
    if(!available.length)continue;
    const group={name:'KZ_FUSE_'+groups.length,ops:pattern.sequence.map(i=>i.op),sequence:pattern.sequence,frequency:0};
    for(const c of available) {
      let overlap=false;for(let i=c.start;i<c.end;i++)if(occupied[c.pi].has(i)){overlap=true;break;}
      if(overlap)continue;
      positions[c.pi].set(c.start,group.name);for(let i=c.start;i<c.end;i++)occupied[c.pi].add(i);
      group.frequency++;count++;instructionsFused+=c.sequence.length;dispatchesSaved+=c.sequence.length-1;
    }
    if(group.frequency)groups.push(group);
  }
  return {groups,positions,count,instructionsFused,dispatchesSaved};
}
