// Luau 0.694 bytecode v6 adapter. Opcode/format definitions follow Luau (MIT),
// Copyright (c) Roblox Corporation. See THIRD_PARTY_NOTICES.md.
// The output serializer is an independently implemented KZ format.
export const OPS = `NOP BREAK LOADNIL LOADB LOADN LOADK MOVE GETGLOBAL SETGLOBAL GETUPVAL SETUPVAL CLOSEUPVALS GETIMPORT GETTABLE SETTABLE GETTABLEKS SETTABLEKS GETTABLEN SETTABLEN NEWCLOSURE NAMECALL CALL RETURN JUMP JUMPBACK JUMPIF JUMPIFNOT JUMPIFEQ JUMPIFLE JUMPIFLT JUMPIFNOTEQ JUMPIFNOTLE JUMPIFNOTLT ADD SUB MUL DIV MOD POW ADDK SUBK MULK DIVK MODK POWK AND OR ANDK ORK CONCAT NOT MINUS LENGTH NEWTABLE DUPTABLE SETLIST FORNPREP FORNLOOP FORGLOOP FORGPREP_INEXT FASTCALL3 FORGPREP_NEXT NATIVECALL GETVARARGS DUPCLOSURE PREPVARARGS LOADKX JUMPX FASTCALL COVERAGE CAPTURE SUBRK DIVRK FASTCALL1 FASTCALL2 FASTCALL2K FORGPREP JUMPXEQKNIL JUMPXEQKB JUMPXEQKN JUMPXEQKS IDIV IDIVK`.split(' ');
export const AUX = new Set(`GETGLOBAL SETGLOBAL GETIMPORT GETTABLEKS SETTABLEKS NAMECALL JUMPIFEQ JUMPIFLE JUMPIFLT JUMPIFNOTEQ JUMPIFNOTLE JUMPIFNOTLT NEWTABLE SETLIST FORGLOOP FASTCALL3 LOADKX FASTCALL2 FASTCALL2K JUMPXEQKNIL JUMPXEQKB JUMPXEQKN JUMPXEQKS`.split(' '));
export class Reader {
  constructor(data) { this.data = data; this.pos = 0; }
  take(n) { if (n < 0 || this.pos + n > this.data.length) throw Error('Truncated bytecode'); const v = this.data.subarray(this.pos, this.pos + n); this.pos += n; return v; }
  u8() { return this.take(1)[0]; }
  u32() { return this.take(4).readUInt32LE(); }
  var() { let n = 0, shift = 0; for (let i = 0; i < 5; i++) { const b = this.u8(); n += (b & 127) * 2 ** shift; if (!(b & 128)) return n; shift += 7; } throw Error('Invalid varint'); }
}
export class Writer {
  constructor() { this.parts = []; }
  bytes(b) { this.parts.push(Buffer.from(b)); }
  u8(n) { this.bytes([n]); }
  u32(n) { const b = Buffer.alloc(4); b.writeUInt32LE(n >>> 0); this.bytes(b); }
  var(n) { do { const b = n % 128; n = Math.floor(n / 128); this.u8(b | (n ? 128 : 0)); } while (n); }
  finish() { return Buffer.concat(this.parts); }
}
export function parse(data) {
  const r = new Reader(data), version = r.u8();
  if (version === 0) throw Error(data.subarray(1).toString());
  if (version !== 6) throw Error(`Unsupported bytecode version ${version}; run npm run setup (Luau 0.694)`);
  if (r.u8() !== 3) throw Error('Unsupported type metadata version');
  const strings = Array.from({length:r.var()}, () => Buffer.from(r.take(r.var())));
  while (r.u8() !== 0) r.var();
  const protos = Array.from({length:r.var()}, () => {
    const stack = r.u8(), params = r.u8(), ups = r.u8(), vararg = r.u8();
    r.u8(); r.take(r.var());
    const code = Array.from({length:r.var()}, () => r.u32());
    const constants = Array.from({length:r.var()}, () => {
      const tag = r.u8(); let value;
      if (tag === 1) value = r.u8();
      else if (tag === 2) value = Buffer.from(r.take(8));
      else if (tag === 3 || tag === 6) value = r.var();
      else if (tag === 4) value = r.u32();
      else if (tag === 5) value = Array.from({length:r.var()}, () => r.var());
      else if (tag === 7) value = Buffer.from(r.take(16));
      else if (tag !== 0) throw Error(`Unknown constant tag ${tag}`);
      return {tag,value};
    });
    const children = Array.from({length:r.var()}, () => r.var());
    r.var(); r.var();
    if (r.u8()) { const gap = r.u8(); r.take(code.length); r.take(((code.length - 1) >>> gap) * 4 + 4); }
    if (r.u8()) { for (let i = r.var(); i > 0; i--) { r.var(); r.var(); r.var(); r.u8(); } for (let i = r.var(); i > 0; i--) r.var(); }
    return {stack,params,ups,vararg,code,constants,children};
  });
  const main = r.var();
  if (r.pos !== data.length || !protos[main]) throw Error('Invalid bytecode trailer');
  const used = new Set();
  for (const p of protos) for (let i = 0; i < p.code.length; i++) {
    const op = OPS[p.code[i] & 255];
    if (!op || ['BREAK','NATIVECALL'].includes(op)) throw Error(`Unsupported instruction ${op}`);
    used.add(op); if (AUX.has(op)) i++;
  }
  return {strings,protos,main,used};
}
export function serialize(program, config) {
  const w = new Writer();
  w.var(program.strings.length);
  program.strings.forEach((s,i) => { w.var(s.length); w.bytes(s.map((b,j) => b ^ ((config.stringKey + (i+1)*17 + j*config.stringStep) & 255))); });
  w.var(program.protos.length);
  for (let pi=0;pi<program.protos.length;pi++) {
    const p=program.protos[pi];
    let captures=false;
    for(let j=0;j<p.code.length;j++) {const op=OPS[p.code[j]&255];if(['NEWCLOSURE','DUPCLOSURE','CLOSEUPVALS'].includes(op))captures=true;if(AUX.has(op))j++;}
    w.u8(p.params); w.u8(p.ups); w.u8(p.vararg|(captures?2:0)); w.var(p.code.length);
    for (let i = 0; i < p.code.length; i++) {
      const word = p.code[i], op = OPS[word & 255];
      const effective=config.fusion?.positions[pi].get(i)??op;
      const bytes = [config.opcodes[effective], (word >>> 8)&255, (word >>> 16)&255, word >>> 24];
      let transformed = 0;
      for (let j = 0; j < 4; j++) transformed = (transformed | (bytes[j] << (config.layout[j]*8))) >>> 0;
      w.u32(transformed);
      if (AUX.has(op)) w.u32((p.code[++i] ^ config.auxKey) >>> 0);
    }
    w.var(p.constants.length);
    for (const {tag,value} of p.constants) {
      w.u8(tag);
      if (tag === 1) w.u8(value);
      else if (tag === 2 || tag === 7) w.bytes(value);
      else if (tag === 3 || tag === 6) w.var(value);
      else if (tag === 4) w.u32(value);
      else if (tag === 5) { w.var(value.length); value.forEach(v => w.var(v)); }
    }
    w.var(p.children.length); p.children.forEach(v => w.var(v));
  }
  w.var(program.main);
  return w.finish();
}
