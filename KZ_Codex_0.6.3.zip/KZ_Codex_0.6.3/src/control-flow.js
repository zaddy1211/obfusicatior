import {OPS} from './bytecode.js';
import {instructions,leaders,target,jumps} from './instructions.js';
import {shuffle} from './segments.js';

// Split and relocate basic blocks, preserving AUX words and capture groups.
export function flatten(program,rng,{heavyOnly=false}={}) {
  let blockCount=0,insertedJumps=0;
  const protos=program.protos.map(p=>{
    if(heavyOnly&&!p.heavy)return p;
    const isHeavy=p.heavy||!heavyOnly;
    // Block size range: heavy uses smaller blocks for more fragmentation
    const minBlock=isHeavy?4:8,maxExtra=isHeavy?12:25;
    const list=instructions(p),starts=leaders(list),blocks=[];
    let block=[];
    for(const ins of list) {
      if(block.length&&ins.op!=='CAPTURE'&&(starts.has(ins.pc)||block.length>=minBlock+Math.floor(rng()*maxExtra))) {
        blocks.push(block);block=[];
      }
      block.push(ins);
    }
    if(block.length)blocks.push(block);
    if(blocks.length<2)return p;
    blockCount+=blocks.length;
    const code=[OPS.indexOf('JUMPX')],map=new Map(),fixes=[{at:0,to:0}];insertedJumps++;
    const appendJump=to=>{fixes.push({at:code.length,to});code.push(OPS.indexOf('JUMPX'));insertedJumps++;};
    // Shuffle blocks — in heavy mode, shuffle more aggressively with multiple passes
    let shuffled=shuffle(blocks,rng);
    if(isHeavy) shuffled=shuffle(shuffled,rng);
    for(const body of shuffled) {
      for(const ins of body) {
        map.set(ins.pc,code.length);let word=ins.word;
        const to=target(ins);
        if(to!==undefined) {
          if(ins.op==='JUMPX')fixes.push({at:code.length,to});
          else if(jumps.has(ins.op))word=((word&65535)|(ins.size<<16))>>>0;
          else word=((word&16777215)|(ins.size<<24))>>>0;
        }
        code.push(word);if(ins.size===2)code.push(ins.aux);
      }
      const last=body.at(-1),to=target(last),next=last.pc+last.size;
      if(to!==undefined&&last.op!=='JUMPX'){appendJump(next<p.code.length?next:to);appendJump(to);}
      else if(to===undefined&&last.op!=='RETURN')appendJump(next);
    }
    for(const {at,to} of fixes) {
      if(!map.has(to))throw Error('Control-flow pass lost a target');
      const delta=map.get(to)-at-1;
      if(delta<-8388608||delta>8388607)throw Error('Control-flow jump overflow');
      code[at]=(OPS.indexOf('JUMPX')|((delta&16777215)<<8))>>>0;
    }
    return {...p,code};
  });
  return {program:{...program,protos,used:new Set(protos.flatMap(p=>instructions(p).map(ins=>ins.op)))},stats:{blocks:blockCount,insertedJumps}};
}
