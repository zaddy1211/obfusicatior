export const handlers = {
  NOP:'', COVERAGE:'', PREPVARARGS:'', FASTCALL:'', FASTCALL1:'',
  FASTCALL2:'pc=pc+1', FASTCALL2K:'pc=pc+1', FASTCALL3:'pc=pc+1',
  LOADNIL:'r[a]=nil', LOADB:'r[a]=b~=0 pc=pc+c', LOADN:'r[a]=d',
  LOADK:'r[a]=constant(p,d)', LOADKX:'r[a]=constant(p,code[pc]) pc=pc+1', MOVE:'r[a]=r[b]',
  GETGLOBAL:'env=hostGetfenv(current) r[a]=env[constant(p,code[pc])] pc=pc+1',
  SETGLOBAL:'env=hostGetfenv(current) env[constant(p,code[pc])]=r[a] pc=pc+1',
  GETUPVAL:'local cell=uv[b+1] r[a]=cell[1][cell[2]]',
  SETUPVAL:'local cell=uv[b+1] cell[1][cell[2]]=r[a]',
  CLOSEUPVALS:'close(a)',
  GETIMPORT:`env=hostGetfenv(current) local id=code[pc] pc=pc+1 local count=bit32.rshift(id,30)
    local value=env[constant(p,bit32.band(bit32.rshift(id,20),1023))]
    if count>1 then value=value[constant(p,bit32.band(bit32.rshift(id,10),1023))] end
    if count>2 then value=value[constant(p,bit32.band(id,1023))] end r[a]=value`,
  GETTABLE:'r[a]=r[b][r[c]]', SETTABLE:'r[b][r[c]]=r[a]',
  GETTABLEKS:'r[a]=r[b][constant(p,bit32.band(code[pc],16777215))] pc=pc+1',
  SETTABLEKS:'r[b][constant(p,bit32.band(code[pc],16777215))]=r[a] pc=pc+1',
  GETTABLEN:'r[a]=r[b][c+1]', SETTABLEN:'r[b][c+1]=r[a]',
  NAMECALL:'local receiver=r[b] r[a+1]=receiver r[a]=receiver[constant(p,bit32.band(code[pc],16777215))] pc=pc+1',
  NEWCLOSURE:'env=hostGetfenv(current) local child=protos[childAt(p,d+1)] local captures={} r[a]=make(child,captures,env) capture(child,captures,false)',
  DUPCLOSURE:`env=hostGetfenv(current) local child=protos[rawConstant(p,d+1)+1] local captures={}
    local fn=make(child,captures,env) r[a]=fn capture(child,captures,true)
    local previous=p.cache[d]
    if previous then
      local same=hostGetfenv(previous.fn)==env
      for i=1,child.ups do local x,y=captures[i],previous.uv[i] if not rawequal(x[1][x[2]],y[1][y[2]]) then same=false break end end
      if same then r[a]=previous.fn end
    end
    if not previous then p.cache[d]={env=env,uv=captures,fn=fn} end`,
  CALL:`local argc=b-1 if b==0 then argc=top-a-1 end
    local results=table.pack(r[a](table.unpack(r,a+1,a+argc)))
    local count=c-1 if c==0 then count=results.n top=a+count end
    for i=1,count do r[a+i-1]=results[i] end`,
  RETURN:'local count=b-1 if b==0 then count=top-a end close(0) return table.unpack(r,a,a+count-1)',
  JUMP:'pc=pc+d', JUMPBACK:'pc=pc+d', JUMPX:'pc=pc+e',
  JUMPIF:'if r[a] then pc=pc+d end', JUMPIFNOT:'if not r[a] then pc=pc+d end',
  CONCAT:'local value=r[c] for i=c-1,b,-1 do value=r[i]..value end r[a]=value',
  NOT:'r[a]=not r[b]', MINUS:'r[a]=-r[b]', LENGTH:'r[a]=#r[b]',
  NEWTABLE:'r[a]=table.create(code[pc]) pc=pc+1',
  DUPTABLE:'local value={} local keys=rawConstant(p,d+1) for _,key in keys do value[constant(p,key)]=0 end table.clear(keys) r[a]=value',
  SETLIST:'local index=code[pc] pc=pc+1 local count=c-1 if c==0 then count=top-b end for i=0,count-1 do r[a][index+i]=r[b+i] end',
  FORNPREP:`r[a]=assert(tonumber(r[a]),'KZ Codex: invalid loop limit') r[a+1]=assert(tonumber(r[a+1]),'KZ Codex: invalid loop step') r[a+2]=assert(tonumber(r[a+2]),'KZ Codex: invalid loop start')
    if not (if r[a+1]>0 then r[a+2]<=r[a] else r[a]<=r[a+2]) then pc=pc+d end`,
  FORNLOOP:'r[a+2]=r[a+2]+r[a+1] if (if r[a+1]>0 then r[a+2]<=r[a] else r[a]<=r[a+2]) then pc=pc+d end',
  FORGPREP:`local generator=r[a]
    if type(generator)~='function' then
      local mt=getmetatable(generator)
      if mt~=nil and type(mt)~='table' then error('KZ Codex: protected iterable metatables are unsupported',0) end
      if type(mt)=='table' and mt.__iter then r[a],r[a+1],r[a+2]=mt.__iter(generator)
      elseif type(mt)=='table' and mt.__call then
      elseif type(generator)=='table' then r[a]=next r[a+1]=generator r[a+2]=nil
      else error('KZ Codex: invalid iterator',0) end
    end pc=pc+d`,
  FORGPREP_NEXT:'pc=pc+d', FORGPREP_INEXT:'pc=pc+d',
  FORGLOOP:`local count=bit32.band(code[pc],255)
    local results=table.pack(r[a](r[a+1],r[a+2]))
    for i=1,count do r[a+2+i]=results[i] end r[a+2]=results[1]
    if results[1]~=nil then pc=pc+d else pc=pc+1 end`,
  GETVARARGS:'local count=b-1 if b==0 then count=math.max(0,args.n-p.params) top=a+count end for i=1,count do r[a+i-1]=args[p.params+i] end',
  CAPTURE:"error('KZ Codex: unexpected capture',0)",
  SUBRK:'r[a]=constant(p,b)-r[c]', DIVRK:'r[a]=constant(p,b)/r[c]',
  IDIV:'r[a]=r[b]//r[c]', IDIVK:'r[a]=r[b]//constant(p,c)',
};
for (const [name,operator] of Object.entries({ADD:'+',SUB:'-',MUL:'*',DIV:'/',MOD:'%',POW:'^',AND:'and',OR:'or'})) {
  handlers[name]=`r[a]=r[b] ${operator} r[c]`;
  handlers[name+'K']=`r[a]=r[b] ${operator} constant(p,c)`;
}
for (const [name,operator] of Object.entries({JUMPIFEQ:'==',JUMPIFLE:'<=',JUMPIFLT:'<',JUMPIFNOTEQ:'~=',JUMPIFNOTLE:'<=',JUMPIFNOTLT:'<'})) {
  const expression=`r[a] ${operator} r[code[pc]]`;
  handlers[name]=`if ${name==='JUMPIFNOTLE'||name==='JUMPIFNOTLT'?`not (${expression})`:expression} then pc=pc+d else pc=pc+1 end`;
}
for (const [name,expr] of Object.entries({JUMPXEQKNIL:'nil',JUMPXEQKB:'bit32.band(aux,1)~=0',JUMPXEQKN:'constant(p,bit32.band(aux,16777215))',JUMPXEQKS:'constant(p,bit32.band(aux,16777215))'})) {
  handlers[name]=`local aux=code[pc] local equal=r[a]==(${expr}) if equal~=(aux>=2147483648) then pc=pc+d else pc=pc+1 end`;
}
function callCases(prefix) {
  const calls=['r[a]()','r[a](r[a+1])','r[a](r[a+1],r[a+2])','r[a](r[a+1],r[a+2],r[a+3])'];
  return calls.map((call,i)=>`${i?'elseif':'if'} b==${i+1} then ${prefix}${call}`).join(' ')+` else ${prefix}r[a](table.unpack(r,a+1,a+argc)) end`;
}
handlers.CALL=`local argc=b-1 if b==0 then argc=top-a-1 end
  local callee=r[a] local info=registry[callee]
  if info then
    local count=run(info[1],info[2],hostGetfenv(callee),callee,r,a,c-1,r,a+1,argc)
    if c==0 then top=a+count end
  else
  if c==1 then ${callCases('')}
  elseif c==2 then ${callCases('r[a]=')}
  elseif c==3 then ${callCases('r[a],r[a+1]=')}
  elseif c==4 then ${callCases('r[a],r[a+1],r[a+2]=')}
  else local results=table.pack(r[a](table.unpack(r,a+1,a+argc)))
    local count=c-1 if c==0 then count=results.n top=a+count end
    for i=1,count do r[a+i-1]=results[i] end
  end end`;
handlers.RETURN=`if close then close(0) end
  -- Wipe only when windows were used (avoids per-return cost on fast/plain protos)
  if p.constWindow and p.constWindow.clearOnReturn and p.constWindow.wipe then p.constWindow.wipe() end
  if p.instrWindowStart and p.instrWindow then
    for i=1,#p.instrWindow do p.instrWindow[i]=nil end
    p.instrWindowStart=nil
  end
  local count=b-1 if b==0 then count=top-a end
  local written=wanted if written<0 then written=count end
  for i=0,written-1 do if i<count then destination[destStart+i]=r[a+i] else destination[destStart+i]=nil end end
  table.clear(r) if #pool<8 then pool[#pool+1]=r end
  return count`;

export function specializedCall(b,c) {
  const argc=b===0?'top-a-1':String(b-1);
  const argumentsText=b>0&&b<=5?Array.from({length:b-1},(_,i)=>`r[a+${i+1}]`).join(','):`table.unpack(r,a+1,a+${argc})`;
  let native;
  if(c>0&&c<=5)native=(c>1?Array.from({length:c-1},(_,i)=>`r[a+${i}]`).join(',')+'=':'')+`callee(${argumentsText})`;
  else native=`local results=table.pack(callee(${argumentsText})) local count=${c===0?'results.n':c-1} ${c===0?'top=a+count':''} for i=1,count do r[a+i-1]=results[i] end`;
  return `local callee=r[a] local info=registry[callee]
    if info then local count=run(info[1],info[2],hostGetfenv(callee),callee,r,a,${c-1},r,a+1,${argc}) ${c===0?'top=a+count':''}
    else ${native} end`;
}

// Extended diversify: more variants per handler, covers more opcodes
export function diversify(name,rng,choiceLog) {
  const original=handlers[name];let choices=[original];

  // Arithmetic variants must read operands before assigning the destination.
  if(['ADD','SUB','MUL','DIV','MOD','POW','IDIV','ADDK','SUBK','MULK','DIVK','MODK','POWK','IDIVK'].includes(name)) {
    const expression=original.slice('r[a]='.length);
    choices.push(`local value=${expression} r[a]=value`);
    choices.push(`if a==b then ${original.replaceAll('r[b]','r[a]')} else ${original} end`);
    // new: explicit temp with type guard shape
    choices.push(`do local _lhs,_rhs=r[b],${name.endsWith('K')?'constant(p,c)':'r[c]'} r[a]=_lhs ${{'ADD':'+','SUB':'-','MUL':'*','DIV':'/','MOD':'%','POW':'^','IDIV':'//','ADDK':'+','SUBK':'-','MULK':'*','DIVK':'/','MODK':'%','POWK':'^','IDIVK':'//'}[name]} _rhs end`);
  }

  // MOVE: 4 variants (was 3)
  if(name==='MOVE') choices.push('local value=r[b] r[a]=value','if a~=b then r[a]=r[b] end','do r[a]=r[b] end');

  // LOADB: 3 variants
  if(name==='LOADB') choices.push('if b==0 then r[a]=false else r[a]=true end pc=pc+c','r[a]=(b~=0) pc=pc+c');

  // NOT: 3 variants
  if(name==='NOT') choices.push('if r[b] then r[a]=false else r[a]=true end','do local _v=r[b] r[a]=not _v end');

  // GETTABLE: 3 variants
  if(name==='GETTABLE') choices.push('local container,key=r[b],r[c] r[a]=container[key]','do local _t=r[b] r[a]=_t[r[c]] end');

  // SETTABLE: 3 variants
  if(name==='SETTABLE') choices.push('local value,container,key=r[a],r[b],r[c] container[key]=value','do local _v,_t,_k=r[a],r[b],r[c] _t[_k]=_v end');

  // JUMPIF / JUMPIFNOT: 3 variants each
  if(name==='JUMPIF') choices.push('if not r[a] then else pc=pc+d end','do if r[a] then pc=pc+d end end');
  if(name==='JUMPIFNOT') choices.push('if r[a] then else pc=pc+d end','do if not r[a] then pc=pc+d end end');

  // LOADN: new variants
  if(name==='LOADN') choices.push('do local _n=d r[a]=_n end','r[a]=0+d');

  // LOADNIL: new variant
  if(name==='LOADNIL') choices.push('do r[a]=nil end');

  // LENGTH: new variant
  if(name==='LENGTH') choices.push('do local _t=r[b] r[a]=#_t end');

  // CONCAT: new variant
  if(name==='CONCAT') choices.push('do local _v=r[c] for i=c-1,b,-1 do _v=r[i].._v end r[a]=_v end');

  // MINUS: new variant
  if(name==='MINUS') choices.push('do local _v=r[b] r[a]=-_v end');

  const selected=Math.floor(rng()*choices.length);
  if(choices.length>1)choiceLog.push({opcode:name,variant:selected});
  return choices[selected];
}
