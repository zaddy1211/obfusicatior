import {spawnSync} from 'node:child_process';
import {mkdtempSync,writeFileSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {resolve,dirname} from 'node:path';

// Ask the pinned Luau runtime to read only AST-confirmed literal tokens. This
// preserves decimal/hex/Unicode escapes, binary strings and long-string rules;
// no function body or other expression from the input is executed.
export function nativeLiterals(statements,source,range,astExecutable) {
  const tokens=new Map();
  function walk(node) {
    if(!node||typeof node!=='object')return;
    if(node.type==='AstExprConstantString') {
      const [start,end]=range(node.location),token=source.subarray(start,end).toString();
      if(token.startsWith('"')||token.startsWith("'")||/^\[=*\[/.test(token))tokens.set(node.location,token);
      return;
    }
    for(const value of Object.values(node))if(Array.isArray(value))value.forEach(walk);
    else if(value&&typeof value==='object')walk(value);
  }
  statements.forEach(walk);
  if(!tokens.size)return new Map();
  const dir=mkdtempSync(resolve(tmpdir(),'kz-literals-'));
  try {
    const path=resolve(dir,'literals.luau');
    writeFileSync(path,`local values={${[...tokens.values()].join(',\n')}}
for _,value in values do
  local pieces=table.create(#value)
  for i=1,#value do pieces[i]=string.format('%02x',string.byte(value,i)) end
  print('KZ:'..table.concat(pieces))
end\n`);
    // If luau-ast was found via PATH (bare name), resolve the interpreter via
    // PATH too; only derive a sibling path when an explicit directory was given.
    const isBare=!astExecutable.includes('/')&&!astExecutable.includes('\\');
    const executable=isBare?'luau':resolve(dirname(astExecutable),'luau'+(process.platform==='win32'?'.exe':''));
    const result=spawnSync(executable,[path],{encoding:'utf8',maxBuffer:64*1024*1024,timeout:30000});
    if(result.error)throw result.error;
    if(result.status!==0)throw Error(result.stderr||'Native literal extraction failed');
    const rows=result.stdout.trimEnd().split(/\r?\n/);
    if(rows.length!==tokens.size||rows.some(row=>!/^KZ:(?:[0-9a-f]{2})*$/.test(row)))throw Error('Invalid native literal data');
    return new Map([...tokens.keys()].map((location,index)=>[location,Buffer.from(rows[index].slice(3),'hex')]));
  } finally {rmSync(dir,{recursive:true,force:true});}
}
