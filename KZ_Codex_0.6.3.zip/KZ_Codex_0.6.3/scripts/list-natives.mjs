import { listTopLevelLocals } from '../src/list-natives.js';
const input = process.argv[2];
if (!input) {
  console.error('Usage: node scripts/list-natives.mjs <input.luau>');
  process.exit(1);
}
const result = listTopLevelLocals(input);
console.log(`Method: ${result.method}`);
if (result.note) console.log(`Note: ${result.note}`);
console.log(`Candidates (${result.names.length}):`);
for (const n of result.names) console.log(`  --native ${n.name}`);
console.log('\n# Example rebuild (use ONLY profiler-hot names):');
console.log(`node src/cli.js "${input}" -o output/protected.luau --profile fast -O 2 --vm-variants 1 --one-line --force \\`);
const sample = result.names.slice(0, 8).map(n => `  --native ${n.name}`).join(' \\\n');
if (sample) console.log(sample + ' \\');
console.log('  --report output/protected.report.json');
