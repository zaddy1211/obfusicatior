/**
 * Recovery regression test — updated for 0.6.3 hardened Share A.
 *
 * 0.6.3 broke the original Codex-v6 single m={}/x={} pattern. This test:
 *   0. Asserts the old trivial pattern is gone
 *   1. Reconstructs Share A via interleaved even/odd tables + secondary
 *      magic-derived mask + unrotate
 *   2. Opens the kind-5 bootstrap section with Share A → Share B
 *   3. Opens the kind-6 section with A⊕B → Share C
 *   4. master = A⊕B⊕C; opens every remaining sealed section
 *   5. Parses the manifest and string section
 *
 * PASS = the (updated) extractor still recovers EVERYTHING. This remains the
 * expected baseline: staged keys raise live-dump cost; offline extraction is
 * still possible once the new parser is written. Treat any future "extractor
 * fails" result as LIMITED evidence only — obtain a blind assessment before
 * claiming real-world resistance.
 */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { writeFileSync, mkdtempSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { resolve } from 'node:path';
import { build, executable } from '../src/build.js';
import { open, nonce, associatedData, combineShares } from '../src/key-material.js';

const luauAvailable = (() => {
  const c = executable('luau-compile');
  if (existsSync(c) || !String(c).includes('tools')) {
    const r = spawnSync(String(c).includes('tools') ? 'false' : c, ['--help'], { timeout: 3000 });
    return !r.error;
  }
  return false;
})();

// ---------- documented extractor (source-only, no build internals) ----------

function decode85(text, alphabet) {
  const out = Buffer.alloc(Math.floor(text.length / 5) * 4);
  for (let i = 0; i < text.length; i += 5) {
    let n = 0;
    for (let j = 0; j < 5; j++) {
      const d = alphabet.indexOf(text[i + j]);
      assert.notEqual(d, -1, 'alphabet character');
      n = n * 85 + d;
    }
    out.writeUInt32LE(n >>> 0, (i / 5) * 4);
  }
  return out;
}

function expand(data) {
  // Bounded hash-chain LZSS: flag byte per 8 tokens; literal 1 byte;
  // match = u16 LE distance + u8 (length - 3).
  const out = [];
  let pos = 0;
  while (pos < data.length) {
    const flags = data[pos++];
    for (let bit = 0; bit < 8 && pos < data.length; bit++) {
      if (flags & (1 << bit)) {
        const distance = data[pos] | (data[pos + 1] << 8);
        const length = data[pos + 2] + 3;
        pos += 3;
        for (let n = 0; n < length; n++) out.push(out[out.length - distance]);
      } else {
        out.push(data[pos++]);
      }
    }
  }
  return Buffer.from(out);
}

function bit32_lrotate(v, n) {
  n = n & 31;
  return ((v << n) | (v >>> (32 - n))) >>> 0;
}
function secondaryWord(seed, index) {
  let s = (seed ^ Math.imul(index, 0x9e3779b9)) >>> 0;
  s = Math.imul(s ^ (s >>> 16), 0x85ebca6b) >>> 0;
  s = Math.imul(s ^ (s >>> 13), 0xc2b2ae35) >>> 0;
  s = (s ^ (s >>> 16)) >>> 0;
  return s || 1;
}

function extract(source) {
  const alphabet = source.match(/local alphabet="([^"]+)"/)[1];
  const magic = [...source.matchAll(/byte\(\)==(\d+)/g)].slice(0, 3).map(m => Number(m[1]));

  // 0.6.3 hardened Share A: interleaved even/odd tables + secondary magic-derived
  // mask + rotate. The old single m={}/x={} pattern is intentionally absent.
  const oldShare = source.match(/local m=\{([\d,]+)\} local x=\{([\d,]+)\}/);
  assert.equal(oldShare, null, 'old trivial Share A pattern must be gone (0.6.3 hardening)');

  const me = source.match(/local me=\{([\d,]+)\}/)[1].split(',').map(Number);
  const mo = source.match(/local mo=\{([\d,]+)\}/)[1].split(',').map(Number);
  const xe = source.match(/local xe=\{([\d,]+)\}/)[1].split(',').map(Number);
  const xo = source.match(/local xo=\{([\d,]+)\}/)[1].split(',').map(Number);
  const rMatch = source.match(/local r=(\d+)/);
  const rotAmount = Number(rMatch[1]);
  const secondarySeed = ((magic[0] << 16) ^ (magic[1] << 8) ^ magic[2] ^ 0x4b5a3633) >>> 0;

  const shareA = Buffer.alloc(32);
  for (let i = 0; i < 4; i++) {
    const ve = (xe[i] ^ me[i] ^ secondaryWord(secondarySeed, i * 2)) >>> 0;
    const vo = (xo[i] ^ mo[i] ^ secondaryWord(secondarySeed, i * 2 + 1)) >>> 0;
    // unrotate (right-rotate by rotAmount)
    const ue = bit32_lrotate(ve, (32 - rotAmount) & 31);
    const uo = bit32_lrotate(vo, (32 - rotAmount) & 31);
    shareA.writeUInt32LE(ue, i * 8);
    shareA.writeUInt32LE(uo, i * 8 + 4);
  }

  // Sections: {kind,owner,rawLen,packedLen,tag0..3,"data"}; id = position
  const sections = [];
  const re = /\{\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*"([^"]*)"\s*\}/g;
  let m;
  while ((m = re.exec(source))) {
    sections.push({
      id: sections.length + 1,
      kind: Number(m[1]), owner: Number(m[2]),
      rawLen: Number(m[3]), packedLen: Number(m[4]),
      tag: Buffer.concat([1, 2, 3, 4].map(i => {
        const b = Buffer.alloc(4); b.writeUInt32LE(Number(m[4 + i]) >>> 0); return b;
      })),
      data: m[9],
    });
  }
  assert.ok(sections.length >= 3, 'sections present');

  const openSection = (s, key) => {
    const padded = decode85(s.data, alphabet);
    const ciphertext = padded.subarray(0, s.packedLen);
    const plain = open(ciphertext, s.tag, key, nonce(0, s.id),
      associatedData(s.id, s.kind, s.owner, s.rawLen, s.packedLen));
    const raw = expand(plain);
    assert.equal(raw.length, s.rawLen, 'decompressed length');
    return raw;
  };

  const bootstrap = sections.find(s => s.kind === 5);
  const shareCSection = sections.find(s => s.kind === 6);
  const shareB = openSection(bootstrap, shareA).subarray(0, 32);
  const materialAB = Buffer.alloc(32);
  for (let i = 0; i < 32; i++) materialAB[i] = shareA[i] ^ shareB[i];
  const shareC = openSection(shareCSection, materialAB).subarray(0, 32);
  const master = combineShares(shareA, shareB, shareC);

  const opened = new Map([[bootstrap.id, true], [shareCSection.id, true]]);
  const raws = new Map();
  for (const s of sections) {
    if (s.kind === 5 || s.kind === 6) continue;
    raws.set(s.id, openSection(s, master)); // throws if authentication fails
    opened.set(s.id, true);
  }

  // Manifest (kind 0): magic, string section id, string count, proto count, main
  const manifest = sections.find(s => s.kind === 0);
  const data = raws.get(manifest.id);
  let cursor = 0;
  const byte = () => data[cursor++];
  const variable = () => {
    let value = 0, power = 1;
    for (let i = 0; i < 5; i++) {
      const n = byte(); value += (n & 127) * power;
      if (n < 128) return value;
      power *= 128;
    }
    throw new Error('invalid varint');
  };
  assert.deepEqual([byte(), byte(), byte()], magic, 'manifest magic');
  const stringSection = variable();
  const stringCount = variable();
  const protoCount = variable();
  const main = variable();

  return {
    shareA, shareB, shareC, master,
    sectionCount: sections.length,
    openedCount: opened.size,
    manifest: { stringSection, stringCount, protoCount, main },
    raws,
  };
}

// ---------------------------------------------------------------------------

test('documented extractor still recovers everything (regression target)', { skip: !luauAvailable && 'Luau tools not available' }, () => {
  const dir = mkdtempSync(resolve(tmpdir(), 'kz-recovery-'));
  try {
    const marker = 'KZ-RECOVERY-MARKER-7f3a';
    const fixture = resolve(dir, 'fixture.luau');
    writeFileSync(fixture, `
local function Hot(x) return x * 2 + 1 end
local function Secrets() return "${marker}" end
assert(Hot(21) == 43)
assert(Secrets() == "${marker}")
print("ok")
`);
    const result = build(fixture, {
      optimization: 2, profile: 'fast', vmVariants: 1, oneLine: true,
      seed: 'recovery-regression', native: ['Hot'], protect: ['Secrets'],
    });

    const recovered = extract(result.source);

    // The extractor is expected to recover EVERYTHING. That is the documented
    // security posture: staged keys raise live-dump cost, not offline extraction.
    assert.equal(recovered.openedCount, recovered.sectionCount,
      'every sealed section opened offline from source-only material');
    assert.ok(recovered.manifest.protoCount >= 2, 'prototypes enumerated');
    assert.ok(recovered.manifest.main >= 1 && recovered.manifest.main <= recovered.manifest.protoCount);

    // String section payload is recoverable and authenticated
    const stringRaw = recovered.raws.get(recovered.manifest.stringSection);
    assert.ok(stringRaw && stringRaw.length > 0, 'string section recovered');
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('unsigned corruption is rejected (authentication still enforced)', { skip: !luauAvailable && 'Luau tools not available' }, () => {
  const dir = mkdtempSync(resolve(tmpdir(), 'kz-tamper-'));
  try {
    const fixture = resolve(dir, 'fixture.luau');
    writeFileSync(fixture, 'print("ok")\n');
    const result = build(fixture, { profile: 'fast', seed: 'tamper-check' });
    // Flip one character inside a sealed section payload (not the tag)
    const re = /\{\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*"([^"]*)"\s*\}/;
    const m = result.source.match(re);
    const data = m[9];
    const i = Math.floor(data.length / 2);
    const flipped = data.slice(0, i) + (data[i] === 'A' ? 'B' : 'A') + data.slice(i + 1);
    const tampered = result.source.slice(0, m.index) + m[0].replace('"' + data + '"', '"' + flipped + '"') + result.source.slice(m.index + m[0].length);
    assert.throws(() => extract(tampered), /Unsupported state|auth|tag/i,
      'bit-flipped payload must fail AEAD authentication');
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});
