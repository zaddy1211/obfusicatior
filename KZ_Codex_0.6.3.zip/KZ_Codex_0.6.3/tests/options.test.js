import test from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { resolve, join } from 'node:path';
import { mkdtempSync, writeFileSync, readFileSync, existsSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { build, executable, save, validateBuildOptions } from '../src/build.js';

const cli = fileURLToPath(new URL('../src/cli.js', import.meta.url));

function runCLI(...args) {
  return spawnSync(process.execPath, [cli, ...args], { encoding: 'utf8' });
}

function toolAvailable(name) {
  const candidate = executable(name);
  return existsSync(candidate) || !String(candidate).includes('tools');
}

const luauCompilerAvailable = toolAvailable('luau-compile');
const luauRunnerAvailable = toolAvailable('luau-execute') || toolAvailable('luau');

test('build option validation accepts defaults and documented limits', () => {
  assert.doesNotThrow(() => validateBuildOptions('input.luau'));
  assert.doesNotThrow(() => validateBuildOptions('input.luau', {
    optimization: 2,
    vmOptimization: 1,
    profile: 'fast',
    vmVariants: 4,
    maxBytes: 100,
    hardMaxBytes: 200,
    native: ['Update'],
    protect: ['RareHelper'],
    nativeRegions: ['HOT_LOOP@state'],
    seed: 'release-1',
    force: true,
    executeTest: false,
  }));
});

test('build options reject malformed input and option objects', () => {
  assert.throws(() => validateBuildOptions(''), /Input path/);
  assert.throws(() => validateBuildOptions(undefined), /Input path/);
  assert.throws(() => validateBuildOptions('input.luau', null), /options must be an object/i);
  assert.throws(() => validateBuildOptions('input.luau', []), /options must be an object/i);
});

test('build options reject unknown profiles and invalid optimization levels', () => {
  assert.throws(() => validateBuildOptions('input.luau', { profile: 'stealth' }), /Profile must be/);
  assert.throws(() => validateBuildOptions('input.luau', { optimization: 3 }), /Optimization must be/);
  assert.throws(() => validateBuildOptions('input.luau', { optimization: 1.5 }), /Optimization must be/);
  assert.throws(() => validateBuildOptions('input.luau', { vmOptimization: -1 }), /VM optimization must be/);
});

test('build options reject out-of-range VM variant counts', () => {
  for (const vmVariants of [0, 5, 1.5, NaN]) {
    assert.throws(() => validateBuildOptions('input.luau', { vmVariants }), /VM variants must be/);
  }
});

test('build options require ordered positive integer size budgets', () => {
  assert.throws(() => validateBuildOptions('input.luau', { maxBytes: 0 }), /Preferred size budget/);
  assert.throws(() => validateBuildOptions('input.luau', { hardMaxBytes: Infinity }), /Hard size ceiling/);
  assert.throws(() => validateBuildOptions('input.luau', { maxBytes: 200, hardMaxBytes: 100 }), /cannot exceed/);
});

test('build options validate selection arrays and reject duplicate function modes', () => {
  assert.throws(() => validateBuildOptions('input.luau', { native: 'Update' }), /--native values must be provided as an array/);
  assert.throws(() => validateBuildOptions('input.luau', { protect: ['  '] }), /--protect values/);
  assert.throws(() => validateBuildOptions('input.luau', { nativeRegions: ['A\nB'] }), /--native-region values/);
  assert.throws(() => validateBuildOptions('input.luau', { native: ['Update'], protect: ['Update'] }), /unique/);
});

test('build options reject invalid seeds and non-boolean flags', () => {
  assert.throws(() => validateBuildOptions('input.luau', { seed: Infinity }), /Seed must be/);
  assert.throws(() => validateBuildOptions('input.luau', { fusion: 'true' }), /fusion must be a boolean/);
  assert.throws(() => validateBuildOptions('input.luau', { allowSynthetic: true, executeTest: true }), /cannot be combined/);
});

test('build options prevent output/report collisions and source clobbering', () => {
  const input = resolve('fixture.luau');
  const output = resolve('build-result.luau');
  assert.throws(() => validateBuildOptions(input, { output, report: output }), /must be different/);
  assert.throws(() => validateBuildOptions(input, { report: input }), /cannot overwrite the input source/);
});

test('save uses no-clobber publication unless force is explicitly requested', () => {
  const dir = mkdtempSync(join(tmpdir(), 'kz-save-safety-'));
  try {
    const output = join(dir, 'artifact.luau');
    assert.equal(save(output, { source: 'first' }), resolve(output));
    assert.equal(readFileSync(output, 'utf8'), 'first');
    assert.throws(() => save(output, { source: 'second' }), /already exists/);
    assert.equal(readFileSync(output, 'utf8'), 'first');
    save(output, { source: 'replaced' }, { force: true });
    assert.equal(readFileSync(output, 'utf8'), 'replaced');
    assert.throws(() => save(output, null), /Build result/);
    assert.throws(() => save('', { source: 'bad' }), /Output path/);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('synthetic builds ignore input and preserve existing report files without --force', () => {
  const dir = mkdtempSync(join(tmpdir(), 'kz-build-safety-'));
  try {
    const input = join(dir, 'input.luau');
    const output = join(dir, 'output.luau');
    const report = join(dir, 'output.json');
    const secondOutput = join(dir, 'must-not-be-written.luau');
    writeFileSync(input, 'error("build must not run this source")\n');

    const result = build(input, {
      allowSynthetic: true,
      output,
      report,
      profile: 'fast',
      seed: 'layout-only',
    });
    assert.equal(result.stats.executionTest, 'skipped (synthetic)');
    assert.equal(result.stats.inputBytes, 0);
    assert.doesNotMatch(result.source, /build must not run this source/);
    assert.equal(JSON.parse(readFileSync(report, 'utf8')).executionTest, result.stats.executionTest);
    assert.equal(existsSync(output), true);

    assert.throws(() => build(input, {
      allowSynthetic: true,
      output: secondOutput,
      report,
      profile: 'fast',
    }), /Report already exists/);
    assert.equal(existsSync(secondOutput), false, 'preflight failure must not leave a partial output');

    const secondReport = join(dir, 'must-not-be-written.json');
    assert.throws(() => build(input, {
      allowSynthetic: true,
      output,
      report: secondReport,
      profile: 'fast',
    }), /Output already exists/);
    assert.equal(existsSync(secondReport), false, 'output preflight must happen before writing a report');

    const replaced = build(input, {
      allowSynthetic: true,
      output,
      report,
      force: true,
      profile: 'fast',
      seed: 'force-check',
    });
    assert.equal(replaced.stats.executionTest, 'skipped (synthetic)');
    assert.equal(JSON.parse(readFileSync(report, 'utf8')).executionTest, 'skipped (synthetic)');
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('real builds compile-check without executing the input by default', {
  skip: !luauCompilerAvailable && 'Luau compiler not available',
}, () => {
  const dir = mkdtempSync(join(tmpdir(), 'kz-compile-only-'));
  try {
    const input = join(dir, 'must-not-run.luau');
    writeFileSync(input, 'error("default build executed the input")\n');
    const result = build(input, { profile: 'fast' });
    assert.equal(result.stats.validatedOutput, true);
    assert.match(result.stats.executionTest, /^skipped \(opt-in;/);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('explicit execution test runs a trusted smoke fixture', {
  skip: !luauCompilerAvailable || !luauRunnerAvailable ? 'Luau compiler/interpreter not available' : false,
}, () => {
  const dir = mkdtempSync(join(tmpdir(), 'kz-execute-test-'));
  try {
    const input = join(dir, 'safe.luau');
    writeFileSync(input, 'assert(1 + 1 == 2)\n');
    const result = build(input, { profile: 'fast', executeTest: true });
    assert.equal(result.stats.validatedOutput, true);
    assert.equal(result.stats.executionTest, 'pass');
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('CLI rejects conflicting execution-test flags', () => {
  const result = runCLI('input.luau', '--execute-test', '--no-execute');
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /mutually exclusive/);
});

test('CLI prevents executing a synthetic fixture', () => {
  const result = runCLI('input.luau', '--synthetic', '--execute-test');
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /cannot be combined/);
});

test('CLI reports a missing value instead of consuming the next flag', () => {
  const result = runCLI('input.luau', '--output', '--force');
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /--output requires a value/);
  assert.doesNotMatch(result.stdout, /build complete/i);
});

test('CLI rejects extra positional input paths', () => {
  const result = runCLI('first.luau', 'second.luau');
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /Unexpected extra input path/);
});

test('CLI validates profile before compiler discovery', () => {
  const result = runCLI('not-present.luau', '--profile', 'unknown');
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /Profile must be/);
  assert.doesNotMatch(result.stderr, /compiler not found/i);
});
