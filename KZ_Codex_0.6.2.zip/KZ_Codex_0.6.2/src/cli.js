#!/usr/bin/env node
/**
 * KZ Codex 0.6 CLI — selective native + staged VM
 */
import { resolve, parse as parsePath } from 'node:path';
import { existsSync } from 'node:fs';
import { build, save } from './build.js';

const help = `KZ Codex 0.6 — selective native + staged VM obfuscator

Usage: node src/cli.js input.luau -o output.luau [options]

  -o, --output PATH         Output file
  -O, --optimization N      Luau opt level 0|1|2 (default 1)
  --profile NAME            fast | balanced | heavy | max (default balanced)
  --vm-variants N           1–4 (default 1 for FPS-sensitive builds)
  --seed VALUE              Layout seed (keys still use OS entropy unless documented otherwise)
  --max-bytes N             Preferred budget (default 1700000)
  --hard-max-bytes N        Hard ceiling (default 1900000)
  --force                   Overwrite existing output
  --readable                Keep comments
  --one-line                Single physical line output
  --report PATH             JSON build report
  --native NAME             Keep top-level local function native (repeatable) — USE FOR QB HOT PATHS
  --native-region MARKER    Keep marked region native (repeatable)
  --protect NAME            Heavily protect top-level local (repeatable)
  --no-execute              Skip the runtime execution test (compile validation still enforced)
  --synthetic               Test-only synthetic program (no real compile)
  -h, --help

QB Smart Fit / FPS:
  Profile fast alone is NOT enough if the solver still runs inside the VM.
  Mark trajectory/solver/per-frame callbacks with --native FunctionName.
  Example:
    node src/cli.js game.luau -o out.luau --profile fast -O 2 --vm-variants 1 --one-line \\
      --native SmartFitSolve --native UpdateTrajectory --force --report out.json
`;

function parseArgs(argv) {
  const opts = {
    optimization: 1,
    profile: 'balanced',
    maxBytes: 1_700_000,
    hardMaxBytes: 1_900_000,
    vmVariants: 1,
    force: false,
    readable: false,
    oneLine: false,
    allowSynthetic: false,
    fusion: false,
    native: [],
    nativeRegions: [],
    protect: [],
  };
  const positional = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '-o' || a === '--output') opts.output = argv[++i];
    else if (a === '--optimization' || a === '-O') opts.optimization = Number(argv[++i]);
    else if (a === '--profile') opts.profile = argv[++i];
    else if (a === '--seed') opts.seed = argv[++i];
    else if (a === '--max-bytes') opts.maxBytes = Number(argv[++i]);
    else if (a === '--hard-max-bytes') opts.hardMaxBytes = Number(argv[++i]);
    else if (a === '--vm-variants') opts.vmVariants = Number(argv[++i]);
    else if (a === '--force') opts.force = true;
    else if (a === '--readable') opts.readable = true;
    else if (a === '--one-line') opts.oneLine = true;
    else if (a === '--report') opts.report = argv[++i];
    else if (a === '--native') opts.native.push(argv[++i]);
    else if (a === '--native-region') opts.nativeRegions.push(argv[++i]);
    else if (a === '--protect') opts.protect.push(argv[++i]);
    else if (a === '--no-execute') opts.executeTest = false;
    else if (a === '--synthetic') opts.allowSynthetic = true;
    else if (a === '-h' || a === '--help') opts.help = true;
    else if (a.startsWith('-')) throw new Error('Unknown option: ' + a);
    else positional.push(a);
  }
  if (opts.help || positional.length < 1) {
    console.log(help);
    process.exit(opts.help ? 0 : 1);
  }
  opts.input = positional[0];
  return opts;
}

try {
  const opts = parseArgs(process.argv.slice(2));
  const result = build(opts.input, opts);
  if (opts.output) {
    // build already wrote if output set
  }
  const s = result.stats;
  console.log('KZ Codex 0.6 build complete');
  console.log('  Input → output :', (s.inputBytes || 0).toLocaleString(), '→', s.outputBytes.toLocaleString(), 'bytes');
  console.log('  Preferred      :', (s.budgetBytes || 0).toLocaleString(), s.underPreferred ? '(OK)' : '(over preferred)');
  console.log('  Hard ceiling   :', (s.hardBudget || 0).toLocaleString());
  console.log('  Native funcs   :', (s.nativeFunctions || []).length ? (s.nativeFunctions || []).join(', ') : '(none — all virtualized)');
  console.log('  Key split      :', s.keySplit);
  console.log('  Profile        :', opts.profile);
  console.log('  Validation     :', s.validatedOutput ? 'compile OK' : 'not validated (synthetic/test build)');
  if (s.executionTest) console.log('  Execution test :', s.executionTest);
  if (s.protectedFunctions?.length) console.log('  Protected fns  :', s.protectedFunctions.map(g => g.name).join(', '));
  if (opts.output) console.log('  Written to     :', resolve(opts.output));
  if (!(s.nativeFunctions || []).length && opts.profile === 'fast') {
    console.warn('NOTE: --profile fast with zero --native still runs hot paths in the VM.');
    console.warn('      Mark QB Smart Fit / trajectory solvers with --native Name for FPS.');
  }
} catch (err) {
  console.error('KZ Codex:', err.message);
  process.exit(1);
}
