/**
 * Quick self-test for the staged key system.
 * Run with: node src/selftest-keys.js
 */
import { splitKey, combineShares, deriveProtoSubkey, payloadKey } from './key-material.js';
import { randomBytes } from 'node:crypto';

function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'assertion failed');
}

const master = randomBytes(32);
const { shareA, shareB, shareC } = splitKey(master);

const reconstructed = combineShares(shareA, shareB, shareC);
assert(reconstructed.equals(master), 'XOR reconstruction failed');

// Simulate partial dumps
const onlyAB = Buffer.concat([shareA, shareB]);
const onlyAC = Buffer.concat([shareA, shareC]);
const onlyBC = Buffer.concat([shareB, shareC]);

assert(!onlyAB.equals(master) && onlyAB.length === 64, 'partial dump A+B should not equal master');
assert(!onlyAC.equals(master), 'partial dump A+C should not equal master');
assert(!onlyBC.equals(master), 'partial dump B+C should not equal master');

// Subkey uniqueness
const sk1 = deriveProtoSubkey(master, 1, Buffer.from('build1'));
const sk2 = deriveProtoSubkey(master, 2, Buffer.from('build1'));
const sk1b = deriveProtoSubkey(master, 1, Buffer.from('build1'));
assert(sk1.equals(sk1b), 'subkey must be deterministic');
assert(!sk1.equals(sk2), 'different proto ids must produce different subkeys');
assert(sk1.length === 32, 'subkey must be 16 bytes');

// Seeded payload key still works
const k1 = payloadKey({ test: true }, 'seed-42');
const k2 = payloadKey({ test: true }, 'seed-42');
const k3 = payloadKey({ test: false }, 'seed-42');
assert(k1.equals(k2), 'seeded key must be deterministic');
assert(!k1.equals(k3), 'different program material must change key');

console.log('All key-material self-tests passed.');
console.log('Master length :', master.length);
console.log('Share sizes   :', shareA.length, shareB.length, shareC.length);
console.log('Subkey length :', sk1.length);
