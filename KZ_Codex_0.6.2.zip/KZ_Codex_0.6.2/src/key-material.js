/**
 * KZ Codex 0.6 — Staged / Split Key Material
 *
 * The master key is split into three shares so that a single memory dump
 * never yields the complete key.  Shares are XOR-based for simplicity and
 * speed (no heavy crypto at runtime beyond what already exists).
 *
 * Share A  – bootstrap (present in the earliest stage)
 * Share B  – recovered after Stage-0 authentication
 * Share C  – recovered only when the first heavy/protected function runs
 */

import { createHash, createHmac, createCipheriv, createDecipheriv, randomBytes } from 'node:crypto';

const SHARE_SIZE = 32; // bytes

/**
 * Split a 32-byte master key into three 32-byte shares.
 * master = A ⊕ B ⊕ C
 */
export function splitKey(master) {
  if (!Buffer.isBuffer(master) || master.length !== 32) {
    throw new Error('Master key must be a 32-byte Buffer');
  }
  const shareA = randomBytes(SHARE_SIZE);
  const shareB = randomBytes(SHARE_SIZE);
  const shareC = Buffer.alloc(SHARE_SIZE);
  for (let i = 0; i < SHARE_SIZE; i++) {
    shareC[i] = master[i] ^ shareA[i] ^ shareB[i];
  }
  return { shareA, shareB, shareC };
}

/**
 * Reconstruct the master key from any two shares + the third.
 * In practice the runtime only ever holds two at a time.
 */
export function combineShares(a, b, c) {
  const out = Buffer.alloc(SHARE_SIZE);
  for (let i = 0; i < SHARE_SIZE; i++) {
    out[i] = a[i] ^ b[i] ^ c[i];
  }
  return out;
}

/**
 * Derive a 32-byte per-prototype subkey.
 * Used for heavy instruction streams and constant streams of that prototype.
 * Full 32 bytes so it can be used directly with ChaCha20.
 */
export function deriveProtoSubkey(masterMaterial, protoId, buildNonce) {
  const h = createHmac('sha256', masterMaterial);
  h.update('KZ proto subkey v6\0');
  h.update(Buffer.from([
    (protoId >>> 0) & 0xff,
    (protoId >>> 8) & 0xff,
    (protoId >>> 16) & 0xff,
    (protoId >>> 24) & 0xff,
  ]));
  if (buildNonce) h.update(buildNonce);
  return h.digest(); // full 32 bytes
}

/**
 * Derive a short-lived window key used for ephemeral constant windows.
 * Changes every N accesses or on function boundary.
 */
export function deriveWindowKey(subkey, windowCounter) {
  const h = createHmac('sha256', subkey);
  h.update('KZ window v6\0');
  h.update(Buffer.from([
    (windowCounter >>> 0) & 0xff,
    (windowCounter >>> 8) & 0xff,
    (windowCounter >>> 16) & 0xff,
    (windowCounter >>> 24) & 0xff,
  ]));
  return h.digest().subarray(0, 16);
}

/**
 * Build-time payload key (compatible with 0.5.x seeded builds).
 * Fresh unseeded builds still use OS randomness.
 */
export function payloadKey(program, seed) {
  if (seed === undefined) return randomBytes(32);

  const material = JSON.stringify(program, (_, value) => {
    if (typeof value === 'number' && (!Number.isFinite(value) || Object.is(value, -0))) {
      const bits = Buffer.alloc(8);
      bits.writeDoubleLE(value);
      return { ieee754: bits.toString('hex') };
    }
    return value;
  });

  const base = createHash('sha256')
    .update('KZ payload v6.0\0')
    .update(String(seed))
    .update('\0')
    .update(material)
    .digest();

  return createHmac('sha256', base)
    .update('kz-codex-key-stretch-v6\0' + String(seed))
    .digest();
}

/**
 * Nonce helpers (domain-separated, same layout as 0.5.x for compatibility)
 */
export function nonce(domain, id) {
  const b = Buffer.alloc(12);
  b.writeUInt32LE(domain >>> 0, 0);
  b.writeUInt32LE(id >>> 0, 4);
  return b;
}

export function associatedData(id, kind, owner, rawSize, packedSize) {
  const b = Buffer.alloc(24);
  [7, id, kind, owner, rawSize, packedSize].forEach((n, i) => b.writeUInt32LE(n >>> 0, i * 4)); // domain 7 = v0.6
  return b;
}


/**
 * Standard seal (ChaCha20-Poly1305) – same algorithm, new AAD domain (7).
 */

export function open(ciphertext, tag, key, iv, aad = Buffer.alloc(0)) {
  const d = createDecipheriv('chacha20-poly1305', key, iv, { authTagLength: 16 });
  d.setAAD(aad, { plaintextLength: ciphertext.length });
  d.setAuthTag(tag);
  return Buffer.concat([d.update(ciphertext), d.final()]);
}

export function seal(data, key, iv, aad = Buffer.alloc(0)) {
  const c = createCipheriv('chacha20-poly1305', key, iv, { authTagLength: 16 });
  c.setAAD(aad, { plaintextLength: data.length });
  const ciphertext = Buffer.concat([c.update(data), c.final()]);
  return { ciphertext, tag: c.getAuthTag() };
}

export function stream(data, key, domain, id) {
  const iv = Buffer.alloc(16);
  iv.writeUInt32LE(1, 0);
  nonce(domain, id).copy(iv, 4);
  const c = createCipheriv('chacha20', key, iv);
  return Buffer.concat([c.update(data), c.final()]);
}
