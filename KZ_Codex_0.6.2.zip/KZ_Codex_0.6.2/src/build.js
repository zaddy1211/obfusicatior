/**
 * KZ Codex 0.6 — Build entry
 * Restores 0.5.4 selective native / protect / one-line pipeline.
 */
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import {
  readFileSync, existsSync, mkdirSync, writeFileSync,
  renameSync, unlinkSync, mkdtempSync, rmSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { resolve, dirname, join } from 'node:path';
import { performance } from 'node:perf_hooks';
import { parse as parseBytecode, OPS } from './bytecode.js';
import { emit } from './emit.js';
import { prepareNative, prepareNativeRegions, wrapNative } from './hybrid.js';
import { optimize } from './optimize.js';
import { linkProtected } from './link.js';
import { oneLine } from './one-line.js';

export const root = fileURLToPath(new URL('../', import.meta.url));
const banner = `--[[ KZ CODEX v0.6 | SELECTIVE NATIVE + STAGED VM ]]\n`;

export function executable(name) {
  const base = resolve(root, 'tools', 'luau');
  const win = process.platform === 'win32';
  const candidates = [
    join(base, name + (win ? '.exe' : '')),
    join(base, name),
    resolve(root, '../KZ_Codex_v52/KZv6/tools/luau', name + (win ? '.exe' : '')),
  ];
  for (const p of candidates) if (existsSync(p)) return p;
  const r = spawnSync(name, ['--help'], { encoding: 'utf8', timeout: 3000 });
  if (!r.error && (r.status === 0 || r.status === 1)) return name;
  return resolve(base, name + (win ? '.exe' : ''));
}

export function compile(input, { optimization = 1, compiler = executable('luau-compile') } = {}) {
  if (!existsSync(compiler) && String(compiler).includes('tools')) {
    throw new Error('Luau compiler missing. Place luau-compile in tools/luau/ or on PATH.');
  }
  if (![0, 1, 2].includes(optimization)) throw new Error('Optimization must be 0, 1 or 2');
  const result = spawnSync(
    compiler,
    ['--binary', '-O' + optimization, '-g0', resolve(input)],
    { encoding: null, maxBuffer: 256 * 1024 * 1024, timeout: 180000 }
  );
  if (result.error) throw result.error;
  if (result.status !== 0) {
    throw new Error((result.stderr && result.stderr.toString()) || (result.stdout && result.stdout.toString()) || 'Luau compilation failed');
  }
  return parseBytecode(result.stdout);
}

function syntheticProgram() {
  const loadnIdx = OPS.indexOf('LOADN');
  const returnIdx = OPS.indexOf('RETURN');
  const loadn = ((loadnIdx & 255) | ((42 & 0xffff) << 16)) >>> 0;
  const ret = ((returnIdx & 255) | (2 << 16)) >>> 0;
  const numBuf = Buffer.alloc(8);
  numBuf.writeDoubleLE(42, 0);
  return {
    version: 6,
    strings: [Buffer.from('KZ 0.6 demo')],
    protos: [{
      stack: 2, params: 0, ups: 0, vararg: 0,
      code: [loadn, ret],
      constants: [{ tag: 2, value: numBuf }],
      children: [], heavy: false, engine: 1, dispatchMode: 0,
    }],
    main: 0,
    used: new Set(['LOADN', 'RETURN']),
  };
}

export function build(input, options = {}) {
  const started = performance.now();
  const {
    optimization = 1,
    output,
    force = false,
    seed,
    profile = 'balanced',
    maxBytes = 1_700_000,
    hardMaxBytes = 1_900_000,
    vmVariants = 1,
    readable = false,
    report,
    allowSynthetic = false,
    oneLine: doOneLine = false,
    native = [],
    nativeRegions = [],
    protect = [],
    fusion = false,
    dispatchStyle = 'inline',
  } = options;

  const inputPath = resolve(input);
  if (!existsSync(inputPath) && !allowSynthetic) {
    throw new Error('Input not found: ' + inputPath);
  }
  const inputBytes = existsSync(inputPath) ? readFileSync(inputPath).length : 0;

  let program, nativeInfo, regionInfo;
  const protectedFunctions = [];
  const dir = mkdtempSync(resolve(tmpdir(), 'kz-build-'));
  const compilerPath = executable('luau-compile');
  const hasCompiler = existsSync(compilerPath) || !String(compilerPath).includes('tools');

  try {
    if (!hasCompiler && !allowSynthetic) {
      throw new Error(
        'Luau compiler not found (need luau-compile). ' +
        'Install official Luau 0.694 under tools/luau/, or pass --synthetic for test-only builds.'
      );
    }

    if (!hasCompiler && allowSynthetic) {
      console.warn('WARNING: synthetic program (test-only). Not a real protection build.');
      program = syntheticProgram();
    } else {
      let sourceInput = inputPath;

      if (nativeRegions && nativeRegions.length) {
        regionInfo = prepareNativeRegions(sourceInput, nativeRegions, executable('luau-ast'));
        sourceInput = resolve(dir, 'regions.luau');
        writeFileSync(sourceInput, regionInfo.source);
      }

      const nativeNames = [...(native || []), ...((regionInfo && regionInfo.names) || [])];
      const selected = [...nativeNames, ...(protect || [])];

      if (selected.length) {
        if (new Set(selected).size !== selected.length) {
          throw new Error('Function selections must be unique across --native and --protect');
        }
        nativeInfo = prepareNative(sourceInput, selected, executable('luau-ast'), {
          ...options,
          seed,
          sealNames: nativeNames,
        });
        const temporary = resolve(dir, 'input.luau');
        writeFileSync(temporary, nativeInfo.transformed);
        program = compile(temporary, { optimization, compiler: compilerPath });

        for (let i = 0; i < selected.length; i++) {
          if (protect && protect.includes(selected[i])) {
            writeFileSync(temporary, nativeInfo.declarations[i] + '\nreturn ' + nativeInfo.nativeNames[i] + '\n');
            const independent = optimize(compile(temporary, { optimization, compiler: compilerPath }), {
              enabled: (options.vmOptimization ?? optimization) === 2,
            });
            protectedFunctions.push({
              name: selected[i],
              program: independent.program,
              optimizationPasses: independent.stats,
            });
          }
        }
      } else {
        program = compile(sourceInput, { optimization, compiler: compilerPath });
      }
    }
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }

  // Profile heavy flags — fast must NOT virtualize everything (QB FPS)
  if (profile === 'heavy' || profile === 'max') {
    program.protos.forEach(p => { p.heavy = true; });
  } else if (profile === 'fast') {
    program.protos.forEach(p => { p.heavy = false; });
  } else {
    const nCount = ((native && native.length) || 0) + ((regionInfo && regionInfo.names && regionInfo.names.length) || 0);
    if (nCount === 0 && program.protos[program.main]) {
      program.protos[program.main].heavy = true;
    }
  }

  program.protos.forEach(p => {
    p.engine = p.engine ?? 1;
    p.dispatchMode = p.dispatchMode ?? 0;
  });

  const optimized = optimize(program, {
    enabled: (options.vmOptimization ?? optimization) === 2,
  });
  const nativeCount = ((native && native.length) || 0) + ((regionInfo && regionInfo.names && regionInfo.names.length) || 0);
  const linked = linkProtected(optimized.program, protectedFunctions, nativeCount);

  if (nativeInfo && nativeInfo.literalStrings && nativeInfo.literalStrings.length) {
    const knownStrings = new Map(
      linked.program.strings.map((value, i) => [value.toString('base64'), i + 1])
    );
    linked.program.nativeLiteralStringIds = nativeInfo.literalStrings.map(value => {
      const key = value.toString('base64');
      if (!knownStrings.has(key)) {
        linked.program.strings.push(value);
        knownStrings.set(key, linked.program.strings.length);
      }
      return knownStrings.get(key);
    });
  }

  const result = emit(linked.program, {
    seed,
    profile,
    maxBytes,
    hardMaxBytes,
    vmVariants,
    readable,
    fusion,
    dispatchStyle,
  });

  result.stats.nativeStringCount = (nativeInfo && nativeInfo.literalStrings && nativeInfo.literalStrings.length) || 0;
  result.stats.nativeStringProtection = result.stats.nativeStringCount ? 'authenticated-startup' : 'none';
  result.stats.optimizationPasses = optimized.stats;
  result.stats.protectedFunctions = (linked.groups || []).map(group => ({ ...group }));
  result.stats.runtimeCopies = 1;
  result.stats.nativeFunctions = [...(native || []), ...((regionInfo && regionInfo.labels) || [])];

  if (doOneLine) result.source = oneLine(result.source);

  const vmBytes = Buffer.byteLength(result.source) + Buffer.byteLength(banner);
  if (nativeCount && nativeInfo) {
    nativeInfo.declarations = nativeInfo.declarations.slice(0, nativeCount);
    nativeInfo.nativeNames = nativeInfo.nativeNames.slice(0, nativeCount);
    result.source = wrapNative(result.source, nativeInfo);
  }
  if (doOneLine) result.source = oneLine(result.source);
  result.source = (doOneLine ? oneLine(banner) + ' ' : banner) + result.source;

  result.stats.vmOverheadBytes = vmBytes - (result.stats.payloadBytes || 0);
  const outputBytes = Buffer.byteLength(result.source);
  result.stats.inputBytes = inputBytes;
  result.stats.outputBytes = outputBytes;
  result.stats.ratio = inputBytes ? outputBytes / inputBytes : null;
  result.stats.budgetBytes = maxBytes;
  result.stats.hardBudget = hardMaxBytes;
  result.stats.budgetRemainingBytes = hardMaxBytes - outputBytes;
  result.stats.underPreferred = outputBytes <= maxBytes;
  result.stats.nativeWrapperBytes = outputBytes - vmBytes;
  result.stats.optimization = optimization;
  result.stats.buildMilliseconds = performance.now() - started;
  result.stats.runtimeOverheadNote =
    'Measure in Roblox Script Profiler. Source size does not predict FPS.';

  if (outputBytes > hardMaxBytes) {
    throw new Error(
      'Hard size ceiling exceeded: ' + outputBytes.toLocaleString() + ' > ' + hardMaxBytes.toLocaleString() + ' bytes.'
    );
  }

  // Fail-closed validation: a build that cannot compile or execute its own
  // output is NOT a build. No output file and no report are released.
  if (hasCompiler && !allowSynthetic) {
    const checkDir = mkdtempSync(resolve(tmpdir(), 'kz-validate-'));
    try {
      const temporary = resolve(checkDir, 'protected.luau');
      writeFileSync(temporary, result.source);
      compile(temporary, { compiler: compilerPath, optimization: 1 });
      result.stats.validatedOutput = true;

      // Execution test: if a Luau interpreter is available, actually run the
      // protected output. A runtime crash (e.g. mis-forwarded natives or
      // protected functions) fails the build instead of shipping broken code.
      const runner = ['luau-execute', 'luau'].map(executable).find(p =>
        existsSync(p) || !String(p).includes('tools'));
      if (runner && options.executeTest !== false) {
        const run = spawnSync(runner, [temporary], {
          encoding: 'utf8', timeout: 30000, maxBuffer: 16 * 1024 * 1024,
        });
        if (run.error) {
          throw new Error('Execution test failed to start: ' + run.error.message);
        }
        if (run.status !== 0) {
          throw new Error(
            'Execution test failed (protected output crashed at runtime): ' +
            ((run.stderr || run.stdout || 'exit ' + run.status).slice(0, 400))
          );
        }
        result.stats.executionTest = 'pass';
      } else {
        result.stats.executionTest = runner ? 'skipped (--no-execute)' : 'unavailable (no Luau interpreter found)';
      }
    } catch (e) {
      throw new Error('Build validation failed: ' + (e.message || e));
    } finally {
      rmSync(checkDir, { recursive: true, force: true });
    }
  } else if (allowSynthetic) {
    result.stats.validatedOutput = false;
    result.stats.executionTest = 'skipped (synthetic)';
  }

  if (output) {
    if (existsSync(output) && !force) {
      throw new Error('Output already exists: ' + output + ' (use --force)');
    }
    mkdirSync(dirname(output), { recursive: true });
    const temporary = output + '.' + process.pid + '.tmp';
    try {
      writeFileSync(temporary, result.source);
      renameSync(temporary, output);
    } finally {
      if (existsSync(temporary)) unlinkSync(temporary);
    }
  }

  if (report) {
    mkdirSync(dirname(report), { recursive: true });
    writeFileSync(report, JSON.stringify(result.stats, null, 2) + '\n', 'utf8');
  }

  return result;
}

export function save(output, result, { force = false } = {}) {
  const destination = resolve(output);
  if (existsSync(destination) && !force) {
    throw new Error('Output already exists; use --force to replace it');
  }
  mkdirSync(dirname(destination), { recursive: true });
  const temporary = destination + '.' + process.pid + '.tmp';
  try {
    writeFileSync(temporary, result.source, { flag: 'wx' });
    renameSync(temporary, destination);
  } finally {
    if (existsSync(temporary)) unlinkSync(temporary);
  }
  return destination;
}
