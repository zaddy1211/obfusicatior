/**
 * KZ Codex 0.6 — Staged key & packaging tests
 */
import test from 'node:test';
import assert from 'node:assert/strict';
import { randomBytes } from 'node:crypto';
import {
  splitKey, combineShares, deriveProtoSubkey, deriveWindowKey,
  payloadKey, seal, stream, nonce, associatedData,
} from '../src/key-material.js';
import { emit } from '../src/emit.js';
import { OPS } from '../src/bytecode.js';

function syntheticProgram(heavy = true) {
  const loadnIdx = OPS.indexOf('LOADN');
  const returnIdx = OPS.indexOf('RETURN');
  const loadn = ((loadnIdx & 255) | (0 << 8) | ((42 & 0xffff) << 16)) >>> 0;
  const ret = ((returnIdx & 255) | (0 << 8) | (2 << 16)) >>> 0;
  const numBuf = Buffer.alloc(8);
  numBuf.writeDoubleLE(42, 0);
  return {
    version: 6,
    strings: [Buffer.from('test')],
    protos: [{
      stack: 2, params: 0, ups: 0, vararg: 0,
      code: [loadn, ret],
      constants: [{ tag: 2, value: numBuf }],
      children: [], heavy, engine: 1, dispatchMode: 0,
    }],
    main: 0,
    used: new Set(['LOADN', 'RETURN']),
  };
}

test('splitKey reconstructs master', () => {
  const master = randomBytes(32);
  const { shareA, shareB, shareC } = splitKey(master);
  assert.equal(shareA.length, 32);
  assert.equal(shareB.length, 32);
  assert.equal(shareC.length, 32);
  assert.ok(combineShares(shareA, shareB, shareC).equals(master));
});

test('partial shares never equal master', () => {
  const master = randomBytes(32);
  const { shareA, shareB, shareC } = splitKey(master);
  assert.ok(!shareA.equals(master));
  assert.ok(!shareB.equals(master));
  assert.ok(!shareC.equals(master));
  const ab = Buffer.alloc(32);
  for (let i = 0; i < 32; i++) ab[i] = shareA[i] ^ shareB[i];
  assert.ok(!ab.equals(master));
});

test('proto subkeys are deterministic and distinct', () => {
  const master = randomBytes(32);
  const nonce = Buffer.from('build-nonce');
  const a = deriveProtoSubkey(master, 1, nonce);
  const b = deriveProtoSubkey(master, 1, nonce);
  const c = deriveProtoSubkey(master, 2, nonce);
  assert.ok(a.equals(b));
  assert.ok(!a.equals(c));
  assert.equal(a.length, 32);
});

test('window keys change with counter', () => {
  const sub = randomBytes(32);
  const k0 = deriveWindowKey(sub, 0);
  const k1 = deriveWindowKey(sub, 1);
  assert.ok(!k0.equals(k1));
});

test('seeded payloadKey is deterministic', () => {
  const a = payloadKey({ x: 1 }, 'seed');
  const b = payloadKey({ x: 1 }, 'seed');
  const c = payloadKey({ x: 2 }, 'seed');
  assert.ok(a.equals(b));
  assert.ok(!a.equals(c));
});

test('seal/open roundtrip via stream domains', () => {
  const key = randomBytes(32);
  const data = Buffer.from('hello staged keys');
  const encrypted = stream(data, key, 4, 7);
  assert.ok(!encrypted.equals(data));
  // stream is symmetric XOR-style for same counter path
  const again = stream(encrypted, key, 4, 7);
  assert.ok(again.equals(data));
});

test('AEAD seal produces tag', () => {
  const key = randomBytes(32);
  const iv = nonce(0, 1);
  const aad = associatedData(1, 0, 0, 5, 5);
  const { ciphertext, tag } = seal(Buffer.from('hello'), key, iv, aad);
  assert.equal(tag.length, 16);
  assert.ok(ciphertext.length >= 5);
});

test('emit produces staged output under budget', () => {
  const program = syntheticProgram(true);
  const result = emit(program, {
    seed: 'test-seed',
    profile: 'heavy',
    vmVariants: 3,
    readable: true,
    maxBytes: 1_700_000,
    hardMaxBytes: 1_900_000,
  });
  assert.ok(result.source.includes('shareA'));
  assert.ok(result.source.includes('ensureShareC') || result.source.includes('shareC'));
  assert.ok(result.source.includes('WINDOW_SIZE') || result.source.includes('instrWindow'));
  assert.ok(result.source.includes('makeWindow'));
  assert.equal(result.stats.keySplit, true);
  assert.ok(result.stats.outputBytes < 1_700_000);
  assert.ok(result.stats.enginesAssigned >= 1);
});

test('emit respects hard size ceiling', () => {
  const program = syntheticProgram(true);
  assert.throws(() => {
    emit(program, { seed: 'x', hardMaxBytes: 100, maxBytes: 50 });
  }, /ceiling|budget|exceeded/i);
});

test('different seeds produce different share A', () => {
  const program = syntheticProgram(true);
  const a = emit(program, { seed: 'seed-a', readable: true });
  const b = emit(program, { seed: 'seed-b', readable: true });
  // Share A words appear in source; different seeds → different keys
  assert.notEqual(a.source, b.source);
});

test('AEAD rejects tampered ciphertext via different tag', () => {
  const key = randomBytes(32);
  const iv = nonce(0, 9);
  const aad = associatedData(9, 2, 1, 4, 4);
  const { ciphertext, tag } = seal(Buffer.from('test'), key, iv, aad);
  const tampered = Buffer.from(ciphertext);
  tampered[0] ^= 0xff;
  const { tag: tag2 } = seal(Buffer.from('test'), key, iv, aad);
  // Same plaintext same tag; tampered is different bytes
  assert.ok(tag.equals(tag2));
  assert.ok(!tampered.equals(ciphertext));
});

test('heavy emit includes streamKey path markers', () => {
  const program = syntheticProgram(true);
  const result = emit(program, { seed: 'stream', profile: 'heavy', readable: true });
  assert.ok(result.source.includes('streamKey'));
  assert.ok(result.source.includes('ensureMaster'));
  assert.ok(result.stats.perProtoSubkeys >= 1);
});

test('production build strips comments', () => {
  const program = syntheticProgram(true);
  const result = emit(program, { seed: 'prod', profile: 'balanced', readable: false });
  const commentLines = result.source.split('\n').filter(l => l.trimStart().startsWith('--'));
  assert.equal(commentLines.length, 0);
});

test('compress/decompress 3-byte match format is consistent in Node', async () => {
  const { compress } = await import('../src/codec.js');
  const samples = [
    Buffer.from('hello world hello world hello'),
    Buffer.alloc(200, 0x41),
    randomBytes(64),
  ];
  for (const data of samples) {
    const packed = compress(data);
    // Manual expand matching runtime 3-byte format
    const out = Buffer.alloc(data.length);
    let cursor = 0, o = 0;
    while (cursor < packed.length && o < data.length) {
      const flags = packed[cursor++];
      for (let bit = 0; bit < 8 && o < data.length && cursor < packed.length; bit++) {
        if ((flags & (1 << bit)) === 0) {
          out[o++] = packed[cursor++];
        } else {
          const distance = packed[cursor] | (packed[cursor + 1] << 8);
          const length = packed[cursor + 2] + 3;
          cursor += 3;
          for (let n = 0; n < length && o < data.length; n++) {
            out[o] = out[o - distance];
            o++;
          }
        }
      }
    }
    assert.ok(out.equals(data), 'roundtrip mismatch');
  }
});

test('AEAD open succeeds on authentic seal', async () => {
  const { seal, open, nonce, associatedData } = await import('../src/key-material.js');
  const key = randomBytes(32);
  const iv = nonce(0, 3);
  const aad = associatedData(3, 0, 0, 11, 11);
  const plain = Buffer.from('hello world');
  const { ciphertext, tag } = seal(plain, key, iv, aad);
  const out = open(ciphertext, tag, key, iv, aad);
  assert.ok(out.equals(plain));
});

test('AEAD open rejects bit-flipped ciphertext', async () => {
  const { seal, open, nonce, associatedData } = await import('../src/key-material.js');
  const key = randomBytes(32);
  const iv = nonce(0, 4);
  const aad = associatedData(4, 2, 1, 4, 4);
  const { ciphertext, tag } = seal(Buffer.from('test'), key, iv, aad);
  const bad = Buffer.from(ciphertext);
  bad[0] ^= 0xff;
  assert.throws(() => open(bad, tag, key, iv, aad));
});

test('AEAD open rejects bit-flipped tag', async () => {
  const { seal, open, nonce, associatedData } = await import('../src/key-material.js');
  const key = randomBytes(32);
  const iv = nonce(0, 5);
  const aad = associatedData(5, 0, 0, 4, 4);
  const { ciphertext, tag } = seal(Buffer.from('test'), key, iv, aad);
  const badTag = Buffer.from(tag);
  badTag[0] ^= 0xff;
  assert.throws(() => open(ciphertext, badTag, key, iv, aad));
});

test('wrong share material cannot open bootstrap-shaped seal', async () => {
  const { seal, open, splitKey, nonce, associatedData } = await import('../src/key-material.js');
  const master = randomBytes(32);
  const { shareA, shareB } = splitKey(master);
  const iv = nonce(0, 1);
  const aad = associatedData(1, 5, 0, 32, 32);
  const { ciphertext, tag } = seal(shareB, shareA, iv, aad);
  const wrongA = randomBytes(32);
  assert.throws(() => open(ciphertext, tag, wrongA, iv, aad));
  // correct share opens
  const recovered = open(ciphertext, tag, shareA, iv, aad);
  assert.ok(recovered.equals(shareB));
});
