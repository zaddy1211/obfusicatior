# QB Smart Fit — build configuration (0.6.2)

## Intended split (verified)

| Function | Treatment | Reason |
|----------|-----------|--------|
| Solver (Smart Fit core) | `--native` | Per-frame; VM dispatch = ~1 FPS |
| Track (cut / predict) | `--native` | Called every frame with solve |
| Targeting (select WR/DB) | `--native` | Hot path |
| Routes (frequent calls) | `--native` | Hot if called per throw |
| Field | `--protect` | **Only after** the protected path passes the execution test |
| Beam | `--protect` | Visual only; **only after** the protected path passes |

Names must be exact top-level `local function` names in your source:

```powershell
node scripts/list-natives.mjs "kz ff3 better rewrite.lua"
```

## Build command

```powershell
node src/cli.js "kz ff3 better rewrite.lua" -o output/protected.luau `
  --profile fast -O 2 --vm-variants 1 --one-line --force `
  --native Solver --native Track --native Targeting --native Routes `
  --protect Field --protect Beam `
  --report output/protected.report.json
```

(Replace names with the real ones from `list-natives`.)

## Gates (now enforced by the build itself)

1. **Fail-closed validation.** If the protected output does not compile, or the
   execution test crashes, the build exits non-zero, prints the failure, and
   releases **no output file and no report**. There is no "build complete"
   line for a broken build.
2. **Protected-path gate.** `--protect Field --protect Beam` is safe to add
   precisely because of gate 1: the execution test runs the protected output
   before release. If the protected path regresses (mis-forwarded arguments,
   VM crash), the build fails instead of shipping a nil-call crash in-game.
   If you must bypass the runtime test temporarily, use `--no-execute`
   (compile validation still enforced; report shows `skipped`).
3. **Report checks.** `nativeFunctions` must list Solver/Track/Targeting/Routes;
   `protectedFunctions` must list Field/Beam with their entry proto ids;
   `executionTest: "pass"`; `outputBytes` < 1,900,000.

## What NOT to do

- Do not drop `--native` from the four hot paths to "add protection" — that is
  the ~1 FPS regression.
- Do not `--protect` the solver.
- Do not pad output toward the 1.9 MB ceiling; current overhead is ~36 KB of
  runtime for a 1.2 KB script and scales with program size, not with budget.
- Do not re-enable fusion until real e2e coverage exists for it.
