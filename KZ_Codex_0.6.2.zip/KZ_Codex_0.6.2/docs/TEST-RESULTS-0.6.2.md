# Test results — 0.6.2 (this session)

Environment: Node 20, official Luau 0.694 CLI tools (luau, luau-ast,
luau-compile) on PATH. All builds below are **real compiles**, not synthetic.

## Fix 1 — `--protect` forwarding (was: "attempt to call a nil value")

Root cause: `linkProtected` recorded each protected function's entry proto in
`program.injections`, but the emitted entry point only forwarded the *native*
injected arguments to the main proto. Protected argument slots were left
unfilled, so the first call to a protected function called nil.

Fix: the entry now instantiates each injected protected proto once at startup
(`make(protos[entry],{},getfenv(0))()`) and forwards the resulting functions
to the main proto **in declaration order**: natives first, then protected —
matching the parameter order `prepareNative` generates.

Also fixed en route: `native-literals.js` derived the interpreter path from
`dirname(luau-ast)`, which broke when `luau-ast` came from PATH (resolved to
`<cwd>/luau` → ENOENT). Bare tool names now resolve the interpreter via PATH.

Verified (each build runs its protected output under `luau`; the fixture
asserts every native and protected function's return values):

| Build | Result |
|-------|--------|
| 4 natives + 2 protected (Solver, Track, Targeting, Routes / Field, Beam), fast, O2, one-line | **execution test: pass** |
| protect-only (Field, Beam, no natives) | **pass** |
| native + protect, heavy profile, 2 VM variants | **pass** |
| balanced, no selections | **pass** |

## Fix 2 — failed validation stops the build

- Output compile validation failure → build throws, exit 1.
- New runtime execution test: when a Luau interpreter is available, the
  protected output is executed before release; any crash → build throws.
  Opt-out: `--no-execute` (compile validation still enforced).
- Nothing is written on failure: no output file, no report, no
  "build complete" line. (Writes remain atomic via temp-file + rename.)

Negative tests:

| Case | Expected | Actual |
|------|----------|--------|
| Input compiles but errors at runtime | build fails, no output | **exit 1, no output file** |
| Input with syntax errors | build fails, no output | **exit 1, no output file** |

This gate already caught one real defect during the session (a malformed
numeric rewrite emitting a Lua `--` comment) and one bad test fixture —
both before any output was released.

## Fix 3 — intended split

Verified with a QB-shaped fixture mirroring the intended split: hot paths
native, Field/Beam protected. Build config with gates:
`docs/BUILD-CONFIG-QB.md`. Field/Beam protection is now self-gating — a
protected-path regression fails the build automatically.

## Fix 5 — native algorithm strengthening

Exposed native numeric literals now use structurally varied exact identities,
not only single-term masking: 3-term additive split, subtract-back, double-xor,
and 8-bit shift/bor decomposition. All forms verified exact (including
negative-value edge cases) across 8 seeds; unit tests 20/20. Kept selective:
values in [-2, 2] and |n| > 1e7 are untouched to avoid hot-path noise.

## Fix 6 — recovery regression target

`tests/recovery.test.js` implements the documented Codex v6 extractor
(Share A unmask → bootstrap → Share B → Share C → master → open all sections
→ parse manifest), running source-only against real build output:

- **Extractor recovers everything: PASS (as expected).** Every sealed section
  opens offline; manifest and strings recovered. This is the documented
  posture — staged keys raise live-dump cost, not offline extraction.
- **Unsigned corruption rejected: PASS.** A single flipped character in a
  sealed payload fails ChaCha20-Poly1305 authentication.

If this test ever starts failing because extraction got harder, treat it as
limited evidence only — get a separate blind assessment before claiming
improvement. It has NOT been done; no such claim is made.

## Full suite

`node --test tests/` — **20 pass, 0 fail** (keys, emit, recovery, tamper).
`node src/selftest-keys.js` — pass.

## Size

QB-shaped fixture: 1,245 B input → 36,167 B output (one line). Well under the
1,700,000 preferred / 1,900,000 hard budgets. No padding added.
