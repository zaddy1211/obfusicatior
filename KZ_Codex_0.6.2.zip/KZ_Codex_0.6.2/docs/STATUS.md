# KZ Codex 0.6.1 — Status

## Done in this session

### Correctness (Codex P0)
- Fail-closed compiler discovery (`--synthetic` explicit only)
- LZSS 3-byte match format aligned
- Opcode name→id map (no more all-zeros)
- Single section ID assignment
- Instruction window first-fetch fix
- Windowed string `text()` path
- Dispatch helper operands for blocks/table
- `decode` kind/owner checks
- Real AEAD open + mutation tests (ciphertext/tag/wrong share)

### FPS path
- Full hybrid pipeline restored (`--native`, `--native-region`, `--protect`, `--one-line`)
- `fast` profile does not force all-heavy
- CLI warns when fast + zero natives
- `scripts/list-natives.mjs` lists top-level locals for selection
- `docs/REBUILD-FPS.md` procedure

### Misc
- Removed redundant `table.freeze(getmetatable(registry))`
- Production comment strip (incl. indented)
- streamKey in manifest for heavy inner streams
- Lazy `ensureMaster` + share wipe
- 18/18 unit tests passing

## You must do on the game machine
1. Profiler names while holding ball
2. Rebuild with `--native` on those names only
3. Remeasure Smart Fit FPS
4. Re-run Codex e2e harness if available

## Still open
- Fusion (keep off)
- Full prepare() parity with 0.5.4 jump/fusion recipe checks
- Multi-runner dispatch bodies
- Roblox FPS numbers (environment cannot measure)

# 0.6.2 — Status update

## Fixed
- `--protect` forwarding: linked protected functions are instantiated at startup
  and forwarded to the main proto in correct argument positions (natives first,
  then protected). Nil-call crash on protected functions resolved; covered by
  the new mandatory execution test.
- `native-literals.js` PATH resolution (bare `luau-ast` no longer resolves the
  interpreter to `<cwd>/luau`).
- Fail-closed builds: compile validation or execution-test failure aborts the
  build — no output, no report, no "build complete". `--no-execute` opts out of
  the runtime test only.
- Native literal hardening: structurally varied exact identities (3-term split,
  subtract-back, double-xor, shift/bor) replacing single-form number masking.

## Added
- `tests/recovery.test.js` — documented extractor as regression target
  (recovers everything: expected baseline) + unsigned-corruption rejection.
- `docs/BUILD-CONFIG-QB.md`, `docs/MEASURE-SMART-FIT.md`,
  `docs/TEST-RESULTS-0.6.2.md`, `docs/LIMITATIONS-0.6.2.md`
- `scripts/measure-smart-fit.luau` — in-game frame-time harness

## Tests
- `node --test tests/` — 20/20 pass (with Luau 0.694 tools)
- Real native+protect / protect-only / heavy / balanced builds: execution pass

# 0.6.3 — Hardening pass (keys + anti-tamper + math)

## Changed
- **Share A embedding** is no longer a trivial `m={}/x={}` pair. It now uses
  interleaved even/odd tables, a secondary mask derived from the build magic
  bytes, and a per-build rotate. The old Codex-v6 extractor fails; the updated
  recovery test implements the new reconstruction and still recovers everything
  (expected baseline — offline recovery remains possible, just costlier).
- **Anti-tamper**: non-fast profiles checksum a few section descriptors at
  startup in addition to the existing arithmetic/self-test probes.
- **Optimizer**: small integer `POW` (exponent 0..10) is now constant-folded.
- New guidance: `docs/MATH-PERFORMANCE.md` for math-heavy scripts.

## Residual (unchanged honesty)
- Offline key recovery is still possible once the new parser is written.
- AEAD still authenticates holders of the embedded key (resealing is possible).
- Hot math must stay `--native`; putting it in the heavy VM destroys FPS.
