# KZ Codex 0.6 (Hardened)

Improved Luau/Roblox obfuscator built on the 0.5.4 foundation with a focus on **harder dynamic analysis**, **staged keys**, and a **1.7 MB preferred / 1.9 MB hard** size budget.

> Obfuscation raises analysis cost. It cannot make client code impossible to recover.
> Keep secrets and authoritative decisions on the server.

## What’s new vs 0.5.4

| Feature | 0.5.4 | 0.6 |
|---------|-------|-----|
| Master key | Single contiguous 32-byte key | **3-way XOR split** (A / B / C) |
| Key lifetime | Present for whole run | **Stage-gated**; never all three at once |
| Per-function keys | Shared master stream | **32-byte subkey per prototype** |
| Constants | Long-lived decoded values | **Ephemeral rotating window** (12 slots) |
| Heavy instructions | On-demand full stream | **Sliding window** (~6 instructions) |
| Loader | Single stage | **3-stage** (bootstrap → sections → heavy) |
| Handler diversity | Present | **Per-build diversification** |
| Multi-runner | Present | **Engine assignment + manifest tables** |
| Size budget | 1.5 MB | **Preferred 1.7 MB / hard 1.9 MB** |

## Requirements

- Node.js 22+
- Official **Luau 0.694** CLI tools (for real compilation)
  - Without Luau, the pipeline still runs on a synthetic program for testing security foundations

## Quick start

```bash
# Self-test cryptographic foundations
node src/selftest-keys.js

# Unit tests
node --test tests/keys.test.js

# Build (synthetic fallback if Luau is missing)
node src/cli.js examples/demo.luau -o output/demo.kz.luau \
  --profile heavy --vm-variants 3 --seed dev --force --readable \
  --report output/demo.report.json
```

With Luau 0.694 installed and on `PATH` (or under a known tools path), the same command compiles real bytecode.

## Profiles

| Profile | Behavior |
|---------|----------|
| `balanced` | Default. Staged keys, selective heavy, inline dispatch |
| `heavy` | All protos heavy, control-flow flatten, blocks dispatch option |
| `max` | Maximum protection within budget; more variants |
| `fast` | Faster paths; less diversification |

## Security model (honest)

Still **client-side**. A skilled attacker who fully controls the Luau executor can eventually recover the program.

Hard facts, no marketing:

- **Embedded keys remain recoverable.** Share A and the bootstrap chain ship in the output; offline recovery of the master key and all sections is expected. `tests/recovery.test.js` is the regression baseline proving the documented extractor still recovers everything.
- **Authentication ≠ modification resistance.** ChaCha20-Poly1305 rejects *unsigned* corruption (bit-flips fail tag checks). Someone who recovers the embedded key **can** generate valid modified payloads.
- Native functions are renamed ordinary Luau — recoverable once the startup string pool opens. That is the FPS tradeoff, intentional.
- Constant/instruction windows shorten *live memory* lifetime; they do not hinder offline bulk extraction.

0.6 raises the cost of:

- Writing a reliable automated dumper (staged keys + windows)
- Recovering a clean source from a **single** memory snapshot
- Reusing a dump of one function against other functions (per-proto subkeys)

Expected effect vs 0.5.4: dynamic analysis moves from “a few hours” toward “a full day or more” for a typical script, while staying inside the size limit.

## Project layout

```
src/
  key-material.js      Staged split keys, subkeys, AEAD helpers
  ephemeral-constants.js  Rotating constant window
  segments.js          Packaging with staged seal hierarchy
  emit.js              Emitter (runtime template + handlers)
  runtime.luau         Generated runtime template
  build.js / cli.js    Build entry + CLI
  handlers.js          Opcode handlers
  diversity.js         Dispatch tree generation
  …                    bytecode, fusion, control-flow, etc.
tests/
  keys.test.js         Staged key + emit tests (10 passing)
docs/
  DESIGN-0.6.md        Design rationale
  STATUS.md            Implementation status
```

## Size discipline

1. Prefer algorithmic complexity over data size  
2. No large decoy tables  
3. No second full interpreter  
4. Window sizes stay small (≤16 constants, ≤6 instructions)  
5. Share C only materialized for heavy functions  

## License / heritage

Built as a hardened evolution of KZ Codex 0.5.x ideas.  
Crypto is standard RFC 8439 ChaCha20-Poly1305.  
No claim of unprecedented reverse-engineering resistance.
