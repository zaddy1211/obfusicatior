# `luau-obfuscate` User Guide

## 1. Overview
`luau-obfuscate` is a local, offline command-line obfuscator engineered for Roblox Luau developers. It translates sensitive game logic into a hardened virtual machine representation with zero cloud dependencies, zero telemetry, and certified bit-for-bit semantic equivalence with native Luau.

---

## 2. Quick Start

### Basic Obfuscation
```bash
./bin/luau-obfuscate input.luau -o output.luau
```

### 1-Line Minified Obfuscation (Roblox Studio Ready)
```bash
./bin/luau-obfuscate input.luau -o output.luau --minify
```
The output file contains exactly 1 continuous line of code, ready to be pasted directly into a `Script`, `LocalScript`, or `ModuleScript`.

### Custom Seed for Deterministic Builds
```bash
./bin/luau-obfuscate input.luau -o output.luau --seed 20261026 --minify
```

---

## 3. Command-Line Options

| Option | Argument | Description |
|---|---|---|
| `INPUT` | File path | Source Luau script to obfuscate |
| `-o, --output` | File path | Output path for the obfuscated script |
| `--profile` | `balanced`, `strong`, `maximum`, `native` | Protection profile (default: `balanced`) |
| `--minify`, `--single-line` | Flag | Produces a compact single-line output script (0 newlines) |
| `--seed` | Integer | 64-bit integer seed for deterministic compilation |
| `--harden` / `--no-harden` | Flag | Enable or disable multi-layer VM hardening (default: ON) |
| `--report` | File path | Export a JSON sizing, audit, and performance report |
| `--ir` | File path | Export semantic register IR to JSON |
| `--bytecode` | File path | Export raw Luau compiler bytecode |
| `--info` | Flag | Display compiler pin and version information |
| `-h, --help` | Flag | Display complete help and usage text |

---

## 4. Execution Profiles

### `strong-smooth` (Default)
Recommended for client gameplay scripts, UI controllers, and render loops. Automatically detects sensitive functions (e.g. anti-cheat, licensing, cryptographic math) and virtualizes them into the hardened VM while keeping non-sensitive loops running natively to maintain 60 FPS on desktop and mobile.

### `whole-vm`
Virtualizes every single function in the script into the custom VM. Maximum security against reverse-engineering and automated lifters. Ideal for authentication tokens, server-side economy handlers, and core proprietary algorithms.

### `native`
Applies source-level obfuscation, control flow flattening, and constant encryption without full VM virtualization. Minimal runtime overhead.

---

## 5. Automated Red-Team Validation

To verify the security of obfuscated scripts against modern automated lifters (*Pushan*, *VMPredator*, `vmmap.js`), run the included red-team evaluation suite:
```bash
python3 tests/redteam_suite.py
```
This tests:
1. **Cleartext String & Method Leakage**: Confirms zero sensitive identifiers are exposed.
2. **Cross-Build Opcode Invariance**: Verifies dynamic Fisher-Yates opcode permutation across seeds.
3. **AST Dispatcher Structural Similarity**: Confirms dispatcher AST similarity drops below 65%.
4. **Universal Automated Disassembly**: Verifies lifters fail to recover instruction streams.
5. **Semantic Correctness**: Asserts bit-exact execution parity with native Luau.

---

## 6. Full Regression Testing

To run the complete 1,200-test semantic regression suite:
```bash
python3 tests/test_cli.py
```
