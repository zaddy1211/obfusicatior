# Threat Model & Security Terminology — v3.4 Architecture

This document defines *precisely* what the obfuscator does and does not claim.
It exists because earlier revisions conflated **obfuscation** with
**cryptography**, which an external audit correctly flagged.

## 1. Deployment model

- The product is a **local, offline CLI**. Output is a single self-contained
  Luau script.
- Target runtime: normal Roblox Luau (desktop, mobile, server). No
  executor-specific APIs are required or used.
- There is **no out-of-band secret**: no license server, no env var, no
  purchaser key. Everything needed to decode the artifact ships inside the
  artifact.

## 2. The white-box ceiling (fundamental, not a defect)

Because the VM interpreter and its input buffer necessarily coexist in one
shipped file, a skilled analyst holding that file can — with per-build effort —
recover the working decode state and, ultimately, the program. This is a law of
the problem shape, not an implementation flaw. We make **no** claim of
cryptographic confidentiality of the payload.

The security objective is therefore **economic, not absolute**:

> A reusable, generic, automated deobfuscation tool must not be able to break a
> new build cheaply; analysis cost must re-start near zero for *every* build.

## 3. What is public, what is per-build

| Item | Status | Notes |
|---|---|---|
| Build seed (64-bit) | **Public** | Build-diversity material only. Never a security boundary. |
| `stretch` round count (1024) | Public constant | Fixed both sides. |
| Header layout descriptor `L32` | Public (cleartext slot 0) | Drives per-build slot permutation. |
| Split key `_KSPLIT` | Per-build, embedded **only in the runtime text** | Prevents buffer-only decoding. Recoverable by full-artifact analysis (ceiling). |
| KDF algorithm variant `cfg` | Per-build (2 constant families × extra-round bit) | Derived from working state; a decoder from build A is wrong for build B even after recovery procedure is known. |
| All domain constants | Public constants | Domain separation is collision hygiene, not secrecy. |

## 4. Encoding (not encryption) claims

The buffer uses domain-separated, position-entangled keyed *encodings*:

- opcode / operand / sub-opcode permutation spaces (7 spaces),
- string and constant keystreams (32-bit LCG, position-mixed),
- prototype slice keystreams,
- jump-target and closure-offset masks,
- permuted, masked buffer header.

These are **reversible obfuscation transforms**. They are deliberately *not*
called encryption in docs, CLI output, or code comments. `std::mt19937_64` is
used for build-internal diversity; build seeds come from `std::random_device`
(OS entropy) unless the user pins `--seed` for reproducibility.

## 5. Integrity model (what anti-tamper *does*)

Anti-tamper exists to detect **accidental corruption and casual patching**, not
a determined in-process attacker with arbitrary memory write.

| Check | When | Coverage |
|---|---|---|
| Startup environment invariants (bit32/buffer/rawset/rawequal sanity) | load | engine environment tamper |
| Full-buffer authenticated checksum (every byte except the checksum slot) | load | all serialized content incl. header & decoy slots |
| Header word spot re-checks | ongoing (Maximum profile) | casual header overwrite |
| Pseudo-random 4-word sampling, authenticated against pristine reference (decoded spans re-derived from keystream; raw compare elsewhere) | ongoing (Maximum, every 256 dispatched instructions) | statistical ongoing integrity |
| Per-closure re-verification of decoded prototype bytes | ongoing (Maximum, on meta-cache hits) | prototype body patching |

Known integrity limitations:
- Sampling is statistical, not a MAC over every executed instruction.
- An attacker who can hook arbitrary Luau/library functions before the VM loads
  (or rewrite the runtime text itself) is out of scope by definition — that is
  the white-box ceiling restated.
- Debug-library introspection of live VM frames (register arrays, upvalue
  boxes, decoded strings) is explicitly out of scope: values must be plaintext
  at point of use in any VM interpreter.

## 6. Retention & runtime-observability policy

| Data | Policy |
|---|---|
| Opcode decode cache | Position-masked values; disabled entirely at Maximum (decode-per-dispatch). |
| Mask memo caches (`m8/m32/operand`) | Memoized at Balanced/Strong; never memoized at Maximum. |
| Inline string cache | Bounded (Balanced 256 / Strong 512 entries, clear-on-full), sensitive-tagged strings never cached; disabled at Maximum. |
| Constant-pool sensitive strings | Not retained in shared prototype metadata; decoded per closure instantiation. Exception: strings semantically required as table-shape keys/values are promoted into the shared pool because the resulting table necessarily holds the plaintext. |
| Method wrapper table | Emitted with *only* the method names the program actually invokes. Required for `__namecall` semantics (a dynamic key cannot form a namecall expression); documented residual exposure. |
| Prototype metadata cache | Shared per prototype (perf); contains plaintext constants. Documented necessity: the VM must hold usable values. |

## 7. What is intentionally stable (documented invariants)

- 32-byte header with cleartext `L32` descriptor at offset 0.
- One monolithic `buffer.fromstring(...)` payload per artifact.
- The runtime helper set exists in every build (their *names* and dispatcher
  *structure* vary per build; their *presence* does not).
- Error codes `0x01`–`0x0D` taxonomy is stable (debuggability trade-off,
  accepted).

## 8. Explicitly out of scope

- Protection against a hostile host environment that pre-hooks engine APIs.
- Cryptographic confidentiality of payload against an analyst holding the file.
- Timing- and memory-scanner resistance at the C level.
- Anti-debug escalation beyond engine-environment invariant checking.

Resistance objectives ("15+ days") are treated as **experimentally defined
targets** measured by the red-team harness (`tests/redteam_suite.py`,
`tests/recovery_harness.py`), not as guarantees.
