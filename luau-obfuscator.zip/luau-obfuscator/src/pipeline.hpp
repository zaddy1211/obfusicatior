#pragma once
#include "model.hpp"
#include <string>
#include <vector>
#include <set>
#include <map>
#include <utility>

namespace p7 {

enum class Profile {
    Balanced,     // Low-overhead hybrid for general scripts / UI
    Strong,       // Whole-script hardened VM virtualization
    Maximum,      // Maximum security: full VM + ongoing authenticated integrity sampling
    Native        // Pass-through / native obfuscation
};

struct ObfuscationOptions {
    std::string inputPath;
    std::string outputPath;
    std::string reportPath;
    std::string irPath;
    std::string bytecodePath;
    std::string customRuntimePath;

    Profile profile = Profile::Strong;
    uint64_t seed = 0;
    int optLevel = 1;
    int debugLevel = 1;
    bool harden = true;
    bool dataOnly = false;
    bool minify = false;
    bool reproducible = false;
    bool debugMode = false;
};

struct PolicyAuditReport {
    std::string targetFile;
    std::string profileSelected;
    uint64_t seedUsed = 0;
    bool containsSensitiveLogic = false;
    std::vector<std::string> detectedSensitiveTokens;
    size_t originalSizeBytes = 0;
    size_t outputSizeBytes = 0;
    size_t functionCount = 0;
    size_t instructionCount = 0;
    std::map<std::string, int> opcodeDistribution;
    // Machine-readable transformation manifest (F10): ordered name -> status/detail.
    std::vector<std::pair<std::string, std::string>> transformations;
    int sensitiveStringCount = 0;
    std::string seedSource;
    std::string selfCheck = "passed";
};

// Pipeline entry points
PolicyAuditReport runPipeline(const ObfuscationOptions& opts);
std::string exportReportJson(const PolicyAuditReport& report);

} // namespace p7
