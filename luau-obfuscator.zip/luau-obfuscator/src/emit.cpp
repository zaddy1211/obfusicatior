#include "model.hpp"
#include "Luau/Bytecode.h"
#include <sstream>
#include <iomanip>
#include <random>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <numeric>
#include <cctype>
#include <map>

namespace p2 {

std::string quoteJson(const std::string& x){std::ostringstream o;o<<'"';for(unsigned char c:x){if(c=='"')o<<"\\\"";else if(c=='\\')o<<"\\\\";else if(c<32||c>=127)o<<"\\u00"<<std::hex<<std::setw(2)<<std::setfill('0')<<int(c)<<std::dec;else o<<char(c);}o<<'"';return o.str();}
std::string quoteLua(const std::string& x){std::ostringstream o;o<<'"';for(unsigned char c:x){if(c=='"')o<<"\\\"";else if(c=='\\')o<<"\\\\";else if(c<32||c>=127)o<<'\\'<<std::setw(3)<<std::setfill('0')<<int(c);else o<<char(c);}o<<'"';return o.str();}
std::string numberLua(double x){if(std::isnan(x))return "(0/0)";if(std::isinf(x))return x<0?"(-1/0)":"(1/0)";if(x==0&&std::signbit(x))return "(-0.0)";std::ostringstream o;o<<std::setprecision(17)<<x;return o.str();}

namespace {
std::string bits(double v){uint64_t n;std::memcpy(&n,&v,8);std::string s;for(int i=0;i<8;++i)s+=char((n>>(i*8))&255);return s;}
std::string hex(const std::string& s){std::ostringstream o;for(unsigned char c:s)o<<std::hex<<std::setw(2)<<std::setfill('0')<<int(c);return o.str();}
const char* kind(int t){switch(t){case 0:return "nil";case 1:return "boolean";case 2:return "number";case 3:return "bytes";case 4:return "import_marker";case 5:case 8:return "table_shape";case 6:return "closure";case 7:return "vector3";default:throw Failure("E_EMIT: unsupported constant");}}
std::string setJson(const std::set<int>& s){std::ostringstream o;o<<'[';bool comma=false;for(int v:s){if(comma)o<<',';comma=true;o<<v;}o<<']';return o.str();}
std::string stringSet(const std::set<std::string>& s){std::ostringstream o;o<<'[';bool comma=false;for(const auto& v:s){if(comma)o<<',';comma=true;o<<quoteJson(v);}o<<']';return o.str();}
std::string refJson(Ref r){const char* names[]={"register","constant","immediate","nil","boolean"};std::ostringstream o;o<<"{\"kind\":"<<quoteJson(names[r.tag]);if(r.tag<2)o<<",\"index\":"<<r.index;else if(r.tag==2)o<<",\"value\":"<<numberLua(r.number);else if(r.tag==4)o<<",\"value\":"<<(r.index?"true":"false");o<<'}';return o.str();}
std::string refLua(Ref r){std::ostringstream o;o<<'{'<<r.tag<<','<<(r.tag==2?numberLua(r.number):std::to_string(r.index))<<'}';return o.str();}
std::string effectJson(uint32_t mask){std::ostringstream o;o<<'[';bool comma=false;const char* names[]={"read","write","call","throw","yield","allocate","control","cell_alias"};for(int i=0;i<8;++i)if(mask&(1u<<i)){if(comma)o<<',';comma=true;o<<quoteJson(names[i]);}o<<']';return o.str();}

void identifier(const std::string& s){
 if(s.empty()||!(std::isalpha(static_cast<unsigned char>(s[0]))||s[0]=='_'))throw Failure("E_BINDING: invalid global/method identifier");
 for(unsigned char c:s)if(!(std::isalnum(c)||c=='_'))throw Failure("E_BINDING: invalid identifier bytes");
 static const std::set<std::string> words={"and","break","do","else","elseif","end","false","for","function","if","in","local","nil","not","or","repeat","return","then","true","until","while"};
 if(words.count(s))throw Failure("E_BINDING: keyword used as identifier");
}

static std::string formatBinaryString(const std::vector<uint8_t>& bytes) {
    std::string out;
    out.reserve(bytes.size() * 3);
    for (uint8_t b : bytes) {
        if (b >= 32 && b <= 126 && b != '\\' && b != '"') {
            out.push_back(char(b));
        } else if (b == '\\') {
            out += "\\\\";
        } else if (b == '"') {
            out += "\\\"";
        } else {
            out += '\\';
            char buf[4];
            snprintf(buf, sizeof(buf), "%03u", b);
            out += buf;
        }
    }
    return out;
}

// =============================================================================
// Domain Separation Constants (mirrored 1:1 in runtime.luau; both sides derive
// all masks and permutations deterministically from the build seed. The seed is
// PUBLIC build-diversity material, not a secret; see docs/THREAT_MODEL.md).
// =============================================================================
constexpr uint32_t DOMAIN_KDF_CONSTANTS = 0x6A09E667u;
constexpr uint32_t DOMAIN_KDF_STRINGS   = 0xBB67AE85u;
constexpr uint32_t DOMAIN_KDF_BRANCH    = 0x3C6EF372u;
constexpr uint32_t DOMAIN_KDF_CLOSURE   = 0x4A8F64D1u;
constexpr uint32_t DOMAIN_KDF_OPCODE    = 0x7E7E9191u;
constexpr uint32_t DOMAIN_KDF_PROTO     = 0xA54FF53Au;
constexpr uint32_t DOMAIN_KDF_HEADER    = 0x51A7E29Du;
constexpr uint32_t DOMAIN_KDF_OPERAND   = 0xC2B2AE3Du;

static inline uint32_t blendSeed(uint64_t seed) {
    return (uint32_t(seed) ^ (uint32_t(seed >> 32) ^ 0x9E3779B9u)) & 0xFFFFFFFFu;
}

static inline uint32_t avalancheMix(uint32_t h) {
    h ^= (h >> 16);
    h *= 0x85EBCA6Bu;
    h ^= (h >> 13);
    h *= 0xC2B2AE35u;
    h ^= (h >> 16);
    return h;
}

// Iterated avalanche diffusion; mirrors _stretch in runtime.luau exactly.
static inline uint32_t stretchSeed(uint32_t h) {
    for (int i = 0; i < 1024; ++i) {
        h = avalancheMix(h + 0x9E3779B9u);
    }
    return h;
}

// Per-build variant mixer; mirrors _mix in runtime.luau (constant family
// selected by cfg bit1, extra diffusion round by cfg bit0). Must remain
// bit-for-bit identical to the Luau implementation.
static inline uint32_t avalancheMixCfg(uint32_t h, uint32_t cfg) {
    h ^= (h >> 16);
    if (cfg & 2) {
        h *= 0xCC9E2D51u;
        h ^= (h >> 13);
        h *= 0x1B873593u;
    } else {
        h *= 0x85EBCA6Bu;
        h ^= (h >> 13);
        h *= 0xC2B2AE35u;
    }
    h ^= (h >> 16);
    if (cfg & 1) {
        h ^= (h >> 11);
        h *= 0x9E3779B1u;
    }
    return h;
}

// Base KDF (bootstrap phase): header masks and key stretching only.
static inline uint32_t deriveSubkeyBase(uint32_t seed, uint32_t domain, uint32_t nonce, uint32_t len) {
    uint32_t h = seed ^ domain;
    uint32_t n_term = ((uint64_t(nonce) * 0x9E3779B9ULL) + 0x510E527FULL) & 0xFFFFFFFFu;
    h = avalancheMix(h ^ n_term);
    uint32_t l_term = ((uint64_t(len) * 0x1B873593ULL) + 0x27D4EB2FULL) & 0xFFFFFFFFu;
    h = avalancheMix(h ^ l_term);
    return h;
}

// Working-state KDF (per-build variant); everything post-header uses this.
static inline uint32_t deriveSubkey(uint32_t seed, uint32_t domain, uint32_t nonce, uint32_t len) {
    uint32_t h = seed ^ domain;
    uint32_t n_term = ((uint64_t(nonce) * 0x9E3779B9ULL) + 0x510E527FULL) & 0xFFFFFFFFu;
    h = avalancheMix(h ^ n_term);
    uint32_t l_term = ((uint64_t(len) * 0x1B873593ULL) + 0x27D4EB2FULL) & 0xFFFFFFFFu;
    h = avalancheMix(h ^ l_term);
    return h;
}

static inline uint32_t deriveSubkeyCfg(uint32_t ws, uint32_t cfg, uint32_t domain, uint32_t nonce, uint32_t len) {
    uint32_t h = ws ^ domain;
    uint32_t n_term = ((uint64_t(nonce) * 0x9E3779B9ULL) + 0x510E527FULL) & 0xFFFFFFFFu;
    h = avalancheMixCfg(h ^ n_term, cfg);
    uint32_t l_term = ((uint64_t(len) * 0x1B873593ULL) + 0x27D4EB2FULL) & 0xFFFFFFFFu;
    h = avalancheMixCfg(h ^ l_term, cfg);
    return h;
}

// Encoding context: working state + per-build algorithm variant.
struct EncCtx {
    uint32_t ws;
    uint32_t cfg;
};

static inline uint32_t computeMask32(const EncCtx& C, size_t pc) {
    return deriveSubkeyCfg(C.ws, C.cfg, DOMAIN_KDF_BRANCH, uint32_t(pc), 4);
}

static inline uint8_t computeOpcodeMask(const EncCtx& C, size_t pc) {
    uint32_t k = deriveSubkeyCfg(C.ws, C.cfg, DOMAIN_KDF_OPCODE, uint32_t(pc), 1);
    return uint8_t(((k >> 24) ^ (k >> 16) ^ (k >> 8) ^ k) & 0xFF);
}

static inline uint8_t computeOperandMask(const EncCtx& C, size_t pc) {
    uint32_t k = deriveSubkeyCfg(C.ws, C.cfg, DOMAIN_KDF_OPERAND, uint32_t(pc), 1);
    return uint8_t(((k >> 24) ^ (k >> 16) ^ (k >> 8) ^ k) & 0xFF);
}

static void encryptBytes32(std::vector<uint8_t>& out, const std::string& str, const EncCtx& C, uint32_t domain, uint32_t nonce) {
    uint32_t len = uint32_t(str.size());
    uint32_t state = deriveSubkeyCfg(C.ws, C.cfg, domain, nonce, len);
    for (size_t i = 0; i < str.size(); ++i) {
        state = (uint32_t)((uint64_t(state) * 1664525ULL + 1013904223ULL) & 0xFFFFFFFFu);
        uint32_t i_term = (uint32_t)((uint64_t(i) * 0x9E3779B9ULL) & 0xFFFFFFFFu);
        uint32_t step_key = avalancheMixCfg(state ^ i_term, C.cfg);
        uint8_t key = uint8_t(((step_key >> 24) ^ (step_key >> 16) ^ (step_key >> 8) ^ step_key) & 0xFF);
        out.push_back(uint8_t(str[i]) ^ key);
    }
}

static inline void encryptProtoSlice(std::vector<uint8_t>& buf, size_t offset, size_t len, const EncCtx& C, int pid) {
    uint32_t st = deriveSubkeyCfg(C.ws, C.cfg, DOMAIN_KDF_PROTO, uint32_t(pid), uint32_t(len));
    for (size_t i = 0; i < len; ++i) {
        st = (uint32_t)((uint64_t(st) * 1664525ULL + 1013904223ULL) & 0xFFFFFFFFu);
        uint8_t k = uint8_t(((st >> 24) ^ (st >> 16) ^ (st >> 8) ^ st) & 0xFF);
        buf[offset + i] ^= k;
    }
}

// Seeded LCG Fisher-Yates; mirrors _lfisher in runtime.luau exactly.
static std::vector<uint8_t> fisherLCG(uint32_t st, int n) {
    std::vector<uint8_t> p(n);
    for (int i = 0; i < n; ++i) p[i] = uint8_t(i);
    for (int i = n - 1; i > 0; --i) {
        st = (uint32_t)((uint64_t(st) * 1664525ULL + 1013904223ULL) & 0xFFFFFFFFu);
        size_t j = st % size_t(i + 1);
        std::swap(p[i], p[j]);
    }
    return p;
}

// Permutation of the logical sub-encoding spaces; nonce/n perms mirror the
// runtime's _fisher(n, nonce) tables built from the working seed.
static std::vector<uint8_t> generateSubPermutation(const EncCtx& C, uint32_t nonce, int n) {
    return fisherLCG(deriveSubkeyCfg(C.ws, C.cfg, DOMAIN_KDF_OPCODE, nonce, uint32_t(n)), n);
}

static std::vector<uint8_t> generateOpcodePermutation(const EncCtx& C) {
    return generateSubPermutation(C, 0, 27);
}

struct PermSet {
    std::vector<uint8_t> op, bop, cmp, uop, cap, rt, ct;
};

// Collision-free constant-pool nonce: (pid << 16) | ki, with hard bounds so a
// two-time-pad never arises silently (audit finding: multiplicative nonce
// pid*10000+ki collided whenever a prototype held >= 10000 constants).
static inline uint32_t makeConstNonce(int pid, size_t ki) {
    if (pid < 0 || pid > 0xFFFF || ki > 0xFFFF)
        throw Failure("E_LIMIT: prototype/constant index exceeds safe 16-bit nonce range");
    return (uint32_t(pid) << 16) | uint32_t(ki & 0xFFFFu);
}

// Sensitivity classifier: strings that carry security-relevant tokens or are
// long enough to likely embed configuration/credentials are tagged no-retain.
static bool isSensitiveString(const std::string& s) {
    static const char* tokens[] = {
        "checksum", "verify", "token", "secret", "auth", "license",
        "validate", "signature", "tamper", "anti_cheat", "admin",
        "permission", "ban", "key", "pass", "http"
    };
    if (s.size() >= 64) return true;
    std::string low;
    low.reserve(s.size());
    for (unsigned char c : s) low.push_back(char(std::tolower(c)));
    for (const char* t : tokens) {
        if (low.find(t) != std::string::npos) return true;
    }
    return false;
}

std::string constantJson(const Constant& k){std::ostringstream o;o<<"{\"kind\":"<<quoteJson(kind(k.tag));
 if(k.tag==LBC_CONSTANT_BOOLEAN)o<<",\"value\":"<<(k.boolean?"true":"false");
 else if(k.tag==LBC_CONSTANT_NUMBER)o<<",\"ieee754_le_hex\":"<<quoteJson(hex(bits(k.number)));
 else if(k.tag==LBC_CONSTANT_STRING)o<<",\"bytes_hex\":"<<quoteJson(hex(k.bytes));
 else if(k.tag==LBC_CONSTANT_CLOSURE)o<<",\"proto\":"<<k.id;
 else if(k.tag==LBC_CONSTANT_VECTOR){o<<",\"source_components_f64_hex\":[";for(size_t i=0;i<k.vector.size();++i){if(i)o<<',';o<<quoteJson(hex(bits(k.vector[i])));}o<<']';}
 else if(k.tag==LBC_CONSTANT_TABLE||k.tag==LBC_CONSTANT_TABLE_WITH_CONSTANTS){o<<",\"entries\":[";bool comma=false;for(auto e:k.entries){if(comma)o<<',';comma=true;o<<'['<<e.first<<','<<e.second<<']';}o<<']';}
 o<<'}';return o.str();}

static void write_u8(std::vector<uint8_t>& buf, uint8_t v) { buf.push_back(v); }
static void write_u16(std::vector<uint8_t>& buf, uint16_t v) {
    buf.push_back(uint8_t(v & 0xFF));
    buf.push_back(uint8_t((v >> 8) & 0xFF));
}
static void write_i16(std::vector<uint8_t>& buf, int16_t v) {
    uint16_t uv = uint16_t(v);
    write_u16(buf, uv);
}
static void write_u32(std::vector<uint8_t>& buf, uint32_t v) {
    buf.push_back(uint8_t(v & 0xFF));
    buf.push_back(uint8_t((v >> 8) & 0xFF));
    buf.push_back(uint8_t((v >> 16) & 0xFF));
    buf.push_back(uint8_t((v >> 24) & 0xFF));
}
static void write_i32(std::vector<uint8_t>& buf, int32_t v) {
    uint32_t uv = uint32_t(v);
    write_u32(buf, uv);
}
static void write_at_u32(std::vector<uint8_t>& buf, size_t pos, uint32_t v) {
    buf[pos] = uint8_t(v & 0xFF);
    buf[pos + 1] = uint8_t((v >> 8) & 0xFF);
    buf[pos + 2] = uint8_t((v >> 16) & 0xFF);
    buf[pos + 3] = uint8_t((v >> 24) & 0xFF);
}
static void write_at_u16(std::vector<uint8_t>& buf, size_t pos, uint16_t v) {
    buf[pos] = uint8_t(v & 0xFF);
    buf[pos + 1] = uint8_t((v >> 8) & 0xFF);
}
static void write_f64(std::vector<uint8_t>& buf, double v) {
    uint64_t u;
    std::memcpy(&u, &v, sizeof(u));
    for (int i = 0; i < 8; ++i) {
        buf.push_back(uint8_t((u >> (i * 8)) & 0xFF));
    }
}

static void serializeRef(std::vector<uint8_t>& buf, const Ref& r, const PermSet& P) {
    write_u8(buf, P.rt[r.tag]);
    if (r.tag == 0) {
        write_u8(buf, uint8_t(r.index));
    } else if (r.tag == 1) {
        write_u16(buf, uint16_t(r.index));
    } else if (r.tag == 2) {
        write_f64(buf, r.number);
    } else if (r.tag == 4) {
        write_u8(buf, uint8_t(r.index != 0 ? 1 : 0));
    }
}

// String record: u8 flags (bit0 = sensitive / no-retain), position-masked u16
// length (no length oracle), keystream-encoded bytes. KDF nonce = record offset.
static void serializeString(std::vector<uint8_t>& buf, const std::string& str, const EncCtx& C) {
    if (str.size() > 0xFFFF)
        throw Failure("E_LIMIT: string literal exceeds 65535 bytes; split the literal");
    size_t ptr = buf.size();
    uint8_t flags = isSensitiveString(str) ? uint8_t(1) : uint8_t(0);
    uint16_t len = uint16_t(str.size());
    uint16_t lmask = uint16_t(deriveSubkeyCfg(C.ws, C.cfg, DOMAIN_KDF_STRINGS, uint32_t(ptr), 2) & 0xFFFFu);
    write_u8(buf, flags);
    write_u16(buf, uint16_t(len ^ lmask));
    std::vector<uint8_t> enc;
    encryptBytes32(enc, str, C, DOMAIN_KDF_STRINGS, uint32_t(ptr));
    for (uint8_t b : enc) write_u8(buf, b);
}

static uint8_t binaryOpCode(const std::string& op) {
    if (op == "add") return 0;
    if (op == "sub") return 1;
    if (op == "mul") return 2;
    if (op == "div") return 3;
    if (op == "mod") return 4;
    if (op == "pow") return 5;
    if (op == "and") return 6;
    if (op == "or")  return 7;
    if (op == "idiv") return 8;
    return 0;
}

static uint8_t branchOpCode(const std::string& op) {
    if (op == "eq") return 0;
    if (op == "le") return 1;
    if (op == "lt") return 2;
    if (op == "ne") return 3;
    if (op == "not_le") return 4;
    if (op == "not_lt") return 5;
    if (op == "gt") return 6;
    if (op == "ge") return 7;
    return 0;
}

static uint8_t unaryOpCode(const std::string& op) {
    if (op == "not") return 0;
    if (op == "minus" || op == "neg") return 1;
    if (op == "length") return 2;
    return 0;
}

static uint8_t getOpId(const std::string& op) {
    if (op == "Noop") return 0;
    if (op == "Assign") return 1;
    if (op == "Binary") return 2;
    if (op == "GlobalRead") return 3;
    if (op == "GlobalWrite") return 4;
    if (op == "UpvalueRead") return 5;
    if (op == "UpvalueWrite") return 6;
    if (op == "CloseCells") return 7;
    if (op == "IndexRead") return 8;
    if (op == "IndexWrite") return 9;
    if (op == "Closure") return 10;
    if (op == "PrepareMethod") return 11;
    if (op == "Invoke") return 12;
    if (op == "Return") return 13;
    if (op == "Jump") return 14;
    if (op == "BranchTruth") return 15;
    if (op == "BranchCompare") return 16;
    if (op == "Concat") return 17;
    if (op == "Unary") return 18;
    if (op == "NewTable") return 19;
    if (op == "CloneTable") return 20;
    if (op == "WriteList") return 21;
    if (op == "NumericInit") return 22;
    if (op == "NumericAdvance") return 23;
    if (op == "Iterate") return 24;
    if (op == "IterationBoundary") return 25;
    if (op == "Varargs") return 26;
    return 0;
}

struct JumpPatch {
    size_t patch_pos;
    int target_node_pc;
};

struct ProtoPatch {
    size_t patch_pos;
    int child_proto_id;
};

static void serializeConstant(
    std::vector<uint8_t>& buf,
    const Constant& k,
    const EncCtx& C,
    int pid,
    size_t ki,
    std::vector<ProtoPatch>& proto_patches,
    const PermSet& P
) {
    const uint32_t nonce = makeConstNonce(pid, ki);
    if (k.tag == LBC_CONSTANT_BOOLEAN) {
        write_u8(buf, P.ct[1]);
        write_u8(buf, k.boolean ? 1 : 0);
    } else if (k.tag == LBC_CONSTANT_NUMBER) {
        write_u8(buf, P.ct[2]);
        // IEEE-754 bit pattern is stream-encoded like any other 8 bytes
        uint8_t raw8[8];
        std::memcpy(raw8, &k.number, 8);
        std::vector<uint8_t> enc;
        encryptBytes32(enc, std::string((const char*)raw8, 8), C, DOMAIN_KDF_CONSTANTS, nonce);
        for (uint8_t b : enc) write_u8(buf, b);
    } else if (k.tag == LBC_CONSTANT_STRING) {
        if (k.bytes.size() > 0xFFFF)
            throw Failure("E_LIMIT: string constant exceeds 65535 bytes; split the literal");
        write_u8(buf, P.ct[3]);
        uint8_t flags = isSensitiveString(k.bytes) ? uint8_t(1) : uint8_t(0);
        write_u8(buf, flags);
        uint16_t lmask = uint16_t(deriveSubkeyCfg(C.ws, C.cfg, DOMAIN_KDF_CONSTANTS, nonce, 2) & 0xFFFFu);
        write_u16(buf, uint16_t(uint16_t(k.bytes.size()) ^ lmask));
        std::vector<uint8_t> enc;
        encryptBytes32(enc, k.bytes, C, DOMAIN_KDF_CONSTANTS, nonce);
        for (uint8_t b : enc) write_u8(buf, b);
    } else if (k.tag == LBC_CONSTANT_CLOSURE) {
        write_u8(buf, P.ct[6]);
        size_t patch_pos = buf.size();
        write_u32(buf, 0); // patched later with child proto offset ^ DOM_CLOSURE mask
        proto_patches.push_back({ patch_pos, int(k.id) });
    } else if (k.tag == LBC_CONSTANT_VECTOR) {
        write_u8(buf, P.ct[7]);
        uint8_t raw24[24];
        for (int vi = 0; vi < 3; ++vi) {
            double comp = k.vector.at(vi);
            std::memcpy(raw24 + vi * 8, &comp, 8);
        }
        std::vector<uint8_t> enc;
        encryptBytes32(enc, std::string((const char*)raw24, 24), C, DOMAIN_KDF_CONSTANTS, nonce);
        for (uint8_t b : enc) write_u8(buf, b);
    } else if (k.tag == LBC_CONSTANT_TABLE || k.tag == LBC_CONSTANT_TABLE_WITH_CONSTANTS) {
        if (k.entries.size() > 0x3FFF)
            throw Failure("E_LIMIT: table shape exceeds entry budget");
        write_u8(buf, P.ct[8]);
        uint16_t emask = uint16_t(deriveSubkeyCfg(C.ws, C.cfg, DOMAIN_KDF_CONSTANTS, nonce, 2) & 0xFFFFu);
        write_u16(buf, uint16_t(uint16_t(k.entries.size()) ^ emask));
        // Entry index pairs (u16 key, i16 value) go through their own stream so
        // table-literal structure never appears raw in the buffer.
        std::string rawent;
        rawent.reserve(k.entries.size() * 4);
        for (const auto& e : k.entries) {
            // Table shapes must reference already-serialized pool entries; a
            // forward reference would be unresolvable at runtime parse time.
            if (e.first >= uint32_t(ki) || (e.second >= 0 && uint32_t(e.second) >= uint32_t(ki)))
                throw Failure("E_EMIT: forward constant reference inside table shape");
            uint16_t kv = uint16_t(e.first);
            int16_t vv = int16_t(e.second);
            rawent.push_back(char(kv & 0xFF));
            rawent.push_back(char((kv >> 8) & 0xFF));
            rawent.push_back(char(uint16_t(vv) & 0xFF));
            rawent.push_back(char((uint16_t(vv) >> 8) & 0xFF));
        }
        std::vector<uint8_t> enc;
        encryptBytes32(enc, rawent, C, DOMAIN_KDF_CONSTANTS, nonce + 32768u);
        for (uint8_t b : enc) write_u8(buf, b);
    } else {
        write_u8(buf, P.ct[0]); // nil
    }
}

static void serializeNodeDirect(
    std::vector<uint8_t>& buf,
    const Node& n,
    const EncCtx& C,
    const PermSet& P,
    std::vector<JumpPatch>& jump_patches,
    std::vector<ProtoPatch>& proto_patches
) {
    size_t inst_pc = buf.size();
    uint8_t logical_op = getOpId(n.op);
    uint8_t permuted_op = P.op[logical_op];
    uint8_t mask = computeOpcodeMask(C, inst_pc);
    uint8_t raw_op = uint8_t(permuted_op ^ mask);
    write_u8(buf, raw_op);

    bool has_a = (logical_op != 0 && logical_op != 14 && logical_op != 15 && logical_op != 16 && logical_op != 25);
    if (has_a) {
        // Register operand is position-masked with its own domain so raw
        // dataflow (register numbers) never appears cleartext on the wire.
        size_t apos = buf.size();
        write_u8(buf, uint8_t(uint8_t(n.a) ^ computeOperandMask(C, apos)));
    }

    if (logical_op == 1) { // Assign
        serializeRef(buf, n.x, P);
    } else if (logical_op == 2) { // Binary
        serializeRef(buf, n.x, P);
        serializeRef(buf, n.y, P);
        size_t pos = buf.size();
        write_u8(buf, uint8_t(P.bop[binaryOpCode(n.operatorName)] ^ computeOpcodeMask(C, pos)));
    } else if (logical_op == 3 || logical_op == 4) { // GlobalRead / GlobalWrite
        serializeString(buf, n.key, C);
    } else if (logical_op == 5 || logical_op == 6) { // UpvalueRead / UpvalueWrite
        write_u8(buf, uint8_t(n.b));
    } else if (logical_op == 8 || logical_op == 9) { // IndexRead / IndexWrite
        serializeRef(buf, n.x, P);
        serializeRef(buf, n.y, P);
    } else if (logical_op == 10) { // Closure
        size_t patch_pos = buf.size();
        write_u32(buf, 0); // placeholder for child proto_offset
        proto_patches.push_back({ patch_pos, n.proto });
        write_i16(buf, int16_t(n.cache));
        write_u8(buf, uint8_t(n.captures.size()));
        for (const auto& c : n.captures) {
            write_u8(buf, P.cap[c.kind]);
            write_u8(buf, uint8_t(c.index));
        }
    } else if (logical_op == 11) { // PrepareMethod
        serializeRef(buf, n.x, P);
        serializeString(buf, n.key, C);
    } else if (logical_op == 12) { // Invoke
        write_i16(buf, int16_t(n.b));
        write_i16(buf, int16_t(n.c));
    } else if (logical_op == 13) { // Return
        write_i16(buf, int16_t(n.b));
    } else if (logical_op == 14) { // Jump
        size_t patch_pos = buf.size();
        write_i32(buf, 0); // placeholder
        jump_patches.push_back({ patch_pos, n.yes });
    } else if (logical_op == 15) { // BranchTruth
        serializeRef(buf, n.x, P);
        write_u8(buf, uint8_t(n.b != 0 ? 1 : 0));
        size_t patch_yes = buf.size();
        write_i32(buf, 0);
        jump_patches.push_back({ patch_yes, n.yes });
    } else if (logical_op == 16) { // BranchCompare
        serializeRef(buf, n.x, P);
        serializeRef(buf, n.y, P);
        size_t pos = buf.size();
        write_u8(buf, uint8_t(P.cmp[branchOpCode(n.operatorName)] ^ computeOpcodeMask(C, pos)));
        size_t patch_yes = buf.size();
        write_i32(buf, 0);
        jump_patches.push_back({ patch_yes, n.yes });
    } else if (logical_op == 17) { // Concat
        write_u8(buf, uint8_t(n.b));
        write_u8(buf, uint8_t(n.c));
    } else if (logical_op == 18) { // Unary
        serializeRef(buf, n.x, P);
        size_t pos = buf.size();
        write_u8(buf, uint8_t(P.uop[unaryOpCode(n.operatorName)] ^ computeOpcodeMask(C, pos)));
    } else if (logical_op == 19) { // NewTable
        write_u32(buf, uint32_t(n.b));
        write_u32(buf, uint32_t(n.c));
    } else if (logical_op == 20) { // CloneTable
        write_u16(buf, uint16_t(n.b));
    } else if (logical_op == 21) { // WriteList
        write_u8(buf, uint8_t(n.b));
        write_i16(buf, int16_t(n.c));
        write_i16(buf, int16_t(n.cache));
    } else if (logical_op == 22 || logical_op == 23) { // NumericInit / NumericAdvance
        size_t patch_pos = buf.size();
        write_i32(buf, 0);
        jump_patches.push_back({ patch_pos, n.yes });
    } else if (logical_op == 24) { // Iterate
        size_t patch_latch = buf.size();
        write_i32(buf, 0);
        jump_patches.push_back({ patch_latch, n.b });
        write_u8(buf, uint8_t(n.c));
        size_t patch_yes = buf.size();
        write_i32(buf, 0);
        jump_patches.push_back({ patch_yes, n.yes });
        size_t patch_no = buf.size();
        write_i32(buf, 0);
        jump_patches.push_back({ patch_no, n.no });
    } else if (logical_op == 25) { // IterationBoundary
        // Handled by Iterate latch
    } else if (logical_op == 26) { // Varargs
        write_i16(buf, int16_t(n.b));
    }
}

// Translation-unit authentication checksum over every byte except [skip, skip+4).
// Recurrence mirrors the shift-based P1 loop in runtime.luau (arithmetically
// identical mod 2^32): h*31 == (h<<5)-h and h*37+17 == (h<<5)+(h<<2)+h+17.
static uint32_t computeBytecodeChecksum(const std::vector<uint8_t>& buf, uint32_t seed, size_t skip) {
    uint32_t h = seed;
    for (size_t i = 0; i < buf.size(); ++i) {
        if (i >= skip && i < skip + 4) continue;
        h = ((h * 31u + uint32_t(buf[i])) ^ 0x5A827999u) & 0xFFFFFFFFu;
        h ^= (h >> 13);
        h = (h * 37u + 17u) & 0xFFFFFFFFu;
    }
    return h;
}

static uint32_t read_u32_at(const std::vector<uint8_t>& buf, size_t pos) {
    return uint32_t(buf[pos]) | (uint32_t(buf[pos + 1]) << 8) | (uint32_t(buf[pos + 2]) << 16) | (uint32_t(buf[pos + 3]) << 24);
}

std::string programLua(const Module& m, std::mt19937_64& rng, uint64_t seed, int profileMode, uint32_t ksplit, int* sensitiveCount = nullptr) {
    std::vector<uint8_t> programBytecode;
    std::map<int, size_t> proto_start_offsets;
    std::map<int, size_t> proto_end_offsets;
    std::vector<ProtoPatch> proto_patches;
    // 32-byte permuted header: slot 0 = cleartext layout descriptor L32;
    // logical fields (main offset, seed halves, checksum) at L32-derived slots.
    for (int i = 0; i < 32; ++i) programBytecode.push_back(0);

    uint32_t seed_lo = uint32_t(seed);
    uint32_t seed_hi = uint32_t(seed >> 32);
    uint32_t blended_seed = blendSeed(seed);
    // Working decode state: stretch(blended) ^ ksplit. ksplit==0 for data-only /
    // template mode; pipeline injects a nonzero split key into embedded runtimes.
    uint32_t ws = stretchSeed(blended_seed) ^ ksplit;
    EncCtx C{ ws, ws & 3u };

    uint32_t L32 = uint32_t(rng());
    std::vector<uint8_t> hp = fisherLCG(deriveSubkey(L32, DOMAIN_KDF_HEADER, 77, 7), 7);
    size_t slot_main = size_t(1 + hp[0]) * 4;
    size_t slot_s0   = size_t(1 + hp[1]) * 4;
    size_t slot_s1   = size_t(1 + hp[2]) * 4;
    size_t slot_chk  = size_t(1 + hp[3]) * 4;
    uint32_t hk_mask[4] = {
        deriveSubkey(L32, DOMAIN_KDF_HEADER, 10, 4),
        deriveSubkey(L32, DOMAIN_KDF_HEADER, 11, 4),
        deriveSubkey(L32, DOMAIN_KDF_HEADER, 12, 4),
        deriveSubkey(L32, DOMAIN_KDF_HEADER, 13, 4),
    };

    PermSet P;
    P.op  = generateOpcodePermutation(C);
    P.bop = generateSubPermutation(C, 101, 9);
    P.cmp = generateSubPermutation(C, 102, 8);
    P.uop = generateSubPermutation(C, 103, 3);
    P.cap = generateSubPermutation(C, 104, 3);
    P.rt  = generateSubPermutation(C, 105, 5);
    P.ct  = generateSubPermutation(C, 106, 9);

    if (m.functions.size() > 0xFFFF)
        throw Failure("E_LIMIT: function count exceeds 16-bit prototype id range");
    int sens_count = 0;
    for (const auto& f : m.functions) {
        if (f.constants.size() > 0xFFFF)
            throw Failure("E_LIMIT: constant pool exceeds 16-bit index range");
        if (int(f.code.size()) > 0x7FFFFFFF)
            throw Failure("E_LIMIT: instruction stream too large");
        for (const auto& k : f.constants) {
            if (k.tag == LBC_CONSTANT_STRING && isSensitiveString(k.bytes)) sens_count++;
        }
    }

    for (const auto& f : m.functions) {
        size_t proto_start = programBytecode.size();
        proto_start_offsets[f.id] = proto_start;

        write_u32(programBytecode, 0); // placeholder for slice_len
        write_u16(programBytecode, uint16_t(f.id));
        write_u8(programBytecode, uint8_t(f.slots));
        write_u8(programBytecode, uint8_t(f.params));
        write_u8(programBytecode, uint8_t(f.vararg ? 1 : 0));
        write_u8(programBytecode, uint8_t(f.upvalues));
        write_u16(programBytecode, uint16_t(f.constants.size()));

        for (size_t ki = 0; ki < f.constants.size(); ++ki) {
            serializeConstant(programBytecode, f.constants[ki], C, f.id, ki, proto_patches, P);
        }

        std::map<int, size_t> node_byte_offsets;
        std::vector<JumpPatch> jump_patches;

        for (size_t j = 0; j < f.code.size(); ++j) {
            size_t node_pc = j + 1;
            node_byte_offsets[int(node_pc)] = programBytecode.size();
            serializeNodeDirect(programBytecode, f.code[j], C, P, jump_patches, proto_patches);
        }

        if (profileMode == 2) {
            // Profile::Maximum: inject dead code decoy instructions to obfuscate CFG
            Node decoy1;
            decoy1.op = "Assign";
            decoy1.a = 0;
            decoy1.x = Ref{2, 0, double(seed & 0xFFFF)};
            serializeNodeDirect(programBytecode, decoy1, C, P, jump_patches, proto_patches);

            Node decoy2;
            decoy2.op = "Unary";
            decoy2.a = 0;
            decoy2.x = Ref{2, 0, 0.0};
            decoy2.operatorName = "not";
            serializeNodeDirect(programBytecode, decoy2, C, P, jump_patches, proto_patches);
        }

        for (const auto& jp : jump_patches) {
            auto it = node_byte_offsets.find(jp.target_node_pc);
            if (it != node_byte_offsets.end()) {
                uint32_t target_off = uint32_t(it->second);
                uint32_t mask = computeMask32(C, jp.patch_pos);
                write_at_u32(programBytecode, jp.patch_pos, target_off ^ mask);
            }
        }

        proto_end_offsets[f.id] = programBytecode.size();
    }

    // Apply proto patches for child closure references
    for (const auto& pp : proto_patches) {
        auto it = proto_start_offsets.find(pp.child_proto_id);
        if (it != proto_start_offsets.end()) {
            uint32_t child_off = uint32_t(it->second);
            uint32_t mask = deriveSubkeyCfg(C.ws, C.cfg, DOMAIN_KDF_CLOSURE, uint32_t(pp.patch_pos), 4);
            write_at_u32(programBytecode, pp.patch_pos, child_off ^ mask);
        }
    }

    // Write slice_len and encrypt child prototype slices
    for (const auto& f : m.functions) {
        size_t proto_start = proto_start_offsets[f.id];
        size_t proto_end = proto_end_offsets[f.id];
        size_t slice_len = proto_end - (proto_start + 6);

        if (f.id == m.main) {
            write_at_u32(programBytecode, proto_start, uint32_t(slice_len));
        } else {
            uint32_t m32 = computeMask32(C, proto_start);
            write_at_u32(programBytecode, proto_start, uint32_t(slice_len) ^ m32);
            uint16_t m16 = uint16_t(computeMask32(C, proto_start + 4) & 0xFFFF);
            write_at_u16(programBytecode, proto_start + 4, uint16_t(f.id) ^ m16);
            encryptProtoSlice(programBytecode, proto_start + 6, slice_len, C, f.id);
        }
    }

    uint32_t main_off = uint32_t(proto_start_offsets[m.main]);

    // Fill header slots: L32 cleartext at slot 0, decoys at unused slots, then
    // masked logical fields. Checksum is computed last and covers everything
    // except its own slot, so any single header mutation is authenticated.
    write_at_u32(programBytecode, 0, L32);
    {
        int decoy_idx = 0;
        for (int slot = 1; slot <= 7; ++slot) {
            size_t pos = size_t(slot) * 4;
            if (pos == slot_main || pos == slot_s0 || pos == slot_s1 || pos == slot_chk) continue;
            write_at_u32(programBytecode, pos, deriveSubkey(L32, DOMAIN_KDF_HEADER, uint32_t(50 + decoy_idx), 4));
            decoy_idx++;
        }
    }
    write_at_u32(programBytecode, slot_main, main_off ^ hk_mask[0]);
    write_at_u32(programBytecode, slot_s0, seed_lo ^ hk_mask[1]);
    write_at_u32(programBytecode, slot_s1, seed_hi ^ hk_mask[2]);

    uint32_t chk = computeBytecodeChecksum(programBytecode, ws, slot_chk);
    write_at_u32(programBytecode, slot_chk, chk ^ hk_mask[3]);

    // ---------------------------------------------------------------
    // Build-time self-verification: re-parse the header like the runtime would
    // and verify bit-exact field recovery. Any mismatch must fail the build
    // rather than ship a broken artifact.
    // ---------------------------------------------------------------
    {
        uint32_t rL32 = read_u32_at(programBytecode, 0);
        std::vector<uint8_t> rhp = fisherLCG(deriveSubkey(rL32, DOMAIN_KDF_HEADER, 77, 7), 7);
        size_t r_main = size_t(1 + rhp[0]) * 4;
        size_t r_s0   = size_t(1 + rhp[1]) * 4;
        size_t r_s1   = size_t(1 + rhp[2]) * 4;
        size_t r_chk  = size_t(1 + rhp[3]) * 4;
        uint32_t got_main = read_u32_at(programBytecode, r_main) ^ deriveSubkey(rL32, DOMAIN_KDF_HEADER, 10, 4);
        uint32_t got_s0   = read_u32_at(programBytecode, r_s0)   ^ deriveSubkey(rL32, DOMAIN_KDF_HEADER, 11, 4);
        uint32_t got_s1   = read_u32_at(programBytecode, r_s1)   ^ deriveSubkey(rL32, DOMAIN_KDF_HEADER, 12, 4);
        uint32_t got_chk  = read_u32_at(programBytecode, r_chk)  ^ deriveSubkey(rL32, DOMAIN_KDF_HEADER, 13, 4);
        uint32_t rblend   = got_s0 ^ (got_s1 ^ 0x9E3779B9u);
        uint32_t rws      = stretchSeed(rblend) ^ ksplit;
        uint32_t expect_chk = computeBytecodeChecksum(programBytecode, rws, r_chk);
        if (got_main != main_off || got_s0 != seed_lo || got_s1 != seed_hi || got_chk != expect_chk) {
            throw Failure("E_EMIT_SELFCHECK: header round-trip verification failed");
        }
        // Verify permutation spaces are bijections (a collision would be fatal)
        auto checkBijection = [](const std::vector<uint8_t>& p, const char* name) {
            std::vector<uint8_t> seen(p.size(), 0);
            for (uint8_t v : p) {
                if (v >= p.size() || seen[v]) throw Failure(std::string("E_EMIT_SELFCHECK: permutation collision in ") + name);
                seen[v] = 1;
            }
        };
        checkBijection(P.op, "opcode");
        checkBijection(P.bop, "bop");
        checkBijection(P.cmp, "cmp");
        checkBijection(P.uop, "uop");
        checkBijection(P.cap, "capture");
        checkBijection(P.rt, "reftag");
        checkBijection(P.ct, "consttag");
    }

    if (sensitiveCount) *sensitiveCount = sens_count;

    std::ostringstream o;
    o << "{bytecode=buffer.fromstring(\"" << formatBinaryString(programBytecode) << "\")}";
    return o.str();
}

} // namespace

std::string methodTable(const std::set<std::string>& names){std::ostringstream o;o<<"{";for(auto name:names){identifier(name);o<<"["<<quoteLua(name)<<"]=function(receiver,...) return receiver:"<<name<<"(...) end,";}o<<"}";return o.str();}
std::string drivers(const std::set<int>& arities){std::ostringstream o;o<<'{';for(int n:arities){o<<'['<<n<<"]=function(generator,state,index,body) for ";for(int i=1;i<=n;++i){if(i>1)o<<',';o<<'v'<<i;}o<<" in generator,state,index do if body(";for(int i=1;i<=n;++i){if(i>1)o<<',';o<<'v'<<i;}o<<") then return end end end,";}o<<'}';return o.str();}

std::string toJson(const Module& m){
 std::ostringstream o;o<<"{\n\"schema\":\"luau-semantic-register-ir/1\",\"compiler_pin\":"<<quoteJson(CompilerPin)<<",\"source_bytecode_version\":"<<m.bytecodeVersion<<",\"main\":"<<m.main<<",\"private_mapping\":{\"granularity\":\"function,source-line,bytecode-word-span\",\"columns_available\":false,\"shipped_in_luau\":false},\"policy\":{\"coverage\":\"whole-module-reference\",\"all_listed_functions_virtualized\":true,\"guest_native_fallback\":false,\"strong_smooth_selection\":\"deferred to Phase 3\"},\"globals\":"<<stringSet(m.globals)<<",\"global_writes\":"<<stringSet(m.stores)<<",\"methods\":"<<stringSet(m.methods)<<",\"functions\":[\n";
 for(size_t i=0;i<m.functions.size();++i){if(i)o<<",\n";const auto& f=m.functions[i];o<<"{\"id\":"<<f.id<<",\"slots\":"<<f.slots<<",\"params\":"<<f.params<<",\"upvalues\":"<<f.upvalues<<",\"vararg\":"<<(f.vararg?"true":"false")<<",\"private_debug_name_latin1\":"<<quoteJson(f.name)<<",\"private_debug_name_bytes_hex\":"<<quoteJson(hex(f.name))<<",\"line_defined\":"<<f.lineDefined<<",\"escaped_registers\":"<<setJson(f.escaped)<<",\"constants\":[";
  for(size_t k=0;k<f.constants.size();++k){if(k)o<<',';o<<constantJson(f.constants[k]);}o<<"],\"nodes\":[\n";
  for(size_t j=0;j<f.code.size();++j){if(j)o<<",\n";const auto& n=f.code[j];o<<"{\"id\":"<<j+1<<",\"op\":"<<quoteJson(n.op)<<",\"a\":"<<n.a<<",\"b\":"<<n.b<<",\"c\":"<<n.c<<",\"yes\":"<<n.yes<<",\"no\":"<<n.no<<",\"proto\":"<<n.proto<<",\"cache\":"<<n.cache<<",\"x\":"<<refJson(n.x)<<",\"y\":"<<refJson(n.y)<<",\"operator\":"<<quoteJson(n.operatorName)<<",\"key\":"<<quoteJson(n.key)<<",\"captures\":[";
   for(size_t c=0;c<n.captures.size();++c){if(c)o<<',';o<<'['<<n.captures[c].kind<<','<<n.captures[c].index<<']';}
   o<<"],\"source_word_pc\":"<<n.pc<<",\"source_span_words\":"<<n.span<<",\"source_line\":"<<n.line<<",\"block\":"<<n.block<<",\"effect_in\":"<<n.effectIn<<",\"effect_out\":"<<n.effectOut<<",\"effects\":"<<effectJson(n.effects)<<",\"uses\":"<<setJson(n.uses)<<",\"defs\":"<<setJson(n.defs)<<",\"reads_top\":"<<(n.topRead?"true":"false")<<",\"writes_top\":"<<(n.topWrite?"true":"false")<<",\"note\":"<<quoteJson(n.note)<<'}';
  }o<<"],\"blocks\":[";
  for(size_t b=0;b<f.blocks.size();++b){if(b)o<<',';const auto& x=f.blocks[b];o<<"{\"id\":"<<x.id<<",\"begin\":"<<x.begin<<",\"end\":"<<x.end<<",\"successors\":"<<setJson(x.successors)<<",\"uses\":"<<setJson(x.uses)<<",\"defs\":"<<setJson(x.defs)<<",\"live_in\":"<<setJson(x.liveIn)<<",\"live_out\":"<<setJson(x.liveOut)<<'}';}o<<"]}";
 }o<<"]\n}\n";return o.str();
}

std::string emit(const Module& m,const std::string& runtime,uint64_t seed,bool dataOnly, int profileMode, uint32_t ksplit, int* sensitiveCount){
 std::mt19937_64 rng(seed);std::string factory="_f" + std::to_string(seed % 9973);
 while(m.globals.count(factory))factory+='_';
 // Method wrapper table: required for correct Luau __namecall semantics (a
 // dynamic key cannot form a namecall expression). Exposure is narrowed to the
 // exact set of invoked method names (audit finding: wrappers are now emitted
 // by usage only); see docs/THREAT_MODEL.md residuals.
 for(const auto& mn : m.methods) identifier(mn);
 std::string args=programLua(m,rng,seed,profileMode,ksplit,sensitiveCount)+",nil,nil,"+methodTable(m.methods)+","+drivers(m.iteratorArities)+",function(x,y,z) return vector.create(x,y,z) end";
 std::ostringstream o;
 if(dataOnly)o<<"return function("<<factory<<") return "<<factory<<'('<<args<<") end\n";
 else o<<"return (((function()\n"<<runtime<<"\nend)())("<<args<<"))(...)\n";
 return o.str();
}

} // namespace p2
