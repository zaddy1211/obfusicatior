#include "model.hpp"
#include "Luau/Bytecode.h"
#include "Luau/BytecodeUtils.h"
#include <algorithm>
#include <map>
#include <iterator>
#include <functional>
namespace p2 {
namespace {
[[noreturn]] void bad(int f,int pc,const std::string& what){throw Failure("E_LOWER function "+std::to_string(f)+" word "+std::to_string(pc)+": "+what);}
Ref imm(double n){return Ref{2,0,n};} Ref nil(){return Ref{3,0,0};}
bool branch(const std::string& op){return op=="Jump"||op=="BranchTruth"||op=="BranchCompare"||op=="NumericInit"||op=="NumericAdvance"||op=="Iterate"||op=="IterationBoundary";}
bool terminal(const Node& n){return branch(n.op)||n.op=="Return";}
void insertAll(std::set<int>& a,const std::set<int>& b){a.insert(b.begin(),b.end());}
}
Module lower(const RawModule& raw){
 Module m;m.main=raw.main;m.bytecodeVersion=raw.version;size_t totalNodes=0;
 for(const auto& p:raw.functions){
  Function f;f.id=p.id;f.slots=p.slots;f.params=p.params;f.upvalues=p.upvalues;f.vararg=p.vararg;f.constants=p.constants;f.name=p.name;f.lineDefined=p.lineDefined;
  std::map<int,int> anchors;std::vector<int> starts,spans;
  auto reg=[&](int i,int pc)->Ref{if(i<0||i>=p.slots)bad(p.id,pc,"register out of bounds: "+std::to_string(i));return Ref{0,i,0};};
  auto konst=[&](int i,int pc)->Ref{if(i<0||i>=int(p.constants.size()))bad(p.id,pc,"constant out of bounds");return Ref{1,i,0};};
  auto stringKey=[&](int i,int pc)->std::string{konst(i,pc);if(p.constants[i].tag!=LBC_CONSTANT_STRING)bad(p.id,pc,"expected a string constant");return p.constants[i].bytes;};
  auto scalar=[&](int i,int pc)->Ref{auto k=konst(i,pc);int t=p.constants[i].tag;if(t==LBC_CONSTANT_IMPORT||t==LBC_CONSTANT_TABLE||t==LBC_CONSTANT_TABLE_WITH_CONSTANTS)bad(p.id,pc,"non-scalar constant in value context");if(t==LBC_CONSTANT_CLOSURE&&raw.functions[p.constants[i].id].upvalues)bad(p.id,pc,"upvalue closure constant needs a capture site");return k;};
  for(int pc=0;pc<int(p.words.size());){
   uint32_t w=p.words[pc];int op=LUAU_INSN_OP(w);if(op>=LOP__COUNT)bad(p.id,pc,"unknown opcode");
   int span=Luau::getOpLength(LuauOpcode(op));if(pc+span>int(p.words.size()))bad(p.id,pc,"truncated AUX word");
   if(op==LOP_CAPTURE)bad(p.id,pc,"orphan capture instruction");
   if(op==LOP_NEWCLOSURE||op==LOP_DUPCLOSURE){
    int d=LUAU_INSN_D(w),child=-1;
    if(op==LOP_NEWCLOSURE){if(d<0||d>=int(p.children.size()))bad(p.id,pc,"invalid child reference");child=p.children[d];}
    else{konst(d,pc);if(p.constants[d].tag!=LBC_CONSTANT_CLOSURE)bad(p.id,pc,"DUPCLOSURE requires a closure constant");child=p.constants[d].id;}
    span+=raw.functions.at(child).upvalues;
    if(pc+span>int(p.words.size()))bad(p.id,pc,"truncated capture sequence");
    for(int j=pc+1;j<pc+span;++j){uint32_t cw=p.words[j];int kind=LUAU_INSN_A(cw),source=LUAU_INSN_B(cw);
     if(LUAU_INSN_OP(cw)!=LOP_CAPTURE||kind>2||LUAU_INSN_C(cw)!=0)bad(p.id,j,"invalid capture word");
     if(op==LOP_DUPCLOSURE&&kind==LCT_REF)bad(p.id,j,"reference capture is illegal for DUPCLOSURE");
     if(kind==LCT_UPVAL){if(source>=p.upvalues)bad(p.id,j,"upvalue capture out of bounds");}else reg(source,j);
    }
   }
   starts.push_back(pc);spans.push_back(span);pc+=span;
  }
  for(size_t si=0;si<starts.size();++si){
   int pc=starts[si];uint32_t w=p.words[pc];int op=LUAU_INSN_OP(w),a=LUAU_INSN_A(w),b=LUAU_INSN_B(w),c=LUAU_INSN_C(w),d=LUAU_INSN_D(w),span=spans[si];
   uint32_t aux=span>=2?p.words[pc+1]:0;
   anchors[pc]=int(f.code.size())+1;
   auto node=[&](const std::string& name)->Node&{if(++totalNodes>350000)throw Failure("E_LIMIT: semantic node budget exceeded");Node n;n.op=name;n.pc=pc;n.span=span;n.line=p.lines[pc];f.code.push_back(n);return f.code.back();};
   auto put=[&](Ref value){reg(a,pc);auto& n=node("Assign");n.a=a;n.x=value;};
   auto jumpTarget=[&](int64_t target)->int{if(target<0||target>=int64_t(p.words.size()))bad(p.id,pc,"jump target out of range");return int(target);};
   auto compare=[&](const std::string& pred,Ref x,Ref y){auto& n=node("BranchCompare");n.operatorName=pred;n.x=x;n.y=y;n.yes=jumpTarget(int64_t(pc)+1+d);n.no=pc+2;};
   auto binary=[&](const std::string& operation,Ref x,Ref y){reg(a,pc);auto& n=node("Binary");n.a=a;n.x=x;n.y=y;n.operatorName=operation;};
   switch(op){
    case LOP_NOP:{auto& n=node("Noop");n.note="semantic no-op";break;}
    case LOP_LOADNIL:put(nil());break;
    case LOP_LOADB:if(b>1)bad(p.id,pc,"invalid boolean literal");put(Ref{4,b,0});if(c){auto& n=node("Jump");n.yes=jumpTarget(int64_t(pc)+1+c);}break;
    case LOP_LOADN:put(imm(d));break;
    case LOP_LOADK:put(scalar(d,pc));break;
    case LOP_LOADKX:put(scalar(int(aux),pc));break;
    case LOP_MOVE:put(reg(b,pc));break;
    case LOP_GETGLOBAL:case LOP_SETGLOBAL:{reg(a,pc);auto key=stringKey(int(aux),pc);auto& n=node(op==LOP_GETGLOBAL?"GlobalRead":"GlobalWrite");n.a=a;n.key=key;m.globals.insert(key);if(op==LOP_SETGLOBAL)m.stores.insert(key);break;}
    case LOP_GETUPVAL:case LOP_SETUPVAL:{reg(a,pc);if(b>=p.upvalues)bad(p.id,pc,"upvalue index out of bounds");auto& n=node(op==LOP_GETUPVAL?"UpvalueRead":"UpvalueWrite");n.a=a;n.b=b;break;}
    case LOP_CLOSEUPVALS:{if(a>p.slots)bad(p.id,pc,"close boundary out of range");auto& n=node("CloseCells");n.a=a;break;}
    case LOP_GETIMPORT:{
     reg(a,pc);konst(d,pc);if(p.constants[d].tag!=LBC_CONSTANT_IMPORT||p.constants[d].id!=aux)bad(p.id,pc,"import descriptor mismatch");
     int count=aux>>30;if(count<1||count>3)bad(p.id,pc,"invalid import path length");
     int ids[3]={int((aux>>20)&1023),int((aux>>10)&1023),int(aux&1023)};
     auto root=stringKey(ids[0],pc);auto& n=node("GlobalRead");n.a=a;n.key=root;n.note="normalized import root";m.globals.insert(root);
     for(int j=1;j<count;++j){stringKey(ids[j],pc);auto& i=node("IndexRead");i.a=a;i.x=reg(a,pc);i.y=konst(ids[j],pc);i.note="normalized import path";}break;
    }
    case LOP_GETTABLE:case LOP_GETTABLEKS:case LOP_GETTABLEN:case LOP_GETUDATAKS:{
     reg(a,pc);Ref obj=reg(b,pc);Ref key=op==LOP_GETTABLE?reg(c,pc):op==LOP_GETTABLEN?imm(c+1):konst(int(op==LOP_GETUDATAKS?aux&65535:aux),pc);
     if(op==LOP_GETTABLEKS||op==LOP_GETUDATAKS)stringKey(key.index,pc);
     auto& n=node("IndexRead");n.a=a;n.x=obj;n.y=key;break;
    }
    case LOP_SETTABLE:case LOP_SETTABLEKS:case LOP_SETTABLEN:case LOP_SETUDATAKS:{
     reg(a,pc);Ref obj=reg(b,pc);Ref key=op==LOP_SETTABLE?reg(c,pc):op==LOP_SETTABLEN?imm(c+1):konst(int(op==LOP_SETUDATAKS?aux&65535:aux),pc);
     if(op==LOP_SETTABLEKS||op==LOP_SETUDATAKS)stringKey(key.index,pc);
     auto& n=node("IndexWrite");n.a=a;n.x=obj;n.y=key;break;
    }
    case LOP_NEWCLOSURE:case LOP_DUPCLOSURE:{
     reg(a,pc);int child=op==LOP_NEWCLOSURE?p.children[d]:p.constants[d].id;
     auto& n=node("Closure");n.a=a;n.proto=child;n.cache=op==LOP_DUPCLOSURE?d:-1;
     for(int j=pc+1;j<pc+span;++j){auto cw=p.words[j];int kind=LUAU_INSN_A(cw),index=LUAU_INSN_B(cw);n.captures.push_back({kind,index});if(kind==LCT_REF)f.escaped.insert(index);}break;
    }
    case LOP_NAMECALL:case LOP_NAMECALLUDATA:{
     if(pc+2>=int(p.words.size()))bad(p.id,pc,"method preparation has no adjacent call");
     uint32_t call=p.words[pc+2];if((LUAU_INSN_OP(call)!=LOP_CALL&&LUAU_INSN_OP(call)!=LOP_CALLFB)||LUAU_INSN_A(call)!=unsigned(a))bad(p.id,pc,"method preparation requires an adjacent matching CALL");
     reg(a,pc);reg(a+1,pc);reg(b,pc);std::string key=stringKey(int(op==LOP_NAMECALLUDATA?aux&65535:aux),pc);
     auto& n=node("PrepareMethod");n.a=a;n.x=reg(b,pc);n.key=key;m.methods.insert(key);break;
    }
    case LOP_CALL:case LOP_CALLFB:{
     if(op==LOP_CALLFB&&aux!=0xffffffffu&&aux>=p.feedbackSlots)bad(p.id,pc,"feedback slot index out of bounds");
     reg(a,pc);if(b&&a+b>p.slots)bad(p.id,pc,"fixed call arguments exceed frame");if(c&&a+c-1>p.slots)bad(p.id,pc,"fixed results exceed frame");
     auto& n=node("Invoke");n.a=a;n.b=b-1;n.c=c-1;break;
    }
    case LOP_RETURN:{if(b!=1)reg(a,pc);else if(a>p.slots)bad(p.id,pc,"empty return boundary exceeds frame");if(b&&a+b-1>p.slots)bad(p.id,pc,"fixed return exceeds frame");auto& n=node("Return");n.a=a;n.b=b-1;break;}
    case LOP_JUMP:case LOP_JUMPBACK:case LOP_JUMPX:{
     auto& n=node("Jump");n.yes=jumpTarget(int64_t(pc)+1+(op==LOP_JUMPX?LUAU_INSN_E(w):d));break;
    }
    case LOP_CMPPROTO:bad(p.id,pc,"profiled native-proto guards are outside the source-frontend reference subset");
    case LOP_JUMPIF:case LOP_JUMPIFNOT:{auto& n=node("BranchTruth");n.x=reg(a,pc);n.b=op==LOP_JUMPIF?1:0;n.yes=jumpTarget(int64_t(pc)+1+d);n.no=pc+1;break;}
    case LOP_JUMPIFEQ:case LOP_JUMPIFLE:case LOP_JUMPIFLT:case LOP_JUMPIFNOTEQ:case LOP_JUMPIFNOTLE:case LOP_JUMPIFNOTLT:{
     if(aux>255)bad(p.id,pc,"comparison AUX contains reserved bits");
     const char* names[]={"eq","le","lt","ne","not_le","not_lt"};compare(names[op-LOP_JUMPIFEQ],reg(a,pc),reg(int(aux),pc));break;
    }
    case LOP_JUMPXEQKNIL:case LOP_JUMPXEQKB:case LOP_JUMPXEQKN:case LOP_JUMPXEQKS:{
     if((op==LOP_JUMPXEQKNIL&&(aux&0x7fffffffu))||(op==LOP_JUMPXEQKB&&(aux&0x7ffffffeu))||((op==LOP_JUMPXEQKN||op==LOP_JUMPXEQKS)&&(aux&0x7f000000u)))bad(p.id,pc,"reserved comparison AUX bits");
     if(op==LOP_JUMPXEQKN||op==LOP_JUMPXEQKS){konst(int(aux&0xffffff),pc);if(p.constants[aux&0xffffff].tag!=(op==LOP_JUMPXEQKN?LBC_CONSTANT_NUMBER:LBC_CONSTANT_STRING))bad(p.id,pc,"specialized comparison constant has the wrong type");}
     Ref value=op==LOP_JUMPXEQKNIL?nil():op==LOP_JUMPXEQKB?Ref{4,int(aux&1),0}:scalar(int(aux&0xffffff),pc);
     compare((aux>>31)?"ne":"eq",reg(a,pc),value);break;
    }
    case LOP_ADD:case LOP_SUB:case LOP_MUL:case LOP_DIV:case LOP_MOD:case LOP_POW:{const char* names[]={"add","sub","mul","div","mod","pow"};binary(names[op-LOP_ADD],reg(b,pc),reg(c,pc));break;}
    case LOP_ADDK:case LOP_SUBK:case LOP_MULK:case LOP_DIVK:case LOP_MODK:case LOP_POWK:{const char* names[]={"add","sub","mul","div","mod","pow"};binary(names[op-LOP_ADDK],reg(b,pc),scalar(c,pc));break;}
    case LOP_AND:case LOP_OR:binary(op==LOP_AND?"and":"or",reg(b,pc),reg(c,pc));break;
    case LOP_ANDK:case LOP_ORK:binary(op==LOP_ANDK?"and":"or",reg(b,pc),scalar(c,pc));break;
    case LOP_SUBRK:case LOP_DIVRK:binary(op==LOP_SUBRK?"sub":"div",scalar(b,pc),reg(c,pc));break;
    case LOP_IDIV:binary("idiv",reg(b,pc),reg(c,pc));break;
    case LOP_IDIVK:binary("idiv",reg(b,pc),scalar(c,pc));break;
    case LOP_CONCAT:{reg(a,pc);reg(b,pc);reg(c,pc);if(b>c)bad(p.id,pc,"invalid concat range");auto& n=node("Concat");n.a=a;n.b=b;n.c=c;break;}
    case LOP_NOT:case LOP_MINUS:case LOP_LENGTH:{reg(a,pc);auto& n=node("Unary");n.a=a;n.x=reg(b,pc);n.operatorName=op==LOP_NOT?"not":op==LOP_MINUS?"neg":"length";break;}
    case LOP_NEWTABLE:{reg(a,pc);if(b>20||aux>1000000)bad(p.id,pc,"table capacity exceeds reference limits");auto& n=node("NewTable");n.a=a;n.b=int(aux);n.c=b?int(1u<<(b-1)):0;break;}
    case LOP_DUPTABLE:{reg(a,pc);konst(d,pc);int t=p.constants[d].tag;if(t!=LBC_CONSTANT_TABLE&&t!=LBC_CONSTANT_TABLE_WITH_CONSTANTS)bad(p.id,pc,"clone requires a table shape");auto& n=node("CloneTable");n.a=a;n.b=d;break;}
    case LOP_SETLIST:{reg(a,pc);if(b>p.slots||(c&&b+c-1>p.slots)||aux==0||aux>1000000)bad(p.id,pc,"invalid list write bounds");auto& n=node("WriteList");n.a=a;n.b=b;n.c=c-1;n.cache=int(aux);break;}
    case LOP_FORNPREP:case LOP_FORNLOOP:{reg(a,pc);reg(a+1,pc);reg(a+2,pc);auto& n=node(op==LOP_FORNPREP?"NumericInit":"NumericAdvance");n.a=a;n.yes=jumpTarget(int64_t(pc)+1+d);n.no=pc+1;break;}
    case LOP_FORGPREP:case LOP_FORGPREP_INEXT:case LOP_FORGPREP_NEXT:{
     reg(a,pc);reg(a+1,pc);reg(a+2,pc);int latch=jumpTarget(int64_t(pc)+1+d);
     if(LUAU_INSN_OP(p.words[latch])!=LOP_FORGLOOP||LUAU_INSN_A(p.words[latch])!=unsigned(a)||latch+1>=int(p.words.size()))bad(p.id,pc,"generic loop requires a matching structured latch");
     uint32_t info=p.words[latch+1];int nout=info&255;if(nout==0||nout>190||(info&0x7fffff00))bad(p.id,pc,"invalid/unsupported iterator output arity (1..190)");
     reg(a+2+nout,pc);int body=jumpTarget(int64_t(latch)+1+LUAU_INSN_D(p.words[latch]));if(body<=pc||body>latch)bad(p.id,pc,"unstructured generic loop is not supported");
     auto& n=node("Iterate");n.a=a;n.b=latch;n.c=nout;n.yes=body;n.no=latch+2;m.iteratorArities.insert(nout);break;
    }
    case LOP_FORGLOOP:{reg(a,pc);int count=aux&255;if(count==0||count>190||(aux&0x7fffff00))bad(p.id,pc,"unsupported generic-loop arity");reg(a+2+count,pc);auto& n=node("IterationBoundary");n.a=a;n.c=count;n.yes=jumpTarget(int64_t(pc)+1+d);n.no=pc+2;break;}
    case LOP_GETVARARGS:{reg(a,pc);if(!p.vararg||(b&&a+b-1>p.slots))bad(p.id,pc,"invalid vararg access");auto& n=node("Varargs");n.a=a;n.b=b-1;break;}
    case LOP_PREPVARARGS:{if(!p.vararg||a!=p.params)bad(p.id,pc,"invalid vararg prologue");auto& n=node("Noop");n.note="varargs are handled by frame entry";break;}
    case LOP_FASTCALL:case LOP_FASTCALL1:case LOP_FASTCALL2:case LOP_FASTCALL2K:case LOP_FASTCALL3:case LOP_FASTPCALL:{
     if(op==LOP_FASTPCALL){if(a>1)bad(p.id,pc,"unknown protected-call hint");}
     else {if(a==0||a>LBF_TABLE_CLEAR)bad(p.id,pc,"unknown fastcall builtin ID");if(op!=LOP_FASTCALL)reg(b,pc);
      if(op==LOP_FASTCALL2){if(aux>255)bad(p.id,pc,"reserved fastcall AUX bits");reg(int(aux),pc);}
      if(op==LOP_FASTCALL3){if(aux>65535)bad(p.id,pc,"reserved fastcall AUX bits");reg(int(aux&255),pc);reg(int((aux>>8)&255),pc);}
      if(op==LOP_FASTCALL2K)scalar(int(aux),pc);
     }
     int target=jumpTarget(int64_t(pc)+1+c);if(!std::binary_search(starts.begin(),starts.end(),target))bad(p.id,pc,"fastcall target is AUX/capture data");int call=LUAU_INSN_OP(p.words[target]);if(call!=LOP_CALL&&call!=LOP_CALLFB)bad(p.id,pc,"fastcall has no valid fallback CALL");
     auto& n=node("Noop");n.note="execute compiler-provided ordinary-call fallback";break;
    }
    default:bad(p.id,pc,"unsupported opcode "+std::to_string(op)+"; no silent fallback");
   }
  }
  auto mapTarget=[&](int pc)->int{auto it=anchors.find(pc);if(it==anchors.end())bad(p.id,pc,"control flow targets AUX/capture data or function end");return it->second;};
  for(auto& n:f.code)if(branch(n.op)){n.yes=mapTarget(n.yes);if(n.no>=0)n.no=mapTarget(n.no);if(n.op=="Iterate")n.b=mapTarget(n.b);}
  m.functions.push_back(std::move(f));
 }
 validateAndAnalyze(m);return m;
}
void validateAndAnalyze(Module& m){
 int64_t facts=0;auto budget=[&](int64_t delta){facts+=delta;if(facts>2000000)throw Failure("E_LIMIT: IR register-analysis fact budget exceeded");};
 for(auto& f:m.functions){
  if(f.code.empty())throw Failure("E_IR: empty code");
  std::map<int,int> iterationOwners;
  for(const auto& n:f.code)if(n.op=="Iterate"){if(n.b<1||n.b>int(f.code.size())||f.code[n.b-1].op!="IterationBoundary"||f.code[n.b-1].a!=n.a)throw Failure("E_IR: unmatched iteration latch");++iterationOwners[n.b];}
  for(size_t i=0;i<f.code.size();++i)if(f.code[i].op=="IterationBoundary"&&iterationOwners[int(i)+1]!=1)throw Failure("E_IR: orphan/shared iteration latch");
  auto addRef=[](Node& n,Ref r){if(r.tag==0)n.uses.insert(r.index);};
  auto range=[](std::set<int>& s,int begin,int end){for(int i=begin;i<end;++i)s.insert(i);};
  for(auto& n:f.code){
   const auto& op=n.op;
   if(op=="Assign"){n.defs.insert(n.a);addRef(n,n.x);}
   else if(op=="GlobalRead"){n.defs.insert(n.a);n.effects=Read|Call|Throw|Yield;}
   else if(op=="GlobalWrite"){n.uses.insert(n.a);n.effects=Write|Call|Throw|Yield;}
   else if(op=="UpvalueRead"){n.defs.insert(n.a);n.effects=Read|Cell;}
   else if(op=="UpvalueWrite"){n.uses.insert(n.a);n.effects=Write|Cell;}
   else if(op=="CloseCells"){n.effects=Write|Cell|Allocate;}
   else if(op=="IndexRead"){n.defs.insert(n.a);addRef(n,n.x);addRef(n,n.y);n.effects=Read|Call|Throw|Yield;}
   else if(op=="IndexWrite"){n.uses.insert(n.a);addRef(n,n.x);addRef(n,n.y);n.effects=Write|Call|Throw|Yield;}
   else if(op=="Closure"){n.defs.insert(n.a);for(auto c:n.captures)if(c.kind!=2&&c.index!=n.a)n.uses.insert(c.index);n.effects=Allocate|Cell|Read|Write|Throw;}
   else if(op=="PrepareMethod"){n.defs.insert(n.a);n.defs.insert(n.a+1);addRef(n,n.x);n.effects=Read|Call|Throw|Yield;}
   else if(op=="Invoke"){range(n.uses,n.a,n.b<0?f.slots:n.a+n.b+1);range(n.defs,n.a,n.c<0?f.slots:n.a+n.c);n.topRead=n.b<0;n.topWrite=n.c<0;n.effects=Read|Write|Call|Throw|Yield|Allocate;}
   else if(op=="Return"){range(n.uses,n.a,n.b<0?f.slots:n.a+n.b);n.topRead=n.b<0;n.effects=Control;}
   else if(op=="Binary"||op=="BranchCompare"){addRef(n,n.x);addRef(n,n.y);if(op=="Binary")n.defs.insert(n.a);n.effects=Call|Throw|Yield|(op=="BranchCompare"?Control:0);}
   else if(op=="BranchTruth"){addRef(n,n.x);n.effects=Control;}
   else if(op=="Jump"||op=="IterationBoundary"){n.effects=Control;}
   else if(op=="Concat"){range(n.uses,n.b,n.c+1);n.defs.insert(n.a);n.effects=Call|Throw|Yield|Allocate;}
   else if(op=="Unary"){addRef(n,n.x);n.defs.insert(n.a);if(n.operatorName!="not")n.effects=Call|Throw|Yield;}
   else if(op=="NewTable"||op=="CloneTable"){n.defs.insert(n.a);n.effects=Allocate|Throw;}
   else if(op=="WriteList"){n.uses.insert(n.a);range(n.uses,n.b,n.c<0?f.slots:n.b+n.c);n.topRead=n.c<0;n.effects=Write|Allocate|Throw;}
   else if(op=="NumericInit"||op=="NumericAdvance"){range(n.uses,n.a,n.a+3);range(n.defs,n.a,n.a+3);n.effects=Control|Throw;}
   else if(op=="Iterate"){range(n.uses,n.a,n.a+3);range(n.defs,n.a,n.a+3+n.c);n.effects=Control|Read|Write|Call|Throw|Yield|Allocate;
    if(n.b<n.yes||n.b>=n.no||f.code.at(n.b-1).op!="IterationBoundary")throw Failure("E_IR: malformed structured iteration interval");
   }
   else if(op=="Varargs"){range(n.defs,n.a,n.b<0?f.slots:n.a+n.b);n.topWrite=n.b<0;}
   else if(op!="Noop")throw Failure("E_IR: unknown semantic operation");
   for(int d:n.defs)if(f.escaped.count(d))n.effects|=Cell|Write;
   if(n.effects&Call){insertAll(n.uses,f.escaped);insertAll(n.defs,f.escaped);}
   budget(int64_t(n.uses.size()+n.defs.size()));
  }
  std::set<int> leaders={1};
  for(size_t i=0;i<f.code.size();++i){const auto& n=f.code[i];if(branch(n.op)){leaders.insert(n.yes);if(n.no>=0)leaders.insert(n.no);}if(terminal(n)&&i+1<f.code.size())leaders.insert(int(i)+2);}
  std::vector<int> ls(leaders.begin(),leaders.end());
  for(size_t i=0;i<ls.size();++i){Block b;b.id=int(i);b.begin=ls[i];b.end=i+1<ls.size()?ls[i+1]-1:int(f.code.size());
   if(b.begin<1||b.begin>b.end||b.end>int(f.code.size()))throw Failure("E_IR: invalid block extent");
   int effect=0;
   for(int j=b.begin;j<=b.end;++j){Node& n=f.code[j-1];n.block=b.id;n.effectIn=effect;if(n.effects)++effect;n.effectOut=effect;
    for(int r:n.uses)if(!b.defs.count(r))b.uses.insert(r);insertAll(b.defs,n.defs);
   }
   budget(int64_t(b.uses.size()+b.defs.size()));f.blocks.push_back(std::move(b));
  }
  for(auto& b:f.blocks){const auto& n=f.code[b.end-1];
   if(branch(n.op)){b.successors.insert(f.code.at(n.yes-1).block);if(n.no>=0)b.successors.insert(f.code.at(n.no-1).block);}
   else if(n.op!="Return"){if(b.end>=int(f.code.size()))throw Failure("E_IR: fallthrough past function end");b.successors.insert(f.code[b.end].block);}
  }
  bool changed=true;int rounds=0;
  while(changed){if(++rounds>2048)throw Failure("E_LIMIT: liveness fixpoint iteration limit");changed=false;
   for(auto it=f.blocks.rbegin();it!=f.blocks.rend();++it){std::set<int> out,in;
    for(int s:it->successors)insertAll(out,f.blocks.at(s).liveIn);in=it->uses;
    for(int v:out)if(!it->defs.count(v))in.insert(v);
    if(in!=it->liveIn||out!=it->liveOut){budget(int64_t(in.size()+out.size())-int64_t(it->liveIn.size()+it->liveOut.size()));it->liveIn=std::move(in);it->liveOut=std::move(out);changed=true;}
   }
  }
 }
}
}
