#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include <set>
#include <stdexcept>

namespace p2 {
constexpr const char* CompilerPin="32c28089305f488f901aaf1dbf3fd1cb65fa3d11";
struct Failure:std::runtime_error { using std::runtime_error::runtime_error; };
struct Constant {
 int tag=0; bool boolean=false; double number=0; std::string bytes;
 uint32_t id=0; std::vector<double> vector;
 std::vector<std::pair<uint32_t,int32_t>> entries;
};
struct RawFunction {
 uint32_t id=0; int slots=0,params=0,upvalues=0; bool vararg=false; uint8_t flags=0;
 std::vector<uint32_t> words,children; std::vector<Constant> constants;
 std::vector<int> lines; std::string name; uint32_t lineDefined=0;
 size_t byteBegin=0,byteEnd=0; uint32_t typeBytes=0,feedbackSlots=0;
};
struct RawModule {int version=0,typeVersion=0;uint32_t main=0;std::vector<RawFunction> functions;};
RawModule decode(const std::string& data);
struct Ref {int tag=3,index=0;double number=0;}; // reg, constant, immediate, nil, boolean
struct Capture {int kind=0,index=0;};
enum Effect:uint32_t {Read=1,Write=2,Call=4,Throw=8,Yield=16,Allocate=32,Control=64,Cell=128};
struct Node {
 std::string op,operatorName,key,note;
 int a=0,b=0,c=0,yes=-1,no=-1,proto=-1,cache=-1;
 Ref x,y;std::vector<Capture> captures;
 int pc=0,span=1,line=0,block=0,effectIn=0,effectOut=0;
 uint32_t effects=0;std::set<int> uses,defs;bool topRead=false,topWrite=false;
};
struct Block {int id=0,begin=0,end=0;std::set<int> successors,uses,defs,liveIn,liveOut;};
struct Function {
 int id=0,slots=0,params=0,upvalues=0;bool vararg=false;
 std::string name;int lineDefined=0;std::vector<Constant> constants;
 std::vector<Node> code;std::vector<Block> blocks;std::set<int> escaped;
};
struct Module {
 int schema=1,main=0,bytecodeVersion=0;std::vector<Function> functions;
 std::set<std::string> globals,stores,methods;std::set<int> iteratorArities;
};
Module lower(const RawModule& raw);
void validateAndAnalyze(Module& m);
std::string toJson(const Module& m);
std::string emit(const Module& m,const std::string& runtime,uint64_t seed,bool dataOnly, int profileMode = 1, uint32_t ksplit = 0, int* sensitiveCount = nullptr);
std::string quoteJson(const std::string& x);
std::string quoteLua(const std::string& x);
std::string numberLua(double x);
}
