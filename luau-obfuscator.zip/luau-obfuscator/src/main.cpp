#include "pipeline.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <random>

int p2main(int argc, char** argv) {
    try {
        if (argc < 2) {
            std::cerr << "Usage: luau-obfuscate INPUT -o OUTPUT [options]\n"
                      << "Try 'luau-obfuscate --help' for options.\n";
            return 1;
        }

        std::string firstArg = argv[1];
        if (firstArg == "--info") {
            std::cout << "{\n"
                      << "  \"product\": \"luau-obfuscate\",\n"
                      << "  \"version\": \"3.4.0-release\",\n"
                      << "  \"phase\": 7,\n"
                      << "  \"compiler_pin\": \"" << p2::CompilerPin << "\",\n"
                      << "  \"target_engine\": \"Normal Roblox Luau (Desktop, Mobile, Server)\",\n"
                      << "  \"profiles\": [\"balanced\", \"strong\", \"maximum\", \"native\"],\n"
                      << "  \"hardening\": [\"domain_separated_encoding\", \"seeded_permutation_spaces\", \"anti_tamper\", \"polymorphic_symbols\", \"split_key\", \"permuted_authenticated_header\"],\n"
                      << "  \"security_model\": \"docs/THREAT_MODEL.md (seed is public build-diversity material; encodings are obfuscation, not cryptographic confidentiality)\"\n"
                      << "}\n";
            return 0;
        }

        if (firstArg == "-h" || firstArg == "--help" || firstArg == "help") {
            std::cout << "===============================================================================\n"
                      << " luau-obfuscate: High-Performance Custom VM & Obfuscator for Roblox Luau\n"
                      << "===============================================================================\n"
                      << "Usage:\n"
                      << "  luau-obfuscate INPUT -o OUTPUT [options]\n\n"
                      << "Options:\n"
                      << "  -o, --output PATH       Path for emitted obfuscated script (required)\n"
                      << "  --profile PROFILE       Protection profile:\n"
                      << "                            balanced (default: low-overhead 60/120 FPS game orchestration)\n"
                      << "                            strong   (whole-script custom VM virtualization)\n"
                      << "                            maximum  (max protection for high-value algorithms & licensing)\n"
                      << "                            native   (native Luau obfuscation without VM)\n"
                      << "  --seed N                64-bit deterministic compilation seed\n"
                      << "  -R, --reproducible      Deterministic build mode (normalized timestamps & fixed seed)\n"
                      << "  --debug                 Developer debug profile (emits rich error diagnostics)\n"
                      << "  --harden                Enable multi-layered constant encryption, opcode permutation,\n"
                      << "                          and defensive anti-tamper assertions (default: ON)\n"
                      << "  --no-harden             Disable hardening transformations for testing\n"
                      << "  --minify, --single-line Minify emitted script into a single line (no newlines)\n"
                      << "  --report PATH           Export machine-readable JSON policy audit: profile,\n"
                      << "                          transformation manifest, cache/anti-tamper policies,\n"
                      << "                          sensitive-string no-retention count, self-check status\n"
                      << "  --ir PATH               Export internal semantic register IR to JSON file\n"
                      << "  --bytecode PATH         Export raw compiled Luau bytecode to file\n"
                      << "  --runtime PATH          Override embedded custom VM runtime with external file\n"
                      << "  --data-only             Emit test-only binder factory (requires external runtime)\n"
                      << "  -O0, -O1, -O2           Luau compiler optimization level (default: -O1)\n"
                      << "  --info                  Print compiler pin, version, and architecture info\n"
                      << "  -h, --help              Print this help guide\n"
                      << "===============================================================================\n";
            return 0;
        }

        p7::ObfuscationOptions opts;
        int arg_start = 1;
        if (argc > 2 && (std::string(argv[1]) == "build" || std::string(argv[1]) == "compile")) {
            arg_start = 2;
        }
        opts.inputPath = argv[arg_start];

        for (int i = arg_start + 1; i < argc; ++i) {
            std::string s = argv[i];
            auto getValue = [&]() -> std::string {
                if (++i >= argc) throw p2::Failure("E_ARGS: missing value for option " + s);
                return argv[i];
            };

            if (s == "-o" || s == "--output") {
                opts.outputPath = getValue();
            } else if (s == "--profile") {
                std::string p = getValue();
                if (p == "balanced" || p == "strong-smooth" || p == "hybrid") opts.profile = p7::Profile::Balanced;
                else if (p == "strong" || p == "whole-vm" || p == "vm") opts.profile = p7::Profile::Strong;
                else if (p == "maximum" || p == "max") opts.profile = p7::Profile::Maximum;
                else if (p == "native") opts.profile = p7::Profile::Native;
                else throw p2::Failure("E_ARGS: unknown profile '" + p + "'; expected balanced, strong, maximum, or native");
            } else if (s == "--seed") {
                std::string v = getValue();
                size_t n = 0;
                opts.seed = std::stoull(v, &n);
                if (n != v.size() || v.empty() || v[0] == '-')
                    throw p2::Failure("E_ARGS: invalid seed value");
            } else if (s == "-R" || s == "--reproducible") {
                opts.reproducible = true;
            } else if (s == "--debug") {
                opts.debugMode = true;
            } else if (s == "--report") {
                opts.reportPath = getValue();
            } else if (s == "--ir") {
                opts.irPath = getValue();
            } else if (s == "--bytecode") {
                opts.bytecodePath = getValue();
            } else if (s == "--runtime") {
                opts.customRuntimePath = getValue();
            } else if (s == "--harden") {
                opts.harden = true;
            } else if (s == "--no-harden") {
                opts.harden = false;
            } else if (s == "--minify" || s == "--single-line") {
                opts.minify = true;
            } else if (s == "--data-only") {
                opts.dataOnly = true;
            } else if (s.size() == 3 && s.substr(0, 2) == "-O") {
                int level = s[2] - '0';
                if (level < 0 || level > 2) throw p2::Failure("E_ARGS: optimization level must be 0, 1, or 2");
                opts.optLevel = level;
            } else {
                throw p2::Failure("E_ARGS: unrecognized command line option: " + s);
            }
        }

        if (opts.outputPath.empty()) {
            throw p2::Failure("E_ARGS: output path (-o / --output) is required");
        }

        auto report = p7::runPipeline(opts);
        std::cout << "[luau-obfuscate] Obfuscation complete: " << opts.inputPath << " -> " << opts.outputPath << "\n"
                  << "  Profile:  " << report.profileSelected << "\n"
                  << "  Size:     " << report.originalSizeBytes << " B -> " << report.outputSizeBytes << " B\n"
                  << "  Seed:     0x" << std::hex << report.seedUsed << std::dec << "\n"
                  << "  Security: " << (report.containsSensitiveLogic ? "Sensitive logic detected & virtualized" : "Verified kernel") << "\n";
        return 0;

    } catch (const p2::Failure& e) {
        std::cerr << "Error: " << e.what() << "\n";
        return 1;
    } catch (const std::exception& e) {
        std::cerr << "Unexpected error: " << e.what() << "\n";
        return 1;
    }
}
