// UTF-8 paths internally; Windows uses the wide console entry point.
#include <string>
#include <vector>
#include <iostream>
int p2main(int argc,char** argv);
#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
int wmain(int argc,wchar_t** argv){
 std::vector<std::string> values;values.reserve(argc);
 for(int i=0;i<argc;++i){int n=WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,argv[i],-1,nullptr,0,nullptr,nullptr);
  if(n==0){std::cerr<<"E_ARGS: invalid UTF-16 argument\n";return 1;}
  std::string s(n,'\0');if(!WideCharToMultiByte(CP_UTF8,WC_ERR_INVALID_CHARS,argv[i],-1,s.data(),n,nullptr,nullptr))return 1;
  s.resize(n-1);values.push_back(std::move(s));
 }
 std::vector<char*> pointers;for(auto& v:values)pointers.push_back(v.data());pointers.push_back(nullptr);
 return p2main(argc,pointers.data());
}
#else
int main(int argc,char** argv){return p2main(argc,argv);}
#endif
