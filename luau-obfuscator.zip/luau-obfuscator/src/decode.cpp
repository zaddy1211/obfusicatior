// Independent bounded decoder for the pinned Luau v13/type-v3 serialization.
// Format reference: official Luau Bytecode.h / BytecodeBuilder.cpp (MIT).
#include "model.hpp"
#include "Luau/Bytecode.h"
#include <cstring>
#include <limits>
#include <cmath>
namespace p2 {
namespace {
struct Reader {
 const std::string& s;size_t at=0,end;
 explicit Reader(const std::string& x):s(x),end(x.size()){}
 Reader(const std::string& x,size_t a,size_t e):s(x),at(a),end(e){}
 [[noreturn]] void fail(const std::string& x)const{throw Failure("E_DECODE at byte "+std::to_string(at)+": "+x);}
 void need(size_t n)const{if(n>end-at)fail("truncated section");}
 uint8_t byte(){need(1);return uint8_t(s[at++]);}
 uint32_t u32(){need(4);uint32_t x=0;for(int i=0;i<4;++i)x|=uint32_t(uint8_t(s[at++]))<<(i*8);return x;}
 int32_t i32(){return int32_t(u32());}
 uint64_t u64(){need(8);uint64_t x=0;for(int i=0;i<8;++i)x|=uint64_t(uint8_t(s[at++]))<<(i*8);return x;}
 double f64(){uint64_t bits=u64();double x;std::memcpy(&x,&bits,8);return x;}
 double f32(){uint32_t bits=u32();float x;std::memcpy(&x,&bits,4);return x;}
 uint32_t var(){uint32_t v=0;for(int i=0;i<5;++i){uint8_t b=byte();if(i==4&&(b&0xf0))fail("varuint32 overflow");v|=uint32_t(b&127)<<(7*i);if(!(b&128)){if(i&&b==0)fail("noncanonical varuint32");return v;}}fail("unterminated varuint32");}
 uint64_t var64(){uint64_t v=0;for(int i=0;i<10;++i){uint8_t b=byte();if(i==9&&(b&0xfe))fail("varuint64 overflow");v|=uint64_t(b&127)<<(7*i);if(!(b&128)){if(i&&b==0)fail("noncanonical varuint64");return v;}}fail("unterminated varuint64");}
 uint32_t count(uint32_t limit,const char* label){uint32_t n=var();if(n>limit)fail(std::string(label)+" exceeds resource limit");return n;}
 std::string bytes(size_t n){need(n);std::string out=s.substr(at,n);at+=n;return out;}
 void skip(size_t n){need(n);at+=n;}
 bool flag(){auto x=byte();if(x>1)fail("invalid boolean flag");return x!=0;}
};
}
RawModule decode(const std::string& data){
 if(data.size()>16*1024*1024)throw Failure("E_LIMIT: bytecode larger than 16 MiB");
 Reader r(data);RawModule m;m.version=r.byte();
 if(m.version!=13)r.fail("unsupported bytecode version; this decoder requires pinned v13");
 m.typeVersion=r.byte();if(m.typeVersion!=3)r.fail("unsupported type encoding; requires v3");
 uint32_t ns=r.count(1000000,"string count");if(ns>r.end-r.at)r.fail("impossible string count");
 std::vector<std::string> strings;strings.reserve(ns);
 for(uint32_t i=0;i<ns;++i)strings.push_back(r.bytes(r.count(8*1024*1024,"string size")));
 auto str=[&](Reader& in,uint32_t id,bool optional=false)->std::string{
  if(id==0&&optional)return "";if(id==0||id>strings.size())in.fail("string ID out of bounds");return strings[id-1];
 };
 std::set<uint8_t> mapped;
 for(;;){uint8_t ix=r.byte();if(ix==0)break;if(ix>32||!mapped.insert(ix).second)r.fail("invalid userdata remapping");str(r,r.var());}
 uint32_t nf=r.count(10000,"function count");if(nf==0||nf>r.end-r.at)r.fail("impossible function count");
 uint64_t totalWords=0,totalConstants=0;
 m.functions.reserve(nf);
 for(uint32_t fi=0;fi<nf;++fi){
  uint32_t len=r.count(16*1024*1024,"function size");r.need(len);size_t begin=r.at,finish=begin+len;
  Reader f(data,begin,finish);RawFunction p;p.id=fi;p.byteBegin=begin;p.byteEnd=finish;
  p.slots=f.byte();p.params=f.byte();p.upvalues=f.byte();p.vararg=f.flag();p.flags=f.byte();
  if(p.params>p.slots||p.upvalues>200)f.fail("invalid function frame header");
  if(p.flags&~31)f.fail("unknown proto flags");
  if(p.flags&(LPF_NATIVE_MODULE|LPF_NATIVE_FUNCTION))f.fail("native directives are outside the client reference target");
  p.typeBytes=f.count(8*1024*1024,"type section");f.skip(p.typeBytes);
  uint32_t nw=f.count(50000,"instruction words per function");totalWords+=nw;if(totalWords>250000)f.fail("module instruction word budget exceeded");if(nw==0||uint64_t(nw)*4>f.end-f.at)f.fail("impossible instruction word count");
  p.words.reserve(nw);for(uint32_t j=0;j<nw;++j)p.words.push_back(f.u32());
  uint32_t nk=f.count(250000,"constant count");totalConstants+=nk;if(totalConstants>250000)f.fail("module constant budget exceeded");if(nk>f.end-f.at)f.fail("impossible constant count");
  p.constants.reserve(nk);
  for(uint32_t j=0;j<nk;++j){
   Constant k;k.tag=f.byte();
   switch(k.tag){
    case LBC_CONSTANT_NIL:break;
    case LBC_CONSTANT_BOOLEAN:k.boolean=f.flag();break;
    case LBC_CONSTANT_NUMBER:k.number=f.f64();break;
    case LBC_CONSTANT_STRING:k.bytes=str(f,f.var());break;
    case LBC_CONSTANT_IMPORT:{k.id=f.u32();uint32_t count=k.id>>30;if(count<1||count>3)f.fail("invalid import path length");uint32_t ids[3]={(k.id>>20)&1023,(k.id>>10)&1023,k.id&1023};for(uint32_t q=0;q<count;++q)if(ids[q]>=j||p.constants[ids[q]].tag!=LBC_CONSTANT_STRING)f.fail("import path requires preceding string constants");if((count==1&&(k.id&0xfffff))||(count==2&&(k.id&1023)))f.fail("nonzero unused import components");break;}
    case LBC_CONSTANT_TABLE:case LBC_CONSTANT_TABLE_WITH_CONSTANTS:{
     uint32_t n=f.count(1000000,"template entries");if(uint64_t(n)*(k.tag==LBC_CONSTANT_TABLE?1:5)>f.end-f.at)f.fail("impossible table shape size");
     for(uint32_t i=0;i<n;++i){auto key=f.var();int32_t val=k.tag==LBC_CONSTANT_TABLE?-1:f.i32();if(key>=j||val>=int32_t(j))f.fail("table shape references a future/invalid constant");if(p.constants[key].tag!=LBC_CONSTANT_STRING)f.fail("table shape key must be a string");if(val>=0){int t=p.constants[val].tag;if(t!=0&&t!=1&&t!=2&&t!=3&&t!=7)f.fail("unsupported table shape value kind");}k.entries.emplace_back(key,val);}break;
    }
    case LBC_CONSTANT_CLOSURE:k.id=f.var();if(k.id>=fi)f.fail("closure constant must reference an earlier function");break;
    case LBC_CONSTANT_VECTOR:for(int i=0;i<4;++i)k.vector.push_back(f.f32());break;
    case LBC_CONSTANT_INTEGER:f.fail("integer64 constants are not supported in the normal-client reference subset");
    case LBC_CONSTANT_CLASS_SHAPE:f.fail("experimental class constants are not supported");
    case LBC_CONSTANT_VECTORD:f.fail("double-precision vector constants are not supported");
    default:f.fail("unknown constant tag "+std::to_string(k.tag));
   }
   p.constants.push_back(std::move(k));
  }
  uint32_t nc=f.count(100000,"child count");for(uint32_t i=0;i<nc;++i){uint32_t id=f.var();if(id>=fi)f.fail("child must reference an earlier function");p.children.push_back(id);}
  p.lineDefined=f.var();if(p.lineDefined>0x7fffffff)f.fail("line-defined overflow");p.name=str(f,f.var(),true);
  p.lines.assign(nw,0);
  if(f.flag()){
   uint8_t gap=f.byte();if(gap>31)f.fail("line gap shift is invalid");
   std::vector<uint8_t> relative(nw);uint8_t last=0;for(uint32_t i=0;i<nw;++i){last=uint8_t(last+f.byte());relative[i]=last;}
   uint32_t intervals=((nw-1)>>gap)+1;int64_t absolute=0;
   std::vector<int> bases;for(uint32_t i=0;i<intervals;++i){absolute+=f.i32();if(absolute<0||absolute>0x7fffffff)f.fail("invalid absolute line");bases.push_back(int(absolute));}
   for(uint32_t i=0;i<nw;++i){int64_t line=int64_t(bases[i>>gap])+relative[i];if(line>0x7fffffff)f.fail("line overflow");p.lines[i]=int(line);}
  }
  if(f.flag()){
   uint32_t n=f.count(1000000,"debug locals");
   for(uint32_t i=0;i<n;++i){str(f,f.var());uint32_t start=f.var(),end=f.var();uint8_t reg=f.byte();if(start>end||end>nw||reg>=p.slots)f.fail("invalid debug local range");}
   n=f.count(200,"debug upvalues");if(n!=uint32_t(p.upvalues))f.fail("debug upvalue count mismatch");for(uint32_t i=0;i<n;++i)str(f,f.var());
  }
  p.feedbackSlots=f.count(1000000,"feedback slots");
  for(uint32_t i=0;i<p.feedbackSlots;++i){uint8_t kind=f.byte();uint32_t value=f.var();if(kind!=0)f.fail("unsupported feedback slot kind");if(value>=nw)f.fail("feedback PC out of range");}
  if(p.flags&LPF_INLINABLE)f.var64();
  if(f.at!=finish)f.fail("unconsumed proto bytes; refusing format drift");
  m.functions.push_back(std::move(p));r.at=finish;
 }
 m.main=r.var();if(m.main>=m.functions.size())r.fail("main function out of range");
 if(m.functions[m.main].upvalues)r.fail("main function cannot have external upvalues");
 if(r.at!=r.end)r.fail("trailing bytes after main function");
 return m;
}
}
