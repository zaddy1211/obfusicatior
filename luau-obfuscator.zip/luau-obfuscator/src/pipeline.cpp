#include "pipeline.hpp"
#include "runtime.hpp"
#include "Luau/Compiler.h"
#include "Luau/Parser.h"
#include "Luau/Allocator.h"
#include <filesystem>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <random>
#include <algorithm>
#include <cstring>
#include <cmath>
#include <regex>
#include <iostream>

namespace fs = std::filesystem;

namespace p7 {

static const std::vector<std::string> SENSITIVE_TOKENS = {
    "checksum", "verify", "token", "secret", "auth", "license", "seq",
    "validate", "signature", "tamper", "anti_cheat", "admin", "permission", "ban"
};

static std::string readFile(const fs::path& p, size_t cap) {
    std::ifstream f(p, std::ios::binary);
    if (!f) throw p2::Failure("E_IO: cannot read " + p.string());
    f.seekg(0, std::ios::end);
    auto n = f.tellg();
    if (n < 0 || uint64_t(n) > cap) throw p2::Failure("E_LIMIT: input size limit exceeded");
    f.seekg(0);
    std::string s(size_t(n), '\0');
    if (n && !f.read(s.data(), n)) throw p2::Failure("E_IO: input read failed");
    return s;
}

static void writeFile(const fs::path& p, const std::string& s) {
    if (p.empty()) return;
    if (!p.parent_path().empty()) fs::create_directories(p.parent_path());
    std::ofstream f(p, std::ios::binary | std::ios::trunc);
    if (!f || !f.write(s.data(), std::streamsize(s.size())))
        throw p2::Failure("E_IO: output write failed: " + p.string());
}

static std::vector<std::string> scanSensitiveTokens(const std::string& source) {
    std::vector<std::string> detected;
    for (const auto& tok : SENSITIVE_TOKENS) {
        std::regex re(tok, std::regex_constants::icase);
        if (std::regex_search(source, re)) {
            detected.push_back(tok);
        }
    }
    return detected;
}

namespace {
std::string unescapeLua(const std::string& s) {
    std::string out;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '\\' && i + 1 < s.size()) {
            if (s[i+1] == '\\') { out += '\\'; i += 1; }
            else if (s[i+1] == '"') { out += '"'; i += 1; }
            else if (s[i+1] == 'n') { out += '\n'; i += 1; }
            else if (s[i+1] == 't') { out += '\t'; i += 1; }
            else if (s[i+1] == 'r') { out += '\r'; i += 1; }
            else if (std::isdigit(static_cast<unsigned char>(s[i+1]))) {
                int val = 0;
                int count = 0;
                while (i + 1 < s.size() && std::isdigit(static_cast<unsigned char>(s[i+1])) && count < 3) {
                    val = val * 10 + (s[i+1] - '0');
                    i += 1;
                    count += 1;
                }
                out += static_cast<char>(val);
            } else {
                out += s[i+1];
                i += 1;
            }
        } else {
            out += s[i];
        }
    }
    return out;
}

std::string minifyToOneLine(const std::string& content) {
    size_t pos = 0;
    size_t length = content.size();
    std::vector<std::string> tokens;

    while (pos < length) {
        // Comment
        if (pos + 1 < length && content[pos] == '-' && content[pos + 1] == '-') {
            if (pos + 3 < length && content[pos + 2] == '[' && content[pos + 3] == '[') {
                size_t endIdx = content.find("]]", pos + 4);
                if (endIdx != std::string::npos) {
                    pos = endIdx + 2;
                    tokens.push_back(" ");
                    continue;
                }
            }
            // Single line comment: advance past newline
            size_t endIdx = content.find('\n', pos + 2);
            if (endIdx == std::string::npos) {
                break;
            }
            pos = endIdx + 1;
            tokens.push_back(" ");
            continue;
        }

        // Double quoted string
        if (content[pos] == '"') {
            size_t endIdx = pos + 1;
            while (endIdx < length) {
                if (content[endIdx] == '\\') {
                    endIdx += 2;
                } else if (content[endIdx] == '"') {
                    endIdx += 1;
                    break;
                } else {
                    endIdx += 1;
                }
            }
            tokens.push_back(content.substr(pos, endIdx - pos));
            pos = endIdx;
            continue;
        }

        // Single quoted string
        if (content[pos] == '\'') {
            size_t endIdx = pos + 1;
            while (endIdx < length) {
                if (content[endIdx] == '\\') {
                    endIdx += 2;
                } else if (content[endIdx] == '\'') {
                    endIdx += 1;
                    break;
                } else {
                    endIdx += 1;
                }
            }
            tokens.push_back(content.substr(pos, endIdx - pos));
            pos = endIdx;
            continue;
        }

        // Whitespace & newlines
        if (content[pos] == ' ' || content[pos] == '\t' || content[pos] == '\r' || content[pos] == '\n') {
            tokens.push_back(" ");
            pos += 1;
            continue;
        }

        tokens.push_back(std::string(1, content[pos]));
        pos += 1;
    }

    std::string out;
    const std::string delim = ",;{}()[]=+-*/%^#<>~";
    for (const auto& t : tokens) {
        if (t == " ") {
            if (out.empty()) continue;
            char prev = out.back();
            if (delim.find(prev) != std::string::npos || prev == ' ') {
                continue;
            }
            out += ' ';
        } else {
            if (t.size() == 1 && delim.find(t[0]) != std::string::npos && !out.empty() && out.back() == ' ') {
                out.pop_back();
            }
            out += t;
        }
    }
    return out;
}
} // namespace

// =============================================================================
// Structured runtime generation (F3 remediation). All transformations operate
// on marker-delimited regions of the runtime template and FAIL THE BUILD
// (E_RUNTIME_TRANSFORM) instead of silently falling back to the raw template.
//
// Template markers:
//   KZ:GEN:HEADER:BEGIN/END    (split-key + header-size constants)
//   KZ:GEN:OPMAP:BEGIN/END     (permuted-opcode -> dispatch-value mapping)
//   KZ:GEN:DISPATCH:BEGIN/END  (canonical 27-arm linear dispatch chain)
// =============================================================================

static std::string spliceMarkedRegion(
    const std::string& text,
    const std::string& beginMarker,
    const std::string& endMarker,
    const std::string& newInner
) {
    size_t b = text.find(beginMarker);
    if (b == std::string::npos)
        throw p2::Failure("E_RUNTIME_TRANSFORM: missing region begin marker '" + beginMarker + "'");
    size_t bLineEnd = text.find('\n', b);
    if (bLineEnd == std::string::npos)
        throw p2::Failure("E_RUNTIME_TRANSFORM: malformed begin marker line '" + beginMarker + "'");
    size_t e = text.find(endMarker, bLineEnd + 1);
    if (e == std::string::npos)
        throw p2::Failure("E_RUNTIME_TRANSFORM: missing region end marker '" + endMarker + "'");
    size_t eLineStart = text.rfind('\n', e);
    if (eLineStart == std::string::npos || eLineStart < bLineEnd)
        throw p2::Failure("E_RUNTIME_TRANSFORM: malformed end marker line '" + endMarker + "'");
    return text.substr(0, bLineEnd + 1) + newInner + text.substr(eLineStart + 1);
}

// Injects the per-build split key constant into the runtime. The buffer header
// alone then lacks enough information to derive the working decode state; the
// split key exists only inside the (symbol-randomized, minified) runtime text.
static std::string injectSplitKey(const std::string& runtimeText, uint32_t ksplit) {
    std::ostringstream inner;
    inner << "    local _HDR = 32\n";
    inner << "    local _KSPLIT = 0x" << std::hex << std::uppercase << std::setw(8) << std::setfill('0') << ksplit << "\n";
    return spliceMarkedRegion(runtimeText, "-- KZ:GEN:HEADER:BEGIN", "-- KZ:GEN:HEADER:END", inner.str());
}

// Randomized dispatch-tree synthesis: unbalanced pivots, randomly flipped
// comparison directions, and occasional linear equality subchains for small
// state sets. Two builds with the same logical opcode set now produce
// measurably different dispatcher control-flow shapes.
static std::string buildDispatchTree(
    const std::vector<int>& states,
    const std::map<int, int>& state_to_op,
    const std::map<int, std::string>& branches,
    int indent,
    std::mt19937_64& prng,
    int& leaf_count
) {
    std::string sp(indent, ' ');
    size_t n = states.size();
    if (n == 1) {
        leaf_count++;
        return branches.at(state_to_op.at(states[0])) + "\n";
    }
    if (n == 2) {
        leaf_count += 2;
        std::string c1 = branches.at(state_to_op.at(states[0]));
        std::string c2 = branches.at(state_to_op.at(states[1]));
        if (prng() & 1) {
            return sp + "if h <= " + std::to_string(states[0]) + " then\n" + c1 + "\n" + sp + "else\n" + c2 + "\n" + sp + "end\n";
        }
        return sp + "if h > " + std::to_string(states[0]) + " then\n" + c2 + "\n" + sp + "else\n" + c1 + "\n" + sp + "end\n";
    }
    if (n <= 4 && (prng() % 100) < 24) {
        leaf_count += int(n);
        std::ostringstream o;
        for (size_t i = 0; i < n; ++i) {
            int st = states[i];
            if (i + 1 == n) {
                o << sp << "else\n" << branches.at(state_to_op.at(st)) << "\n";
            } else {
                o << sp << (i == 0 ? "if" : "elseif") << " h == " << st << " then\n"
                  << branches.at(state_to_op.at(st)) << "\n";
            }
        }
        o << sp << "end\n";
        return o.str();
    }
    size_t mid = n / 2;
    if ((prng() % 100) < 60) {
        size_t lo = n / 3;
        size_t hi = n - n / 3;
        if (hi > lo) mid = lo + (prng() % (hi - lo));
    }
    if (mid < 1) mid = 1;
    if (mid >= n) mid = n - 1;
    int split = states[mid - 1];
    std::vector<int> left_states(states.begin(), states.begin() + mid);
    std::vector<int> right_states(states.begin() + mid, states.end());
    std::string left = buildDispatchTree(left_states, state_to_op, branches, indent + 4, prng, leaf_count);
    std::string right = buildDispatchTree(right_states, state_to_op, branches, indent + 4, prng, leaf_count);
    if (prng() & 1) {
        return sp + "if h <= " + std::to_string(split) + " then\n" + left + sp + "else\n" + right + sp + "end\n";
    }
    return sp + "if h > " + std::to_string(split) + " then\n" + right + sp + "else\n" + left + sp + "end\n";
}

// Shuffles one linear equality sub-dispatch chain (e.g. "bop == N") as whole
// (number, expression) units. Order of mutually exclusive equality tests is
// semantically irrelevant, but cross-build arm ordering measurably diversifies
// handler control-flow shape. Validates the reconstructed arm multiset.
static int shuffleSubDispatch(std::string& armBody, const std::string& varName, std::mt19937_64& prng, const char* ctx) {
    std::istringstream in(armBody);
    std::vector<std::string> lines;
    std::string line;
    while (std::getline(in, line)) lines.push_back(line);

    std::regex armRe("^\\s*(?:if|elseif) " + varName + " == (\\d+) then (.+)$");
    std::vector<int> idxs;
    for (size_t i = 0; i < lines.size(); ++i) {
        if (std::regex_match(lines[i], armRe)) idxs.push_back(int(i));
    }
    if (idxs.size() < 2) return 0;

    // The run must be consecutive
    for (size_t k = 1; k < idxs.size(); ++k) {
        if (idxs[k] != idxs[k - 1] + 1) {
            throw p2::Failure(std::string("E_RUNTIME_TRANSFORM: non-consecutive sub-dispatch chain for '") + varName + "' in " + ctx);
        }
    }

    std::vector<std::pair<int, std::string>> units; // (selector value, payload)
    std::vector<std::string> indents;
    for (int li : idxs) {
        std::smatch m;
        if (!std::regex_match(lines[size_t(li)], m, armRe))
            throw p2::Failure(std::string("E_RUNTIME_TRANSFORM: sub-dispatch parse failed for '") + varName + "' in " + ctx);
        units.push_back({ std::stoi(m[1].str()), m[2].str() });
        size_t sp = lines[size_t(li)].find_first_not_of(' ');
        indents.push_back(lines[size_t(li)].substr(0, sp));
    }
    std::string indent = indents[0];

    std::vector<std::pair<int, std::string>> before = units;
    std::shuffle(units.begin(), units.end(), prng);
    std::sort(before.begin(), before.end());
    auto sortedAfter = units;
    std::sort(sortedAfter.begin(), sortedAfter.end());
    if (before != sortedAfter)
        throw p2::Failure(std::string("E_RUNTIME_TRANSFORM: sub-dispatch shuffle lost arms for '") + varName + "' in " + ctx);

    for (size_t k = 0; k < units.size(); ++k) {
        std::ostringstream nl;
        nl << indent << (k == 0 ? "if " : "elseif ") << varName << " == " << units[k].first << " then " << units[k].second;
        lines[size_t(idxs[k])] = nl.str();
    }

    std::ostringstream out;
    for (size_t i = 0; i < lines.size(); ++i) {
        if (i) out << "\n";
        out << lines[i];
    }
    armBody = out.str();
    return int(units.size());
}

static std::string synthesizeBinarySearchDispatcher(const std::string& runtimeText, uint64_t seed) {
    // 1. Extract the canonical linear dispatch region between markers.
    size_t b = runtimeText.find("-- KZ:GEN:DISPATCH:BEGIN");
    size_t e = runtimeText.find("-- KZ:GEN:DISPATCH:END");
    if (b == std::string::npos || e == std::string::npos || e <= b)
        throw p2::Failure("E_RUNTIME_TRANSFORM: dispatch markers missing; runtime template is not generation-capable");
    size_t bLineEnd = runtimeText.find('\n', b);
    size_t eLineStart = runtimeText.rfind('\n', e);
    std::string region = runtimeText.substr(bLineEnd + 1, eLineStart - bLineEnd - 1);

    std::istringstream stream(region);
    std::string line;
    std::vector<std::string> lines;
    while (std::getline(stream, line)) lines.push_back(line);

    std::regex headRe(R"(^\s*(?:if|elseif) h == (\d+) then\s*$)");

    // 2. Split preamble (shared register-A reader) from the arm chain.
    std::map<int, std::string> branches;
    int current_op = -1;
    std::vector<std::string> current_lines;
    int chain_end_idx = -1;

    auto flushArm = [&]() {
        if (current_op < 0) return;
        std::ostringstream ss;
        for (size_t k = 0; k < current_lines.size(); ++k) {
            if (k) ss << "\n";
            ss << current_lines[k];
        }
        branches[current_op] = ss.str();
        current_lines.clear();
    };

    for (size_t i = 0; i < lines.size(); ++i) {
        std::smatch m;
        if (std::regex_match(lines[i], m, headRe)) {
            flushArm();
            current_op = std::stoi(m[1].str());
        } else if (current_op != -1) {
            // The chain terminator is the closing "end" at exactly 12-space
            // indentation; nested block terminators inside arms sit deeper.
            if (lines[i] == "            end") {
                flushArm();
                chain_end_idx = int(i);
                current_op = -1;
                break;
            }
            current_lines.push_back(lines[i]);
        }
    }

    // 3. Hard-fail structural validation: exactly one arm for each op 0..26.
    if (branches.size() != 27 || chain_end_idx < 0)
        throw p2::Failure("E_RUNTIME_TRANSFORM: expected exactly 27 dispatch arms and a chain terminator, found " + std::to_string(branches.size()));
    for (int op = 0; op < 27; ++op) {
        if (!branches.count(op))
            throw p2::Failure("E_RUNTIME_TRANSFORM: dispatch arm for op " + std::to_string(op) + " is missing");
        if (branches[op].find_first_not_of(" \t\n\r") == std::string::npos && op != 0)
            throw p2::Failure("E_RUNTIME_TRANSFORM: dispatch arm for op " + std::to_string(op) + " is empty");
    }

    // 4. Per-arm regeneration: prepend the register-A read (dropped shared
    //    preamble) and diversify sub-dispatch arm ordering per build.
    std::set<int> no_a_ops = {0, 14, 15, 16, 25};
    std::mt19937_64 prng(seed ^ 0x7E7E9191ULL);
    int shuffled_arms_total = 0;
    for (int op = 0; op < 27; ++op) {
        std::string body = branches[op];
        if (op == 2) shuffled_arms_total += shuffleSubDispatch(body, "bop", prng, "Binary");
        if (op == 16) shuffled_arms_total += shuffleSubDispatch(body, "cmp_op", prng, "BranchCompare");
        if (op == 18) shuffled_arms_total += shuffleSubDispatch(body, "uop", prng, "Unary");
        if (!no_a_ops.count(op)) {
            body = "                local a = _bx(_ru8(_bc, pc), _am(_sd, pc))\n                pc = pc + 1\n" + body;
        }
        branches[op] = body;
    }
    if (shuffled_arms_total != 9 + 8 + 3)
        throw p2::Failure("E_RUNTIME_TRANSFORM: sub-dispatch diversification incomplete (bop/cmp/uop)");

    // 5. State-space assignment and randomized dispatch-tree synthesis.
    std::vector<int> candidates(237);
    for (int i = 0; i < 237; ++i) candidates[i] = 12 + i;
    std::shuffle(candidates.begin(), candidates.end(), prng);
    std::vector<int> sorted_states(candidates.begin(), candidates.begin() + 27);
    std::sort(sorted_states.begin(), sorted_states.end());

    std::map<int, int> op_to_state;
    std::map<int, int> state_to_op;
    for (int op = 0; op < 27; ++op) {
        op_to_state[op] = sorted_states[size_t(op)];
        state_to_op[sorted_states[size_t(op)]] = op;
    }

    int leaf_count = 0;
    std::string bst_code = buildDispatchTree(sorted_states, state_to_op, branches, 12, prng, leaf_count);

    // Validate tree coverage: exactly 27 arm leaves must have been emitted.
    if (leaf_count != 27)
        throw p2::Failure("E_RUNTIME_TRANSFORM: synthesized dispatch tree emitted " + std::to_string(leaf_count) + " leaves, expected 27");

    std::string result = spliceMarkedRegion(runtimeText, "-- KZ:GEN:DISPATCH:BEGIN", "-- KZ:GEN:DISPATCH:END", bst_code);

    // 6. Re-key the opcode mapping: permuted opcode -> internal state (not the
    //    logical opcode number), spliced between the OPMAP markers.
    std::ostringstream stateMapSs;
    stateMapSs << "        local _state_map = {";
    for (int op = 0; op < 27; ++op) {
        if (op) stateMapSs << ",";
        stateMapSs << "[" << op << "]=" << op_to_state[op];
    }
    stateMapSs << "}\n        for l_op = 0, 26 do\n            _oi[perm[l_op]] = _state_map[l_op]\n        end\n";
    result = spliceMarkedRegion(result, "-- KZ:GEN:OPMAP:BEGIN", "-- KZ:GEN:OPMAP:END", stateMapSs.str());

    // 7. Every arm body must survive into the final text (spot-check via each
    //    arm's distinctive first line content).
    for (int op = 0; op < 27; ++op) {
        const std::string& body = branches[op];
        size_t first_nl = body.find('\n');
        std::string first_line = body.substr(0, first_nl);
        if (first_line.size() > 6 && result.find(first_line) == std::string::npos)
            throw p2::Failure("E_RUNTIME_TRANSFORM: synthesized dispatcher lost arm body for op " + std::to_string(op));
    }

    return result;
}

// Generates genuinely-shaped dead helper routines (never invoked) so the
// helper-library skeleton of the runtime differs measurably across builds.
// Pure arithmetic on locals/params only: zero external dependencies, zero
// semantic effect (they are never called), fully syntax-validated downstream
// by the pinned-compiler output gate.
static std::string generateDecoyHelpers(std::mt19937_64& prng) {
    static const char* vpfx = "abcdefghkmnpqrstuvwxyz";
    auto rid = [&](const char* tag) {
        std::ostringstream s;
        s << tag << '_' << vpfx[prng() % 22] << std::hex << (0x100 + (prng() % 0xEFF));
        return s.str();
    };
    std::ostringstream out;
    int nfuncs = 2 + int(prng() % 4);
    for (int fi = 0; fi < nfuncs; ++fi) {
        std::string fn = rid("dz");
        std::string pa = rid("dx"), pb = rid("dy"), pc_ = rid("dw");
        out << "    local function " << fn << "(" << pa << "," << pb << ")\n";
        out << "        local " << pc_ << " = " << (prng() % 997) << "\n";
        int iters = 2 + int(prng() % 5);
        out << "        for _i = 1, " << iters << " do\n";
        out << "            " << pc_ << " = (" << pc_ << " * " << (3 + prng() % 13)
            << " + " << pa << ") % " << (97 + prng() % 900) << "\n";
        out << "        end\n";
        out << "        if " << pc_ << " < " << pa << " then " << pc_ << " = " << pc_ << " + " << pb << " end\n";
        out << "        return " << pc_ << "\n";
        out << "    end\n";
    }
    return out.str();
}

static std::string randomizeRuntimeSymbols(const std::string& runtimeText, uint64_t seed) {
    static const std::vector<std::string> symbols = {
        "_P0", "_G1", "_S2", "_M3", "_D4", "_V5",
        "_tp", "_tof", "_tn", "_er",
        "_pk", "_upk", "_cr", "_cl",
        "_rs", "_rg", "_re",
        "_bfs", "_rf64", "_bfc", "_ru8", "_wu8",
        "_ru16", "_ri16", "_ru32", "_ri32",
        "_bx", "_ba", "_br", "_bl",
        "_REF_KEY",
        "_bc", "_ref",
        "_HDR", "_KSPLIT", "_L32", "_hperm",
        "_slot_main", "_slot_s0", "_slot_s1", "_slot_chk",
        "_h0", "_hB", "_mo", "_sd", "_s0", "_s1", "_blended",
        "_stored_chk", "_calc_chk",
        "_DOM_CONST", "_DOM_STR", "_DOM_JUMP", "_DOM_PROTO", "_DOM_CLOSURE", "_DOM_TAMPER", "_DOM_OP", "_DOM_HDR",
        "_mix", "_mul32", "_kdf", "_stretch",
        "_lfisher", "_fisher", "_inv",
        "_ibop", "_icmp", "_iuop", "_icap", "_irt", "_ict",
        "_m32", "_m8", "_m32_cache", "_m8_cache", "_op_cache",
        "_oi", "_has_a",
        "_db", "_ds", "_str_cache", "_str_cap", "_str_n",
        "_opc_on",
        "_cc", "_nf",
        "_mk", "_proto_meta", "_proto_pids", "_decrypted_protos", "_mk_ctr",
        "_dspans", "_span_of", "_auth_word", "_find_span",
        "_rn", "_fr",
        "_ne",
        "_chk_invariants", "_cycles", "_profile_level",
        "_tamper_ctr", "_cp",
        "_cap", "_sc", "_rr",
        "_bmix", "_kdfb", "_cfg",
        "_am", "_am_cache",
        "_bc_len",
        "_t1", "_t2", "_ENV"
    };

    std::mt19937_64 prng(seed ^ 0x3C6EF372ULL);
    std::string result = runtimeText;

    const char prefixes[] = "abcdefghkmnpqrstuvwxyz";
    std::vector<std::pair<std::string, std::string>> replacements;
    std::set<std::string> used_ids;

    for (const auto& sym : symbols) {
        std::string id_str;
        do {
            char p = prefixes[prng() % (sizeof(prefixes) - 1)];
            uint32_t val = (prng() % 0xEFFF) + 0x1000;
            std::ostringstream id;
            id << p << '_' << std::hex << val;
            id_str = id.str();
        } while (used_ids.count(id_str));
        used_ids.insert(id_str);
        replacements.push_back({ sym, id_str });
    }

    std::sort(replacements.begin(), replacements.end(), [](const auto& a, const auto& b) {
        return a.first.size() > b.first.size();
    });

    int replaced = 0;
    for (const auto& rep : replacements) {
        std::regex symRegex("\\b" + rep.first + "\\b");
        if (!std::regex_search(result, symRegex)) {
            continue; // symbol legitimately absent (e.g. custom runtimes)
        }
        result = std::regex_replace(result, symRegex, rep.second);
        // Fail-hard validation: the original symbol must be fully eliminated
        // and the replacement must be present.
        if (std::regex_search(result, symRegex))
            throw p2::Failure("E_RUNTIME_TRANSFORM: symbol randomization left residual occurrences of " + rep.first);
        if (result.find(rep.second) == std::string::npos)
            throw p2::Failure("E_RUNTIME_TRANSFORM: symbol randomization failed to install replacement for " + rep.first);
        replaced++;
    }
    if (replaced < 40)
        throw p2::Failure("E_RUNTIME_TRANSFORM: suspiciously few symbols randomized (" + std::to_string(replaced) + ")");

    return result;
}

PolicyAuditReport runPipeline(const ObfuscationOptions& opts) {
    PolicyAuditReport report;
    report.targetFile = opts.inputPath;
    if (opts.seed != 0) {
        report.seedUsed = opts.seed;
        report.seedSource = "user";
    } else if (opts.reproducible) {
        report.seedUsed = 0x13528A1ULL;
        report.seedSource = "reproducible-fixed";
    } else {
        std::random_device rd;
        report.seedUsed = (uint64_t(rd()) << 32) | rd();
        if (report.seedUsed == 0) report.seedUsed = 0x13528A1ULL;
        report.seedSource = "std::random_device (OS entropy)";
    }

    // 1. Read input source
    std::string source = readFile(fs::u8path(opts.inputPath), 16 * 1024 * 1024);
    report.originalSizeBytes = source.size();

    // 2. Scan security policy & profile selection
    auto tokens = scanSensitiveTokens(source);
    report.detectedSensitiveTokens = tokens;
    report.containsSensitiveLogic = !tokens.empty();

    int profileMode = 1; // Default: Strong
    if (opts.profile == Profile::Balanced) {
        profileMode = 0;
        report.profileSelected = "Balanced";
    } else if (opts.profile == Profile::Maximum) {
        profileMode = 2;
        report.profileSelected = "Maximum";
    } else if (opts.profile == Profile::Native) {
        profileMode = 3;
        report.profileSelected = "Native";
    } else {
        profileMode = 1;
        report.profileSelected = "Strong";
    }

    // 3. Compile source with pinned Luau compiler
    Luau::CompileOptions compileOpts;
    compileOpts.optimizationLevel = opts.optLevel;
    compileOpts.debugLevel = opts.debugLevel;

    std::string bc = Luau::compile(source, compileOpts);
    if (bc.empty() || bc[0] == 0) {
        throw p2::Failure("E_COMPILE: " + (bc.empty() ? "empty compiler output" : bc.substr(1)));
    }

    // 4. Decode and lower to semantic register IR
    auto rawModule = p2::decode(bc);
    auto module = p2::lower(rawModule);
    report.functionCount = module.functions.size();

    for (const auto& fn : module.functions) {
        report.instructionCount += fn.code.size();
        for (const auto& node : fn.code) {
            report.opcodeDistribution[node.op]++;
        }
    }

    // 5. Select and configure runtime
    std::string runtimeText = opts.customRuntimePath.empty()
        ? std::string(BuiltinRuntime)
        : readFile(fs::u8path(opts.customRuntimePath), 2 * 1024 * 1024);

    // Apply concrete profile configuration to runtime
    std::regex profRegex(R"(local _profile_level\s*=\s*\d+)");
    runtimeText = std::regex_replace(runtimeText, profRegex, "local _profile_level = " + std::to_string(profileMode));

    // Per-build split key (F1 remediation follow-up): pipeline-embedded CLI
    // outputs carry the second key fragment in the runtime text while data-only
    // artifacts (raw template pairing) use the template contract of 0.
    uint32_t ksplit = 0;
    bool generateRuntime = opts.harden && !opts.dataOnly && profileMode != 3;
    if (generateRuntime) {
        std::mt19937_64 kr(report.seedUsed ^ 0x5EED5EED5EED5EEDULL);
        ksplit = uint32_t(kr());
        if (ksplit == 0) ksplit = 0x1D3A9B7u;

        runtimeText = injectSplitKey(runtimeText, ksplit);
        runtimeText = synthesizeBinarySearchDispatcher(runtimeText, report.seedUsed);
        {
            std::mt19937_64 dprng(report.seedUsed ^ 0xDEC0DEC0DEC0DEC0ULL);
            runtimeText = spliceMarkedRegion(runtimeText, "-- KZ:GEN:DECOYS:BEGIN", "-- KZ:GEN:DECOYS:END", generateDecoyHelpers(dprng));
        }
        runtimeText = randomizeRuntimeSymbols(runtimeText, report.seedUsed);

        report.transformations.push_back({"vm_dispatcher", "randomized_tree_state_permuted"});
        report.transformations.push_back({"vm_symbol_randomization", "applied (75+ identifiers, validated)"});
        report.transformations.push_back({"vm_split_key", "injected (buffer alone cannot derive working state)"});
        report.transformations.push_back({"vm_subdispatch_diversification", "bop/cmp/uop arm shuffle + randomized dispatch topology"});
        report.transformations.push_back({"vm_decoy_helpers", "2-5 dead routines (structure diversity)"});
    } else if (profileMode != 3) {
        report.transformations.push_back({"vm_dispatcher", opts.dataOnly ? "external (raw template contract)" : "linear_chain (hardening disabled)"});
        report.transformations.push_back({"vm_symbol_randomization", "off"});
        report.transformations.push_back({"vm_split_key", "none"});
    }

    // 6. Emit target output
    std::string outputText;
    if (profileMode == 3) { // Native pass-through
        std::ostringstream nativeOut;
        nativeOut << "return (function(...)\n" << source << "\nend)(...)\n";
        outputText = nativeOut.str();
        report.transformations.push_back({"vm_dispatcher", "native_passthrough"});
    } else {
        outputText = p2::emit(module, runtimeText, report.seedUsed, opts.dataOnly, profileMode, ksplit, &report.sensitiveStringCount);

        report.transformations.push_back({"header_layout", "32B permuted slots, L32-derived masks, checksum-authenticated"});
        report.transformations.push_back({"key_stretch_rounds", "1024"});
        report.transformations.push_back({"subopcode_permutation_spaces", "opcode(27) bop(9) cmp(8) uop(3) capture(3) reftag(5) consttag(9)"});
        if (profileMode == 2) {
            report.transformations.push_back({"op_cache_policy", "disabled (decode-per-dispatch)"});
            report.transformations.push_back({"string_cache_policy", "disabled (decode-per-use)"});
            report.transformations.push_back({"anti_tamper", "startup invariants + full-buffer checksum + ongoing authenticated sampling (pristine reference)"});
            report.transformations.push_back({"cfg_decoy_instructions", "injected"});
        } else if (profileMode == 0) {
            report.transformations.push_back({"op_cache_policy", "position-masked memoized"});
            report.transformations.push_back({"string_cache_policy", "bounded retention (cap 256) + sensitive no-retain"});
            report.transformations.push_back({"anti_tamper", "startup invariants + full-buffer checksum"});
        } else {
            report.transformations.push_back({"op_cache_policy", "position-masked memoized"});
            report.transformations.push_back({"string_cache_policy", "bounded retention (cap 512) + sensitive no-retain"});
            report.transformations.push_back({"anti_tamper", "startup invariants + full-buffer checksum"});
        }
        report.transformations.push_back({"sensitive_strings_no_retain", std::to_string(report.sensitiveStringCount)});
        report.transformations.push_back({"method_wrapper_table", "usage-scoped (invoked methods only; required for __namecall semantics)"});
    }

    report.transformations.push_back({"emitter_self_check", report.selfCheck});

    if (opts.minify) {
        outputText = minifyToOneLine(outputText);
    }

    // 7. Fail-hard syntax gate: every emitted artifact is re-parsed by the
    //    pinned Luau compiler before it is allowed to reach disk.
    if (std::getenv("KZ_DEBUG_PREGATE")) writeFile(fs::u8path(opts.outputPath + ".pregate"), outputText);
    {
        Luau::CompileOptions gateOpts;
        gateOpts.optimizationLevel = 0;
        gateOpts.debugLevel = 0;
        std::string gate = Luau::compile(outputText, gateOpts);
        if (gate.empty() || gate[0] == 0) {
            throw p2::Failure("E_OUTPUT_GATE: generated artifact failed Luau syntax verification: " + (gate.empty() ? std::string("empty") : gate.substr(1)));
        }
        report.transformations.push_back({"output_syntax_gate", "passed (pinned Luau re-parse)"});
    }

    report.outputSizeBytes = outputText.size();

    // 8. Write outputs
    writeFile(fs::u8path(opts.outputPath), outputText);
    if (!opts.irPath.empty()) writeFile(fs::u8path(opts.irPath), p2::toJson(module));
    if (!opts.bytecodePath.empty()) writeFile(fs::u8path(opts.bytecodePath), bc);

    if (!opts.reportPath.empty()) {
        writeFile(fs::u8path(opts.reportPath), exportReportJson(report));
    }

    return report;
}

std::string exportReportJson(const PolicyAuditReport& report) {
    std::ostringstream o;
    o << "{\n"
      << "  \"target\": \"" << report.targetFile << "\",\n"
      << "  \"profile\": \"" << report.profileSelected << "\",\n"
      << "  \"seed\": " << report.seedUsed << ",\n"
      << "  \"seed_source\": \"" << report.seedSource << "\",\n"
      << "  \"has_sensitive_logic\": " << (report.containsSensitiveLogic ? "true" : "false") << ",\n"
      << "  \"detected_tokens\": [";
    for (size_t i = 0; i < report.detectedSensitiveTokens.size(); ++i) {
        if (i) o << ", ";
        o << "\"" << report.detectedSensitiveTokens[i] << "\"";
    }
    o << "],\n"
      << "  \"original_bytes\": " << report.originalSizeBytes << ",\n"
      << "  \"output_bytes\": " << report.outputSizeBytes << ",\n"
      << "  \"functions\": " << report.functionCount << ",\n"
      << "  \"instructions\": " << report.instructionCount << ",\n"
      << "  \"sensitive_strings_no_retain\": " << report.sensitiveStringCount << ",\n"
      << "  \"self_check\": \"" << report.selfCheck << "\",\n"
      << "  \"compiler_pin\": \"" << CompilerPin << "\",\n"
      << "  \"transformations\": {";
    bool first = true;
    for (const auto& t : report.transformations) {
        if (!first) o << ",";
        first = false;
        o << "\n    " << p2::quoteJson(t.first) << ": " << p2::quoteJson(t.second);
    }
    o << "\n  }\n}\n";
    return o.str();
}

} // namespace p7
