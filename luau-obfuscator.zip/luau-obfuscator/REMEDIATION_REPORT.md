# KZ Luau Obfuscator — VM Architecture Remediation Report (v3.4.0)

**Scope.** Full source-level audit and remediation of the custom VM across
`src/pipeline.cpp`, `src/emit.cpp`, `src/lower.cpp`, `runtime/runtime.luau`, and
the security test suites, driven by two external review waves (the structured
F1–F10 / twelve-finding audit, and a line-by-line runtime review covering the
dispatch loop, caches, constant pool, and header). Luraph was used only as a
conceptual benchmark; no proprietary material was copied or assumed.

**Bottom line.** 24 defects confirmed and fixed (including 3 *latent
correctness* bugs the audits missed). The same input fixture now produces
artifacts whose dispatcher source shape, opcode space, sub-opcode space, header
layout, and KDF algorithm variant all differ per build; buffer-only static
recovery is measured at **0/20 builds**, while semantic equivalence to native
is **1,200/1,200 + 20/20 + 12/12** across every suite.

---

## 1. Confirmed defects and implemented fixes

Legend: **C** = correctness, **S** = static-analysis resistance, **T** = test
integrity, **D** = documentation/terminology.

### Wave-1 audit findings (F1–F12)

| # | Class | Defect (pre-fix location) | Fix (post-fix location) |
|---|---|---|---|
| F1 | S | Buffer header stored seed halves at fixed offsets with fixed XOR constants (`src/emit.cpp:518-519` v3.3) → seed recoverable from 8 header bytes; `tests/redteam_suite.py:49-65` shipped the attack | 32-byte permuted header: cleartext layout descriptor `L32` at slot 0; logical fields at L32-derived slots with L32-derived masks (`emit.cpp:607-620`); working state = `stretch(blended, 1024 rounds) ^ KSPLIT`, KSPLIT lives only in the runtime text (`runtime.luau:118,141`; emitted per build by `pipeline.cpp:216-220 injectSplitKey`). Buffer-only recovery measured impossible (0/20). Seed officially declared public, build-diversity-only (`docs/THREAT_MODEL.md`). |
| F2 | S | Opcode permutation renumbered opcodes but handlers stayed semantically fixed; canonical behavior map reusable across builds | Seven per-build permutation *spaces* (opcode 27, bop 9, cmp 8, uop 3, capture 3, reftag 5, consttag 9) inverted at runtime (`runtime.luau:262-273`); sub-op bytes additionally position-masked (`runtime.luau` op2/16/18 arms; `emit.cpp` masked writes). KDF itself varies per build via `cfg = ws & 3` (two constant families × extra diffusion round, `runtime.luau:147-167`, mirrored in `emit.cpp` `avalancheMixCfg`). |
| F3 | S/C | Dispatcher synthesis rewrote template text by exact-format regex and **silently returned the unhardened runtime** on 4 paths (`pipeline.cpp:251-254, 296, 312, 337` v3.3) | Marker-delimited structured generation with fail-hard `E_RUNTIME_TRANSFORM` throws (`pipeline.cpp:192 spliceMarkedRegion`, `343-456 synthesizeBinarySearchDispatcher`); symbol randomization now validated per-symbol with minimum-count assertion; new **output syntax gate** re-parses every artifact with the pinned compiler before writing (`pipeline.cpp` step 7). |
| F4 | S | `_op_cache[pc]` stored fully decoded opcode numbers for process lifetime (`runtime.luau` v3.3 dispatch) | Cache stores position-masked values (`_bx(h, mask)`, `runtime.luau:675`); Maximum profile disables the cache entirely (decode-per-dispatch). |
| F5 | S | `_str_cache` retained every decrypted inline string forever (`runtime.luau:149-170` v3.3) | Bounded cache (Balanced 256 / Strong 512, clear-on-full; Maximum 0 = decode-per-use) plus emitter-set sensitive flag (bit0) → never retained (`runtime.luau:191-235`; classifier `emit.cpp:211-230`). |
| F6 | S/C | Child prototypes decrypted in place into `_bc`; previous workaround also synced decryptions into `_ref`, destroying the reference (false-positive class on sampled tamper checks) | `_ref` pristine and never written; decrypted spans registered (`runtime.luau:440-441`); tamper samples authenticate decoded spans by keystream re-derivation (`_auth_word`, `runtime.luau:282-309`) and raw-compare elsewhere, with a strictly-correct partial-overlap rule (`_find_span`). `_mk` meta-cache hits in Maximum additionally re-verify one authenticated word per closure creation. |
| F7 | S | Anti-tamper = startup checks + sparse sampling of *encrypted* regions only; decoded regions unauthenticated (and false-abort prone) | Integrity model defined (`docs/THREAT_MODEL.md` §5): header decoy slots now checksum-authenticated (checksum covers every byte except the chk slot); decoded spans authenticated as above; documented residual: sampling is statistical, not a per-instruction MAC. |
| F8 | T | Red-team suite passed when extraction failed; dispatcher "similarity" was raw text diff; disassembler used a stale mask formula | `tests/redteam_suite.py` rewritten: every probe emits PASS / FAIL / INCONCLUSIVE / MEASURED with metrics; normalized AST-shape similarity; three independent buffer-only disassembly strategies; JSON report (`tests/redteam_out/redteam_report.json`). |
| F9 | D | "Cryptographically hardened" claims wrapped a custom KDF + LCG keystream | Terminology corrected everywhere (runtime comments, `--info`, docs). New explicit statement: encodings are keyed obfuscation; seed is public; `std::mt19937_64` diversity seeded from OS entropy. |
| F10 | T | No machine-readable proof that a profile activates its documented protections | `PolicyAuditReport.transformations` + extended `--report` JSON (dispatcher, split-key, header layout, cache policies, sensitive-string count, self-check, syntax gate); new `test_cli.py` stage 7 asserts the matrix per profile. |
| #9 (fixed serialization) | S | Fixed 16-byte header at offsets 0/4/8/12 | Permuted 32-byte header + decoy slots (above). Stable invariants documented (`docs/THREAT_MODEL.md` §7). |
| #10 (method wrappers) | S/C | Cleartext `["name"]=function(receiver,...) receiver:name(...)` table wholesale | **Attempted** elimination via dynamic `_M3` resolver → regression failure `method_receiver_once` proved `r[k](r,...)` breaks `__namecall` semantics. Wrappers restored but restricted to exactly the invoked method set (they always were); documented as necessary residual. |

### Wave-2 inline review findings (dispatch loop, caches, pools, header)

| # | Class | Defect | Fix |
|---|---|---|---|
| W1 | S | `_op_cache` values plaintext-describable post-dump | Covered by F4 masking; mask memo caches additionally never memoized at Maximum. |
| W2 | S | `bop` sub-operator byte raw in the bytestream | Per-build permutation **and** position mask (both layers). |
| W3 | S | Canonical opcode→behavior mapping static across builds | F2 permutation spaces + per-build KDF variant + per-build symbol randomization + randomized dispatcher topology (below). |
| W4 | S | No bounds check before opcode-byte read | Added `if pc >= _bc_len then _er("0x03", 0) end` to the decode block (single shared site). |
| W5 | D | Magic-number error taxonomy greppable | Accepted residual, documented; kept deliberately for debuggability. |
| W6 | C | Constant nonce `pid * 10000 + ki` → collision (two-time-pad) for protos with ≥10000 constants | Bit-packed nonce `(pid << 16) | ki` with hard bounds on both sides (`emit.cpp:212-218 makeConstNonce` throws `E_LIMIT`; runtime `_ba(_bl(_pid,16)+ki)`). Regression test asserts rejection. |
| W7 | C | `uint16_t len = uint16_t(str.size())` silently truncated strings ≥ 64 KB and desynced the whole stream | Compile-time `E_LIMIT` throw on strings/constants > 65535 bytes (`emit.cpp:299, 407`); py-tests stage 8 verifies a 70 KB literal fails loudly. |
| W8 | S | Register operand `a` transmitted raw → raw register dataflow | Operand mask with independent domain `DOM_OPERAND` (0xC2B2AE3D), position-keyed, memoized (`runtime.luau`, `emit.cpp:157, 481`). |
| W9 | S | `_m8_cache`/`_m32_cache` persistent mask tables | Maximum profile: no memoization (compute-per-use); Balanced/Strong: memoized, documented. |
| W10 | S | Numeric constants (f64) and vector components stored as raw IEEE-754 in buffer | Byte-exact stream encoding with the same keyed keystream (`emit.cpp:403, 429`; runtime decodes via `_db` → `readf64`). NaN/denormal/-0.0 round-trip is bit-exact because bytes — not values — are encoded. |
| W11 | S | String/constant length prefixes plaintext → length-oracle dictionary attack | Length prefixes position-masked (`emit.cpp:299-306`, `_ds`/`_mk` unmask with `kdf(·, ·, ·, 2) & 0xFFFF`). |
| W12 | S | Table-shape records (entry count + index pairs) completely raw | Masked entry count + stream-encoded index pairs (`emit.cpp:431-450`). |
| W13 | S | Dispatch mechanism fingerprint identical across builds (fixed balanced-BST shape) | Randomized tree: unbalanced pivots, flipped comparison directions (`if h <=` / `if h >`), occasional linear equality subchains; 2–5 dead decoy helper routines per build (`pipeline.cpp:227-281 buildDispatchTree`, `generateDecoyHelpers`). Dispatcher normalized similarity across builds dropped 97.0% → 61.8% (probe 3). |
| W14 | S | Anti-debug / live-frame introspection | Documented out-of-scope at VM level (white-box ceiling); engine-environment invariants retained. No theater added. |

### Defects found by *our own* remediation harness (neither audit caught these)

| # | Class | Defect | Fix |
|---|---|---|---|
| N1 | C | Constant-closure pool entries (tag 6) decoded with `DOM_JUMP` mask while the emitter patched them with `DOM_CLOSURE` — latent garbage offsets for any VM actually reading closure constants as values | Runtime tag 6 now uses `_DOM_CLOSURE` (`runtime.luau:502-504`). |
| N2 | C | Tamper sampling false-abort (`0x0A`) on 4-byte words *partially overlapping* decrypted proto spans — exposed when the working state changed the sampled offsets | Strict containment / partial-overlap rule in `_find_span`; Maximum profile verified clean over full 1,200-case suite. |
| N3 | C | Sensitive (no-retention) string constants used as table-shape keys crashed parse with `table index is nil` because shape construction reads pool entries at meta-build time | `_poolv` promotion: structurally-required sensitive strings decode into the shared pool at parse time; all others decode per-instantiation (`runtime.luau` `_mk`). Regression: `p1_pcall_nonstring_error` now 12/12. |

---

## 2. Validation results (before → after)

| Suite | Before (v3.3) | After (v3.4) |
|---|---|---|
| `test_cli.py` | 6 stages, 1,200/1,200 | **8 stages**, 1,200/1,200 + transformation-manifest matrix + marker fail-hard + 20-seed rtdecode round-trip vs IR ground truth + oversize-literal rejection + sensitive-flag checks |
| Semantic regression (`phase3 run_regression`) | 1,200/1,200 PASS | **1,200/1,200 PASS** (both standalone and binder/raw-template modes) |
| `differential_fuzz_suite.py` | 5/5 stages | 5/5 stages, **header mutation matrix enlarged to all 8 slots + decoy slots + body byte**; all abort with safe codes |
| `redteam_suite.py` | 5 boolean probes (v1; two misleading passes) | 7 measured probes: 6 PASS + 1 MEASURED ceiling, **0 FAIL** |
| Cross-build recovery (`recovery_harness.py`, 20 seeds) | n/a | **0/20** buffer-only recoverable; 20/20 distinct opcode perms; 20/20 distinct header layouts; 20/20 semantically bit-identical to native; logical stream invariant 3 protos / 53 instructions on every build |
| Dispatcher source similarity (identifier/number-normalized), pairwise | 97.0% mean (measured FAIL) | **61.8% mean**, range 53.9–75.2% (PASS, threshold 85%) |
| Buffer-only working-state recovery | 16-byte XOR = 3 ops | **impossible without runtime text** (checksum-authenticated candidates: 0 authenticate) |
| Full-artifact recovery (documented white-box ceiling) | ~40-line universal script | possible per build via `rtdecode` (ksplit disambiguated by checksum, ~4 candidates, 53/53 instructions in 9 ms Python) — **per-build, non-generic** |

Roblox Luau compatibility: all Roblox-mock fixtures (Instance hierarchy,
`FindFirstChild` chains, RemoteEvents with pcall guards, metatable and
`__namecall` semantics) execute bit-identically on the pinned Luau VM; nothing
in the runtime requires executor-only APIs.

## 3. Performance comparison (contextual benchmark suite, same harness)

| Metric | v3.3 (after S1–S6/P1–P5 tuning) | v3.4 (this remediation) | Delta |
|---|---|---|---|
| Output size, 613.1 KB source | 1.19 MB | **1.19 MB** (1,247,854 B) | flat (≤1.5 MB target ✓) |
| Per-frame CPU (game orchestration loop) | 0.0085 ms | **0.0103 ms** | +21% — still 99.9% headroom at 60/120 FPS |
| Steady-state per-call (Balanced) | 83.64 µs | **94.28 µs** | +12.7% (operand masks + KDF variant + retention policy) |
| Steady-state per-call (Strong) | 83.6 µs class | **94.39 µs** | +13% |
| Steady-state per-call (Maximum) | ~500 µs class | **1,384.87 µs** | intentionally expensive: decode-per-dispatch, no memoization, ongoing integrity — Maximum is the max-protection profile |
| Steady-state slowdown factor (Bal/Strong) | ~80x native | **~93x native** | acceptable for orchestration hot-path exclusion usage |
| Startup, 582 KB synthetic benchmark | 378.6 ms | **378.6 ms** (unmeasurable delta) | flat |

**Size/line constraint:** output remains a single line under `--minify`,
unchanged budgets (≤1.5 MB target / 2.0 MB max for ~570 KB inputs) hold:
613 KB → 1.19 MB.

## 4. Deliverables map

| Deliverable | Path |
|---|---|
| Source-level VM audit + defects + fixes + results | this file |
| Threat model & terminology | `docs/THREAT_MODEL.md` |
| Architecture spec (v3.4 section appended) | `docs/ARCHITECTURE.md` |
| Hardened runtime template | `runtime/runtime.luau` |
| Emitter | `src/emit.cpp` |
| Fail-hard pipeline & manifest | `src/pipeline.cpp`, `src/pipeline.hpp` |
| Red-team suite v2 (measured) | `tests/redteam_suite.py` → `tests/redteam_out/redteam_report.json` |
| 20-build recovery harness | `tests/recovery_harness.py` → `tests/recovery_out/recovery_report.{json,md}` |
| Independent format decoder | `tests/rtdecode.py` |
| Targeted regression probe | `tests/quick_regression_probe.py` |
| Extended CLI suite (8 stages) | `tests/test_cli.py` |
| Enlarged fuzz header matrix | `tests/differential_fuzz_suite.py` |

## 5. Remaining limitations and risks (honest register)

1. **White-box ceiling is unchanged by design.** Runtime + data coexist;
   `rtdecode` proves full-artifact recovery is possible per build. The bar
   reset by v3.4 is *generic, cheap, reuse-across-builds* extraction: header,
   split key, KDF variant, permutations, dispatcher topology, symbols, and
   decoy helpers all vary per build, so an analyst's scratchpad from build A
   does not transfer to build B.
2. **Integrity is statistical** at runtime (sampling + targeted re-verify), not
   a complete MAC of executed instructions. A per-instruction authenticated
   mode was considered and rejected: it conflicts with the performance mandate
   (it would multiply Maximum-profile cost again).
3. **`_KSPLIT` extraction is constant-scan + checksum-authentication** — raised
   from "read 16 bytes" to "parse runtime text, disambiguate candidates,
   validate" per build; an analyst with the full artifact still gets there.
4. **Method-name wrappers** remain visible in source for invoked methods
   (`__namecall` correctness). All other name-bearing surfaces (globals,
   locals, string constants, jump tables) are encoded.
5. **Live-frame introspection** (register arrays, upvalue boxes, decoded
   strings while executing) is out of scope for any interpreter VM.
6. **Error-code taxonomy** (`0x01`–`0x0D`) is stable by choice for
   debuggability; a reverse engineer gets a coarse VM structure map from it.
7. **Stretch round count and domain constants** are fixed; making the
   bootstrap-phase constants per-build is possible future work, bounded by the
   raw-template regression contract (the template must self-derive everything).
8. **`cfg` variant space is small** (4 variants). It exists to break
   decoder-reuse between builds, not to present large key-space. Expanding it
   (e.g., rotated-vs-multiplied first, domain tag permutation) is compatible
   future work — same dual-derivation pattern.

## 6. What was *not* done, and why

- **No junk-instruction padding for size.** Per the mandate, output size tracks
  content; decoy helpers exist solely for dispatcher-shape diversity (a few
  hundred bytes), not inflation.
- **No data-dependent masks.** The review correctly warns that masks depending
  on live register values silently corrupt loops/branches; all masks remain
  pure functions of compile-time-known position.
- **No anti-debug arms race.** Only environment invariant checks; documented.
