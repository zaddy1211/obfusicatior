# =============================================================================
# luau-obfuscate Windows Build Script (PowerShell)
# Phase 7 Production Release
# Pinned Compiler: 32c28089305f488f901aaf1dbf3fd1cb65fa3d11
# =============================================================================
[CmdletBinding()]
param(
    [string]$BuildType = "Release",
    [string]$Generator = "Visual Studio 17 2022",
    [string]$Architecture = "x64",
    [int]$Jobs = 4
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Definition
$RootDir = Split-Path -Parent $ScriptDir
$BuildDir = Join-Path $ScriptDir "build-win"
$BinDir = Join-Path $ScriptDir "bin"
$LuauSource = Join-Path $RootDir "upstream-v2\luau-lang--luau"

Write-Host "===============================================================================" -ForegroundColor Cyan
Write-Host " Building luau-obfuscate (Phase 7 Production Release) for Windows x64" -ForegroundColor Cyan
Write-Host "===============================================================================" -ForegroundColor Cyan

$CMakeCmd = Get-Command cmake -ErrorAction SilentlyContinue
if (-not $CMakeCmd) {
    Write-Error "cmake was not found in PATH. Please install CMake 3.16+ and retry."
    exit 1
}

if (-not (Test-Path (Join-Path $LuauSource "CMakeLists.txt"))) {
    Write-Error "Pinned Luau source tree not found at $LuauSource."
    exit 1
}

New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null
New-Item -ItemType Directory -Force -Path $BinDir | Out-Null

Write-Host "--> Configuring CMake in $BuildDir..." -ForegroundColor Yellow
& cmake -B $BuildDir -S $ScriptDir -G $Generator -A $Architecture "-DLUAU_SOURCE_DIR=$LuauSource"
if ($LASTEXITCODE -ne 0) {
    Write-Error "CMake configuration failed."
    exit $LASTEXITCODE
}

Write-Host "--> Building luau-obfuscate and luau-lab ($BuildType)..." -ForegroundColor Yellow
& cmake --build $BuildDir --config $BuildType --target luau-obfuscate luau-lab --parallel $Jobs
if ($LASTEXITCODE -ne 0) {
    Write-Error "Build failed."
    exit $LASTEXITCODE
}

$Candidates = @(
    (Join-Path $BuildDir "$BuildType\luau-obfuscate.exe"),
    (Join-Path $BuildDir "luau-obfuscate.exe")
)
$ExePath = $Candidates | Where-Object { Test-Path $_ } | Select-Object -First 1

if (-not $ExePath) {
    Write-Error "Could not locate compiled luau-obfuscate.exe in $BuildDir."
    exit 1
}

$LabCandidates = @(
    (Join-Path $BuildDir "$BuildType\luau-lab.exe"),
    (Join-Path $BuildDir "luau-lab.exe")
)
$LabPath = $LabCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1

$FinalExe = Join-Path $BinDir "luau-obfuscate.exe"
$FinalLab = Join-Path $BinDir "luau-lab.exe"
Copy-Item -Force -Path $ExePath -Destination $FinalExe
if ($LabPath) {
    Copy-Item -Force -Path $LabPath -Destination $FinalLab
}
Write-Host "--> Build complete!" -ForegroundColor Green
Write-Host "    Executable placed at: $FinalExe" -ForegroundColor Green
if ($LabPath) {
    Write-Host "    Lab runner placed at: $FinalLab" -ForegroundColor Green
}

Write-Host "--> Verifying executable info:" -ForegroundColor Cyan
& $FinalExe --info

Write-Host "===============================================================================" -ForegroundColor Cyan
