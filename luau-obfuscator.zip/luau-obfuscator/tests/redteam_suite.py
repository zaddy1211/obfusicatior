#!/usr/bin/env python3
"""
Red-Team Evaluation Suite v2 (post-audit remediation).

Every probe reports a structured result:
  status: PASS | FAIL | INCONCLUSIVE | MEASURED
  metrics: quantitative evidence

Design rules (fixing the weaknesses flagged in the external audit):
- A probe that cannot extract the expected structure reports INCONCLUSIVE, never PASS.
- Recovery attacks report measured recovery RATES, not boolean guesswork.
- Full-artifact recovery is reported as a MEASURED ceiling (it must succeed by
  construction), never silently mislabeled as a defense success or failure.
- The suite exits nonzero only on FAIL. INCONCLUSIVE/MEASURED are printed loudly.

Probes:
  1. Cleartext leakage scan (application constants, identifiers, seeds)
  2. Buffer-header seed-recovery attacks (legacy fixed recipe + v2 buffer-only)
  3. Cross-build structural/semantic diversity (opcode maps, normalized AST
     similarity of the generated dispatcher)
  4. Buffer-only static disassembly (multi-strategy instruction recovery rate)
  5. Retention & policy verification (sensitive flags, cache policy presence)
  6. Full-artifact ceiling measurement (time & recovery using rtdecode)
  7. Differential semantic correctness across fixtures/profiles
"""
import json
import re
import sys
import difflib
import struct
import subprocess
import time
from pathlib import Path

P7_DIR = Path(__file__).resolve().parent.parent
ROOT = P7_DIR.parent
BIN_CLI = P7_DIR / 'bin/luau-obfuscate'
BIN_LAB = P7_DIR / 'bin/luau-lab'
FIXTURES = P7_DIR / 'tests/fixtures'
OUT_DIR = P7_DIR / 'tests/redteam_out'
OUT_DIR.mkdir(parents=True, exist_ok=True)

sys.path.insert(0, str(P7_DIR / 'tests'))
import rtdecode  # noqa: E402

RESULTS = []

def record(probe, status, metrics, note=''):
    RESULTS.append({'probe': probe, 'status': status, 'metrics': metrics, 'note': note})
    tag = {'PASS': '[PASS]', 'FAIL': '[FAIL]', 'INCONCLUSIVE': '[INCONCLUSIVE]', 'MEASURED': '[MEASURED]'}[status]
    print(f"  {tag} {probe}: {note}")
    for k, v in metrics.items():
        print(f"         {k}: {v}")

def run_cmd(cmd):
    return subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

def build(fixture, out, seed, profile='strong', extra=()):
    c = [str(BIN_CLI), str(fixture), '-o', str(out), '--seed', str(seed), '--profile', profile, '--minify'] + list(extra)
    r = run_cmd(c)
    return r.returncode == 0

# ---------------------------------------------------------------------------
def probe_1_cleartext():
    print("\n--- [PROBE 1] Cleartext String & Identifier Leakage ---")
    fx = FIXTURES / 'fixture_strings_tables.luau'
    out = OUT_DIR / 'p1_strings.luau'
    build(fx, out, 12345)
    text = out.read_text(encoding='utf-8', errors='ignore')

    app_secrets = ['SUPER_SECRET_AUTHENTICATION_KEY_9921', 'api.roblox.internal']
    for s in re.findall(r'"([^"]{6,60})"', (FIXTURES / 'fixture_strings_tables.luau').read_text()):
        if len(s) >= 8 and not s.startswith('%'):
            app_secrets.append(s)
    leaks = [t for t in set(app_secrets) if t in text]
    if re.search(r'seed\s*=\s*\d+', text):
        leaks.append('visible_seed_assignment')

    fx2 = FIXTURES / 'fixture_roblox_mock.luau'
    out2 = OUT_DIR / 'p1_roblox.luau'
    build(fx2, out2, 54321)
    text2 = out2.read_text(encoding='utf-8', errors='ignore')
    roblox_leaks = [t for t in ['RemoteEvent', 'FindFirstChild'] if t in text2]

    # Method wrapper names (deliberate, usage-scoped residual for __namecall)
    wrappers = re.findall(r'\["([A-Za-z_][A-Za-z0-9_]*)"\]=function\(', text)
    status = 'FAIL' if (leaks or roblox_leaks) else 'PASS'
    record('cleartext_leakage', status, {
        'application_constant_leaks': leaks,
        'roblox_api_leaks_from_string_pool': roblox_leaks,
        'emitted_method_wrappers': wrappers,
        'wrapper_policy': 'usage-scoped; required for __namecall semantics (documented residual)'
    }, 'no application secrets in cleartext' if status == 'PASS' else 'cleartext leaks detected')

def probe_2_header_attacks():
    print("\n--- [PROBE 2] Build-Seed Recovery from Buffer Header ---")
    out = OUT_DIR / 'p2_seed.luau'
    build(FIXTURES / 'fixture_arithmetic.luau', out, 987654321, 'strong')
    text = out.read_text()
    bc = rtdecode.extract_buffer(text)
    if bc is None:
        record('header_seed_attacks', 'INCONCLUSIVE', {}, 'could not extract buffer from artifact')
        return

    # Attack A — legacy fixed-recipe (v1/v2 headers: XOR 0x5C3A9B17 @4 etc.)
    legacy_seed = None
    if len(bc) >= 16:
        h1 = struct.unpack('<I', bc[4:8])[0]
        h2 = struct.unpack('<I', bc[8:12])[0]
        legacy_seed = ((h1 ^ 0x5C3A9B17) ^ ((h2 ^ 0x6E4B2F83) ^ 0x9E3779B9)) & 0xFFFFFFFF
        ws_legacy = rtdecode.stretch(legacy_seed)
        hdr = rtdecode.HeaderV2(bc)
        legacy_ok = rtdecode.checksum(bc, ws_legacy, hdr.slot_chk) == hdr.stored_chk
    else:
        legacy_ok = False

    # Attack B — buffer-only v2-aware analyst (knows algorithm, no runtime text)
    ws_b, info_b = rtdecode.resolve_working_state(bc, None)

    real_blend = (987654321 & 0xFFFFFFFF) ^ (((987654321 >> 32) & 0xFFFFFFFF) ^ 0x9E3779B9)
    legacy_hit_real = legacy_seed == (real_blend & 0xFFFFFFFF)

    ok = (not legacy_ok) and (ws_b is None)
    record('header_seed_attacks', 'PASS' if ok else 'FAIL', {
        'legacy_fixed_recipe_authenticates': legacy_ok,
        'legacy_recipe_recovers_true_seed': legacy_hit_real,
        'buffer_only_working_state_recovered': ws_b is not None,
        'buffer_only_candidates_tried': info_b.get('candidates_tried'),
        'header_slot_layout': list(rtdecode.HeaderV2(bc).ok and [rtdecode.HeaderV2(bc).slot_main, rtdecode.HeaderV2(bc).slot_s0, rtdecode.HeaderV2(bc).slot_s1, rtdecode.HeaderV2(bc).slot_chk] or []),
    }, 'seed not recoverable from buffer alone at any effort level tested'
       if ok else 'buffer-alone seed recovery still possible')

def normalize_tokens(runtime_text):
    """Normalized token stream: identifiers and numerals folded; only structure
    and keyword/operator vocabulary retained (AST-shape proxy)."""
    t = re.sub(r'0x[0-9A-Fa-f]+|\b\d+(?:\.\d+)?\b', '#', runtime_text)
    t = re.sub(r'"[^"]*"', 'S', t)
    t = re.sub(r'\b[a-zA-Z_][a-zA-Z0-9_]*_[0-9a-f]{4}\b', 'V', t)  # randomized symbols
    t = re.sub(r'\b[a-z]_[0-9a-f]{4}\b', 'V', t)
    return t

def probe_3_diversity():
    print("\n--- [PROBE 3] Cross-Build Structural & Semantic Diversity ---")
    fx = FIXTURES / 'fixture_closures_varargs.luau'
    texts, perms, slotsets = [], [], []
    ok_builds = 0
    for i, seed in enumerate([101, 202, 303, 404, 505]):
        out = OUT_DIR / f'p3_build_{i}.luau'
        if build(fx, out, seed, 'strong'):
            ok_builds += 1
            t = out.read_text()
            texts.append(t)
            bc = rtdecode.extract_buffer(t)
            hdr = rtdecode.HeaderV2(bc)
            slotsets.append((hdr.slot_main, hdr.slot_s0, hdr.slot_s1, hdr.slot_s2 if hasattr(hdr, 'slot_s2') else 0, hdr.slot_chk))
            ws, info = rtdecode.resolve_working_state(bc, t)
            if ws is not None:
                perms.append(tuple(rtdecode.WS(ws).op_perm))
    if ok_builds < 2 or len(perms) < 2:
        record('cross_build_diversity', 'INCONCLUSIVE', {'builds': ok_builds}, 'insufficient builds recovered')
        return

    distinct_perms = len(set(perms))
    distinct_layouts = len(set(slotsets))
    norm = [normalize_tokens(t) for t in texts]
    sims = []
    for i in range(len(norm)):
        for j in range(i + 1, len(norm)):
            sims.append(difflib.SequenceMatcher(None, norm[i], norm[j]).ratio())
    mean_sim = sum(sims) / len(sims)

    status = 'PASS' if (distinct_perms == len(perms) and mean_sim < 0.85) else 'FAIL'
    record('cross_build_diversity', status, {
        'builds': len(perms),
        'distinct_opcode_permutations': distinct_perms,
        'distinct_header_layouts': distinct_layouts,
        'normalized_dispatcher_similarity_mean': round(mean_sim, 4),
        'threshold': 0.85,
    }, f'{distinct_perms}/{len(perms)} distinct opcode spaces; mean normalized similarity {mean_sim:.1%}')

def probe_4_static_disassembly():
    print("\n--- [PROBE 4] Buffer-Only Static Disassembly (multi-strategy) ---")
    out = OUT_DIR / 'p4_disasm.luau'
    build(FIXTURES / 'fixture_arithmetic.luau', out, 777, 'strong')
    text = out.read_text()
    bc = rtdecode.extract_buffer(text)
    if bc is None:
        record('static_disassembly', 'INCONCLUSIVE', {}, 'buffer extraction failed')
        return

    recovered_rate = 0.0
    strategies = {}

    # Strategy 1: legacy fixed-mask decode sweep (pre-remediation format)
    try:
        seed = None
        h1 = struct.unpack('<I', bc[4:8])[0]
        h2 = struct.unpack('<I', bc[8:12])[0]
        seed = ((h1 ^ 0x5C3A9B17) ^ ((h2 ^ 0x6E4B2F83) ^ 0x9E3779B9)) & 0xFFFFFFFF
        valid = sum(1 for i in range(32, min(len(bc), 400))
                    if ((bc[i] ^ (rtdecode.fold8(rtdecode.kdf_base(seed, rtdecode.DOM_OP, i, 1))))) < 27) / max(1, min(len(bc), 400) - 32)
        strategies['legacy_fixed_recipe_plausible_opcode_rate'] = round(valid, 4)
    except Exception as e:
        strategies['legacy_fixed_recipe'] = f'error: {e}'

    # Strategy 2: v2 header-aware, buffer-only working state (no ksplit knowledge)
    ws2, _ = rtdecode.resolve_working_state(bc, None)
    strategies['v2_header_buffer_only_state_recovered'] = ws2 is not None

    # Strategy 3: opcode-frequency guessing without any key material:
    # treat every byte < 27 as a candidate opcode, unmasked.
    plausible = sum(1 for b in bc[32:512] if b < 27) / max(1, min(len(bc) - 32, 480))
    strategies['unmasked_plausible_byte_rate'] = round(plausible, 4)

    recovered_rate = strategies.get('legacy_fixed_recipe_plausible_opcode_rate', 0.0)
    if ws2 is not None:
        recovered_rate = 1.0
    status = 'PASS' if (recovered_rate < 0.95 and ws2 is None) else 'FAIL'
    record('static_disassembly_buffer_only', status, strategies,
           'buffer alone yields no authenticated decode state' if status == 'PASS' else 'buffer-only decode succeeded')

def probe_5_retention_policies():
    print("\n--- [PROBE 5] Constant Retention & Cache Policy Verification ---")
    src = OUT_DIR / 'p5_src.luau'
    marker = 'SUPER_SECRET_LICENSE_TOKEN_' + 'X' * 48  # matches token + length rules
    src.write_text(f'local k = "{marker}"\nlocal t = {{ "prefix_" .. k }}\nprint(#t[1])\n')
    out = OUT_DIR / 'p5_out.luau'
    if not build(src, out, 24680, 'strong'):
        record('retention_policies', 'INCONCLUSIVE', {}, 'build failed')
        return
    text = out.read_text()
    bc = rtdecode.extract_buffer(text)
    ws, info = rtdecode.resolve_working_state(bc, text)
    if ws is None:
        # Maximum assurance about strings is already covered by buffer-only fail;
        # full-artifact parse unavailable => inconclusive for flag verification.
        record('retention_policies', 'INCONCLUSIVE', {}, 'could not authenticate working state')
        return
    hdr = info['header']
    wsv = rtdecode.WS(ws)
    wsv.main_off = hdr.main_off
    cache = {}
    pv = rtdecode.decode_proto_at(bc, hdr.main_off, wsv, cache)
    sens_flags = [c[2] for c in pv['consts'] if c[0] == 'str']
    plain = [c[1] for c in pv['consts'] if c[0] == 'str']
    # Compiler constant-folding may merge the marker into a longer constant;
    # match by substring against recovered constant content.
    marker_core = b'SUPER_SECRET_LICENSE_TOKEN'
    leaked = any(marker_core in p for p in plain)
    flags_set = sum(1 for f in sens_flags if f & 1)
    sens_plain_ok = any((f & 1) and (marker_core in c[1]) for f, c in zip(sens_flags, [c for c in pv['consts'] if c[0] == 'str']))
    b_rt = text
    record('retention_policies', 'PASS' if flags_set >= 1 and sens_plain_ok else 'FAIL', {
        'sensitive_constants_flagged': flags_set,
        'sensitive_marker_recovered_with_flag_under_full_artifact': sens_plain_ok,
        'string_constants_in_main_proto': len(sens_flags),
        'flag_bytes': sens_flags,
    }, f'{flags_set} sensitive constants carry no-retention flags; plaintext correct under authorized decode')

def probe_6_ceiling_measurement():
    print("\n--- [PROBE 6] Full-Artifact Recovery Ceiling (honest measurement) ---")
    out = OUT_DIR / 'p6_ceiling.luau'
    build(FIXTURES / 'fixture_closures_varargs.luau', out, 112233, 'maximum')
    t0 = time.perf_counter()
    r = rtdecode.full_recovery(out)
    dt = time.perf_counter() - t0
    if not r.get('ok'):
        record('full_artifact_ceiling', 'MEASURED', {'ok': False, 'reason': r.get('reason')},
               'full-artifact recovery unexpectedly blocked at working-state stage')
        return
    record('full_artifact_ceiling', 'MEASURED', {
        'prototypes_recovered': r['prototypes'],
        'instructions_recovered': r['instructions'],
        'strings_recovered': len(r['strings']),
        'ksplit_candidates_tried': r['candidates_tried'],
        'recovery_wall_seconds_python': round(dt, 3),
    }, 'white-box ceiling: runtime+data coexist so full recovery is possible; analysis cost is per-build and non-generic')

def probe_7_correctness():
    print("\n--- [PROBE 7] Differential Semantic Correctness ---")
    fixtures = sorted(FIXTURES.glob('*.luau'))
    passed, total = 0, 0
    mismatches = []
    for f in fixtures:
        expected = run_cmd([str(BIN_LAB), 'run', str(f)]).stdout.strip()
        for prof in ('strong', 'maximum', 'balanced'):
            total += 1
            out = OUT_DIR / f'p7_{f.stem}_{prof}.luau'
            build(f, out, 20261030, prof)
            p = run_cmd([str(BIN_LAB), 'run', str(out)])
            if p.returncode == 0 and p.stdout.strip() == expected:
                passed += 1
            else:
                mismatches.append(f'{f.stem}/{prof}')
    status = 'PASS' if passed == total else 'FAIL'
    record('differential_correctness', status, {
        'passed': passed, 'total': total, 'mismatches': mismatches
    }, f'{passed}/{total} fixture/profile executions bit-identical to native')

def main():
    print("=" * 72)
    print(" RED-TEAM VULNERABILITY & RECOVERY ASSESSMENT v2 (measured outcomes)")
    print("=" * 72)
    probe_1_cleartext()
    probe_2_header_attacks()
    probe_3_diversity()
    probe_4_static_disassembly()
    probe_5_retention_policies()
    probe_6_ceiling_measurement()
    probe_7_correctness()

    print("\n" + "=" * 72)
    print(" SUMMARY")
    print("=" * 72)
    failures = [r for r in RESULTS if r['status'] == 'FAIL']
    inconcl = [r for r in RESULTS if r['status'] == 'INCONCLUSIVE']
    for r in RESULTS:
        print(f"  {r['status']:<13} {r['probe']}")
    (OUT_DIR / 'redteam_report.json').write_text(json.dumps(RESULTS, indent=2))
    print(f"\nStructured report: {OUT_DIR / 'redteam_report.json'}")
    if inconcl:
        print(f"WARNING: {len(inconcl)} probe(s) INCONCLUSIVE (not counted as passes)")
    if failures:
        print(f"FAILURES: {len(failures)} probe(s) FAILED")
        sys.exit(1)
    print("No failures. (MEASURED probes report ceilings/honest recovery metrics.)")

if __name__ == '__main__':
    main()
