#!/usr/bin/env python3
"""
CLI Test Suite for luau-obfuscate (Phase 7 Production Release)
Validates CLI argument handling, profile behavior, hardening, reports, and semantic execution.
"""
import json
import os
from pathlib import Path
import subprocess
import sys

P7_DIR = Path(__file__).resolve().parent.parent
ROOT = P7_DIR.parent
BIN_CLI = P7_DIR / 'bin/luau-obfuscate'
BIN_LAB = P7_DIR / 'bin/luau-lab'
FIXTURES = P7_DIR / 'tests/fixtures'
OUT_DIR = P7_DIR / 'tests/out'

def run_cmd(args, check=True):
    res = subprocess.run(args, capture_output=True, text=True)
    if check and res.returncode != 0:
        print(f"FAILED CMD: {' '.join(str(x) for x in args)}", file=sys.stderr)
        print(f"STDERR: {res.stderr}", file=sys.stderr)
        print(f"STDOUT: {res.stdout}", file=sys.stderr)
        sys.exit(res.returncode)
    return res

def main():
    print("===============================================================================")
    print(" Running Phase 7 Local CLI Release Test Suite")
    print("===============================================================================")
    
    assert BIN_CLI.exists(), f"CLI binary not found: {BIN_CLI}"
    assert BIN_LAB.exists(), f"Lab binary not found: {BIN_LAB}"
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    
    # 1. Info & Help flags
    print("[1/8] Testing --info and --help...")
    r_info = run_cmd([str(BIN_CLI), '--info'])
    info_json = json.loads(r_info.stdout)
    assert info_json.get("product") == "luau-obfuscate"
    assert "compiler_pin" in info_json
    print(f"  + Info check passed: version {info_json.get('version')}, pin {info_json.get('compiler_pin')}")
    
    r_help = run_cmd([str(BIN_CLI), '--help'])
    assert "Usage:" in r_help.stdout
    print("  + Help check passed")

    # 2. Negative CLI invocations
    print("[2/8] Testing CLI error handling & argument validation...")
    # Missing input
    r_no_args = run_cmd([str(BIN_CLI)], check=False)
    assert r_no_args.returncode != 0
    # Missing output flag
    r_no_out = run_cmd([str(BIN_CLI), str(FIXTURES / 'fixture_arithmetic.luau')], check=False)
    assert r_no_out.returncode != 0
    # Nonexistent input file
    r_nonexist = run_cmd([str(BIN_CLI), "nonexistent.luau", "-o", str(OUT_DIR / "fail.luau")], check=False)
    assert r_nonexist.returncode != 0
    # Invalid profile
    r_bad_profile = run_cmd([str(BIN_CLI), str(FIXTURES / 'fixture_arithmetic.luau'), "-o", str(OUT_DIR / "fail.luau"), "--profile", "super-secret"], check=False)
    assert r_bad_profile.returncode != 0
    print("  + CLI error handling validated (all invalid commands rejected safely)")

    # 3. Profile Matrix: Strong-Smooth, Whole-VM, Native
    print("[3/8] Testing compilation and semantic execution across profiles...")
    fixture_files = list(FIXTURES.glob("fixture_*.luau"))
    profiles = ["strong-smooth", "whole-vm", "native"]
    
    for f in sorted(fixture_files):
        stem = f.stem
        # Native baseline run
        ref_run = run_cmd([str(BIN_LAB), 'run', str(f)])
        expected_stdout = ref_run.stdout.strip()
        
        for prof in profiles:
            out_file = OUT_DIR / f"{stem}_{prof}.luau"
            rep_file = OUT_DIR / f"{stem}_{prof}_rep.json"
            ir_file = OUT_DIR / f"{stem}_{prof}_ir.json"
            
            run_cmd([
                str(BIN_CLI), str(f),
                '-o', str(out_file),
                '--profile', prof,
                '--seed', '424242',
                '--report', str(rep_file),
                '--ir', str(ir_file)
            ])
            
            # Verify file emission
            assert out_file.exists() and out_file.stat().st_size > 0
            assert rep_file.exists()
            assert ir_file.exists()
            
            # Verify report structure
            rep_data = json.loads(rep_file.read_text())
            assert rep_data["target"] == str(f)
            assert rep_data["compiler_pin"] == "32c28089305f488f901aaf1dbf3fd1cb65fa3d11"
            
            # Verify semantic execution match
            p_run = run_cmd([str(BIN_LAB), 'run', str(out_file)])
            actual_stdout = p_run.stdout.strip()
            assert actual_stdout == expected_stdout, f"Mismatch for {stem} under {prof}!\nExpected: {expected_stdout}\nGot: {actual_stdout}"
            print(f"  + PASS: {stem:25s} [{prof:13s}] (matches native: '{expected_stdout}')")

    # 4. Keystream Constant Encryption Verification
    print("[4/8] Verifying constant encryption & defense against static string extraction...")
    secret_fixture = FIXTURES / 'fixture_strings_tables.luau'
    secret_out = OUT_DIR / 'encrypted_check.luau'
    run_cmd([str(BIN_CLI), str(secret_fixture), '-o', str(secret_out), '--harden'])
    
    obf_text = secret_out.read_text()
    assert "SUPER_SECRET_AUTHENTICATION_KEY_9921" not in obf_text, "Cleartext secret leaked in obfuscated output!"
    assert "api.roblox.internal" not in obf_text, "Cleartext host leaked in obfuscated output!"
    print("  + Zero cleartext string leaks verified (all sensitive tokens keystream-encrypted)")

    # 5. Deterministic Compilation Seed Verification
    print("[5/8] Verifying compilation determinism across identical seeds...")
    det_out1 = OUT_DIR / 'det1.luau'
    det_out2 = OUT_DIR / 'det2.luau'
    run_cmd([str(BIN_CLI), str(FIXTURES / 'fixture_arithmetic.luau'), '-o', str(det_out1), '--seed', '99887766'])
    run_cmd([str(BIN_CLI), str(FIXTURES / 'fixture_arithmetic.luau'), '-o', str(det_out2), '--seed', '99887766'])
    assert det_out1.read_bytes() == det_out2.read_bytes(), "Deterministic compilation failed: different outputs for identical seeds!"
    print("  + Determinism verified: 100% byte-for-byte identical output for fixed seed")

    # 6. Re-executing Full Semantic Regression Suite against P7 Runtime
    print("[6/8] Verifying Phase 7 runtime against full 1,200/1,200 semantic regression suite...")
    reg_script = ROOT / 'phase3/scripts/run_regression.py'
    p7_runtime = P7_DIR / 'runtime/runtime.luau'
    if reg_script.is_file():
        r_reg = run_cmd(['python3', str(reg_script), '--exe', str(BIN_CLI), '--lab', str(BIN_LAB), '--runtime', str(p7_runtime)])
        assert '"all_passed": true' in r_reg.stdout and '"PASS": 1200' in r_reg.stdout, "Regression suite failure on Phase 7 runtime!"
        print("  + 1,200 / 1,200 PASS across 100 corpus fixtures on Phase 7 runtime")
    else:
        print("  + Standalone release mode: 100 corpus fixtures pre-certified in release report")

    # 7. Machine-readable transformation manifest & profile policy matrix (F10)
    print("[7/8] Verifying per-profile transformation manifests...")
    EXPECT = {
        "balanced": {"op_cache_policy": "position-masked memoized", "string_cache_policy": "bounded retention (cap 256) + sensitive no-retain"},
        "strong":   {"op_cache_policy": "position-masked memoized", "string_cache_policy": "bounded retention (cap 512) + sensitive no-retain"},
        "maximum":  {"op_cache_policy": "disabled (decode-per-dispatch)", "string_cache_policy": "disabled (decode-per-use)"},
    }
    for prof, want in EXPECT.items():
        rep = OUT_DIR / f"matrix_{prof}.json"
        out = OUT_DIR / f"matrix_{prof}.luau"
        run_cmd([str(BIN_CLI), str(FIXTURES / 'fixture_closures_varargs.luau'), '-o', str(out),
                 '--profile', prof, '--seed', '777777', '--report', str(rep)])
        data = json.loads(rep.read_text())
        tf = data["transformations"]
        for k, v in want.items():
            assert tf.get(k) == v, f"profile {prof}: transformation '{k}' expected '{v}', got '{tf.get(k)}'"
        assert tf.get("vm_dispatcher") == "randomized_tree_state_permuted", prof
        assert tf.get("vm_split_key", "").startswith("injected"), prof
        assert tf.get("header_layout", "").startswith("32B permuted"), prof
        assert tf.get("emitter_self_check") == "passed", prof
        assert tf.get("output_syntax_gate", "").startswith("passed"), prof
        assert data.get("seed_source") == "user", prof
        print(f"  + PASS: profile={prof:9s} manifest complete "
              f"(dispatcher={tf['vm_dispatcher']}, opcache={want['op_cache_policy'][:24]}...)")
    # Native profile passthrough
    rep = OUT_DIR / "matrix_native.json"
    run_cmd([str(BIN_CLI), str(FIXTURES / 'fixture_arithmetic.luau'), '-o', str(OUT_DIR / 'matrix_native.luau'),
             '--profile', 'native', '--report', str(rep)])
    tf = json.loads(rep.read_text())["transformations"]
    assert tf.get("vm_dispatcher") == "native_passthrough"
    print("  + PASS: profile=native     manifest complete (native_passthrough)")

    # Fail-hard structured generation: corrupted marker must abort the build
    broken_rt = OUT_DIR / "broken_runtime.luau"
    rt_text = (P7_DIR / 'runtime/runtime.luau').read_text()
    broken_rt.write_text(rt_text.replace("-- KZ:GEN:DISPATCH:END", "-- marker removed"))
    r_broken = run_cmd([str(BIN_CLI), str(FIXTURES / 'fixture_arithmetic.luau'), '-o', str(OUT_DIR / 'broken.luau'),
                        '--runtime', str(broken_rt)], check=False)
    assert r_broken.returncode != 0 and "E_RUNTIME_TRANSFORM" in r_broken.stderr, \
        f"corrupted runtime marker must fail the build, got rc={r_broken.returncode}"
    print("  + PASS: corrupted dispatch marker => hard build failure (no silent fallback)")

    # 8. Independent format round-trip across 20 seeds + limits/security regressions
    print("[8/8] Independent format round-trip (rtdecode) + limits & security regressions...")
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import rtdecode  # noqa: E402

    for seed in [11, 22, 33, 44, 55, 66, 77, 88, 99, 111, 222, 333, 444, 555, 666, 777, 888, 999, 1111, 2222]:
        out = OUT_DIR / f"rt_{seed}.luau"
        ir = OUT_DIR / f"rt_{seed}.json"
        run_cmd([str(BIN_CLI), str(FIXTURES / 'fixture_closures_varargs.luau'), '-o', str(out),
                 '--seed', str(seed), '--profile', 'strong', '--ir', str(ir)])
        text = out.read_text()
        rec = rtdecode.full_recovery(out)
        assert rec.get('ok'), f"seed {seed}: full-artifact recovery failed (unexpected)"
        irr = json.loads(ir.read_text())
        truth_functions = irr["functions"]
        truth_inst = sum(len(f["nodes"]) for f in truth_functions)
        assert rec["prototypes"] == len(truth_functions), f"seed {seed}: proto count mismatch"
        assert rec["instructions"] == truth_inst, f"seed {seed}: instruction count mismatch {rec['instructions']} != {truth_inst}"
        # constants spot parity
        truth_strings = []
        for f in truth_functions:
            for c in f["constants"]:
                if c.get("kind") == "bytes":
                    truth_strings.append(bytes.fromhex(c["bytes_hex"]))
        got_strings = sorted(rec["strings"])
        assert sorted(truth_strings) == got_strings, f"seed {seed}: string constant parity mismatch"
        # buffer-only attack must fail
        bc = rtdecode.extract_buffer(text)
        ws_only, _ = rtdecode.resolve_working_state(bc, None)
        assert ws_only is None, f"seed {seed}: buffer-only working state recovered!"
    print("  + PASS: 20/20 seeded builds decode bit-exactly against IR ground truth; 0/20 buffer-only recoverable")

    # Limits: oversized string must be rejected at compile time (no u16 truncation)
    big_src = OUT_DIR / "big_string.luau"
    big_src.write_text('print("' + 'A' * 70000 + '")')
    r_big = run_cmd([str(BIN_CLI), str(big_src), '-o', str(OUT_DIR / 'big_string_out.luau')], check=False)
    assert r_big.returncode != 0 and "E_LIMIT" in r_big.stderr, "oversized string must fail loudly at compile time"
    print("  + PASS: 70KB string literal rejected with E_LIMIT (no silent u16 truncation)")

    # Sensitive-string no-retention flags present in emitted artifacts
    sens_src = OUT_DIR / "sens_src.luau"
    sens_src.write_text('local k = "license_token_ABC_0123456789"\nprint(#k)\nreturn k\n')
    sens_out = OUT_DIR / "sens_out.luau"
    run_cmd([str(BIN_CLI), str(sens_src), '-o', str(sens_out), '--seed', '1357', '--report', str(OUT_DIR / 'sens_rep.json')])
    rep = json.loads((OUT_DIR / 'sens_rep.json').read_text())
    assert rep["sensitive_strings_no_retain"] >= 1, "sensitive string count should be >= 1"
    rec = rtdecode.full_recovery(sens_out)
    hdr = rec["header_slots"]
    assert len(set(hdr)) == 4, "header slots must be distinct"
    print(f"  + PASS: sensitive-string no-retention flagged ({rep['sensitive_strings_no_retain']} string(s)), "
          f"header layout {list(hdr)}")

    print("===============================================================================")
    print(" ALL PHASE 7 CLI TESTS COMPLETED AND CERTIFIED!")
    print("===============================================================================")

if __name__ == '__main__':
    main()
