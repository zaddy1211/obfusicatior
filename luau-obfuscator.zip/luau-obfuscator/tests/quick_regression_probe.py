#!/usr/bin/env python3
"""Targeted regression probe: replicate run_regression.py binder/standalone
modes for individual fixtures without running the full 1,200-case matrix."""
import argparse, subprocess, sys
from pathlib import Path

P7 = Path(__file__).resolve().parent.parent
REPO = P7.parent
BIN_CLI = P7 / 'bin/luau-obfuscate'
BIN_LAB = P7 / 'bin/luau-lab'

PRELUDE = r'''
local function errorText(err)
 if type(err)=='table' then
  local out={}
  for k,v in pairs(err) do table.insert(out,tostring(k)..'='..tostring(v)) end
  table.sort(out);return 'table:{'..table.concat(out,',')..'}'
 end
 return tostring(err):gsub('^.-:%d+:%s*',''):gsub('\r',''):gsub('[\1-\31]','?')
end
'''

def luabytes(x: bytes) -> str:
    return '"' + ''.join('\\%03d' % b for b in x) + '"'

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('fixtures', nargs='+')
    ap.add_argument('--seeds', default='0,1,7,20261025')
    ap.add_argument('--opts', default='0,1,2')
    a = ap.parse_args()

    runtime = (P7 / 'runtime/runtime.luau').read_text()
    work = P7 / 'tests' / 'smoke'
    work.mkdir(exist_ok=True)

    total, failed = 0, 0
    for fx in a.fixtures:
        fxpath = Path(fx)
        if not fxpath.is_absolute():
            fxpath = (REPO / 'phase2/corpus/semantics' / fx).with_suffix('.luau') if not fx.endswith('.luau') else REPO / 'phase2/corpus/semantics' / fx
        native = subprocess.run([str(BIN_LAB), 'run', str(fxpath)], capture_output=True, text=True)
        native_fp = native.stdout.strip()
        for opt in a.opts.split(','):
            for seed in a.seeds.split(','):
                for mode in ('standalone', 'binder'):
                    total += 1
                    target = work / f'qr_{fxpath.stem}_O{opt}_S{seed}_{mode}.luau'
                    bc = work / f'qr_{fxpath.stem}_O{opt}_S{seed}_{mode}.luac'
                    cmd = [str(BIN_CLI), 'build', str(fxpath), '-o', str(target),
                           '--bytecode', str(bc), f'-O{opt}', '--seed', seed,
                           '--runtime', str(P7 / 'runtime/runtime.luau')]
                    if mode == 'binder':
                        cmd += ['--data-only']
                    r = subprocess.run(cmd, capture_output=True, text=True)
                    if r.returncode:
                        print(f'BUILD_ERROR {fxpath.stem} O{opt} S{seed} {mode}: {r.stderr.strip()}')
                        failed += 1
                        continue
                    source = target.read_text()
                    if mode == 'standalone':
                        body = 'local entry=function(...)\n' + source + '\nend\nlocal payload=entry();return table.pack(payload())'
                    else:
                        body = 'local bind=(function(...)\n' + source + '\nend)();local entry=bind(Runtime);local payload=entry();return table.pack(payload())'
                    parts = [PRELUDE]
                    if mode == 'binder':
                        parts += ['local Runtime=(function()\n', runtime, '\nend)()\n']
                    parts += ['local vmOk,vm=pcall(function()\n', body, '\nend)\n',
                              "if vmOk then print('VMROW ok') else print('VMROW ERR', errorText(vm)) end\n"]
                    wrapper = work / 'qr_job.luau'
                    wrapper.write_text(''.join(parts))
                    p = subprocess.run([str(BIN_LAB), 'run', str(wrapper), '1'], capture_output=True, text=True)
                    ok = 'VMROW ok' in p.stdout
                    if not ok:
                        failed += 1
                        print(f'VM_ERROR {fxpath.stem} O{opt} S{seed} {mode}: {p.stdout.strip()[-200:]}')
    print(f'\nPROBE: {total - failed}/{total} passed')
    sys.exit(1 if failed else 0)

if __name__ == '__main__':
    main()
