#!/usr/bin/env python3
"""
rtdecode.py — Independent reference implementation of the KZ VM wire format
(v3.4: permuted authenticated header, per-build KDF variants, position-masked
operands, encoded numerics/vectors/shapes, bit-packed constant nonces).

Used by redteam_suite.py / recovery_harness.py to MEASURE actual information
recovery. Full-artifact recovery is the documented white-box ceiling; the
meaningful bars are (a) buffer-only recoverability = 0 and (b) every payload
bit requiring the per-build working state.
"""
import re, struct
from pathlib import Path

DOM_CONST    = 0x6A09E667
DOM_STR      = 0xBB67AE85
DOM_JUMP     = 0x3C6EF372
DOM_PROTO    = 0xA54FF53A
DOM_CLOSURE  = 0x4A8F64D1
DOM_TAMPER   = 0x3956C25B
DOM_OP       = 0x7E7E9191
DOM_HDR      = 0x51A7E29D
DOM_OPERAND  = 0xC2B2AE3D
MASK32       = 0xFFFFFFFF

def mul32(a, b):
    al, ah = a & 0xFFFF, (a >> 16) & 0xFFFF
    bl, bh = b & 0xFFFF, (b >> 16) & 0xFFFF
    lo = al * bl
    mid = (al * bh + ah * bl) & 0xFFFF
    return (lo + mid * 65536) & MASK32

def mix_base(h):
    h &= MASK32
    h ^= (h >> 16)
    h = mul32(h, 0x85EBCA6B)
    h ^= (h >> 13)
    h = mul32(h, 0xC2B2AE35)
    h ^= (h >> 16)
    return h & MASK32

def mix_cfg(h, cfg):
    h &= MASK32
    h ^= (h >> 16)
    if cfg & 2:
        h = mul32(h, 0xCC9E2D51)
        h ^= (h >> 13)
        h = mul32(h, 0x1B873593)
    else:
        h = mul32(h, 0x85EBCA6B)
        h ^= (h >> 13)
        h = mul32(h, 0xC2B2AE35)
    h ^= (h >> 16)
    if cfg & 1:
        h ^= (h >> 11)
        h = mul32(h, 0x9E3779B1)
    return h & MASK32

def kdf_base(s, dom, nonce, ln):
    h = (s ^ dom) & MASK32
    n_term = (mul32(nonce & MASK32, 0x9E3779B9) + 0x510E527F) & MASK32
    h = mix_base(h ^ n_term)
    l_term = (mul32(ln & MASK32, 0x1B873593) + 0x27D4EB2F) & MASK32
    h = mix_base(h ^ l_term)
    return h

def kdf(s, dom, nonce, ln, cfg):
    h = (s ^ dom) & MASK32
    n_term = (mul32(nonce & MASK32, 0x9E3779B9) + 0x510E527F) & MASK32
    h = mix_cfg(h ^ n_term, cfg)
    l_term = (mul32(ln & MASK32, 0x1B873593) + 0x27D4EB2F) & MASK32
    h = mix_cfg(h ^ l_term, cfg)
    return h

def stretch(h):
    for _ in range(1024):
        h = mix_base((h + 0x9E3779B9) & MASK32)
    return h

def lcg_step(st):
    return (mul32(st, 1664525) + 1013904223) & MASK32

def lfisher(n, st):
    p = list(range(n))
    for i in range(n - 1, 0, -1):
        st = lcg_step(st)
        j = st % (i + 1)
        p[i], p[j] = p[j], p[i]
    return p

def inv(p):
    q = [0] * len(p)
    for i, v in enumerate(p):
        q[v] = i
    return q

def fold8(k):
    return (((k >> 24) ^ (k >> 16) ^ (k >> 8) ^ k) & 0xFF)

def const_nonce(pid, ki):
    return ((pid & 0xFFFF) << 16) | (ki & 0xFFFF)

def extract_buffer(text):
    prefix = 'bytecode=buffer.fromstring("'
    idx = text.find(prefix)
    if idx == -1:
        return None
    start = idx + len(prefix)
    i = start
    while True:
        q = text.find('"', i)
        if q == -1:
            return None
        bs = 0
        j = q - 1
        while j >= 0 and text[j] == '\\':
            bs += 1
            j -= 1
        if bs % 2 == 0:
            break
        i = q + 1
    raw = text[start:q]
    b = bytearray()
    i = 0
    while i < len(raw):
        c = raw[i]
        if c == '\\' and i + 1 < len(raw):
            nxt = raw[i + 1]
            if nxt == '\\':
                b.append(92); i += 2
            elif nxt == '"':
                b.append(34); i += 2
            elif nxt.isdigit():
                b.append(int(raw[i + 1:i + 4])); i += 4
            else:
                b.append(ord(nxt)); i += 2
        else:
            b.append(ord(c)); i += 1
    return bytes(b)

class HeaderV2:
    def __init__(self, bc):
        self.ok = False
        if bc is None or len(bc) < 32:
            self.reason = 'buffer shorter than 32-byte header'
            return
        self.l32 = struct.unpack('<I', bc[0:4])[0]
        hp = lfisher(7, kdf_base(self.l32, DOM_HDR, 77, 7))
        self.slot_main = (1 + hp[0]) * 4
        self.slot_s0 = (1 + hp[1]) * 4
        self.slot_s1 = (1 + hp[2]) * 4
        self.slot_chk = (1 + hp[3]) * 4
        self.main_off = struct.unpack('<I', bc[self.slot_main:self.slot_main + 4])[0] ^ kdf_base(self.l32, DOM_HDR, 10, 4)
        self.s0 = struct.unpack('<I', bc[self.slot_s0:self.slot_s0 + 4])[0] ^ kdf_base(self.l32, DOM_HDR, 11, 4)
        self.s1 = struct.unpack('<I', bc[self.slot_s1:self.slot_s1 + 4])[0] ^ kdf_base(self.l32, DOM_HDR, 12, 4)
        self.stored_chk = struct.unpack('<I', bc[self.slot_chk:self.slot_chk + 4])[0] ^ kdf_base(self.l32, DOM_HDR, 13, 4)
        self.blended = (self.s0 ^ (self.s1 ^ 0x9E3779B9)) & MASK32
        self.ok = True

def checksum(bc, ws, skip):
    h = ws
    for i in range(len(bc)):
        if skip <= i < skip + 4:
            continue
        h = ((h * 31 + bc[i]) & MASK32) ^ 0x5A827999
        h ^= (h >> 13)
        h = (h * 37 + 17) & MASK32
    return h & MASK32

def find_ksplit_candidates(artifact_text):
    cands = set()
    for m in re.finditer(r'local\s+[A-Za-z_][A-Za-z0-9_]*\s*=\s*0x([0-9A-Fa-f]{1,8})\b', artifact_text):
        cands.add(int(m.group(1), 16))
    return sorted(cands)

def resolve_working_state(bc, artifact_text=None):
    hdr = HeaderV2(bc)
    if not hdr.ok:
        return None, {'reason': hdr.reason}
    candidates = [0]
    if artifact_text is not None:
        candidates += find_ksplit_candidates(artifact_text)
    tried = 0
    for cand in candidates:
        ws = stretch(hdr.blended) ^ cand
        tried += 1
        if checksum(bc, ws, hdr.slot_chk) == hdr.stored_chk:
            return ws, {'ksplit': cand, 'candidates_tried': tried, 'header': hdr,
                        'mode': 'full' if cand else 'template'}
    return None, {'reason': 'no working-state candidate authenticated',
                  'candidates_tried': tried, 'header': hdr}

class WS:
    """Working-state-derived tables for one artifact."""
    def __init__(self, ws):
        self.ws = ws
        self.cfg = ws & 3
        self.op_perm = lfisher(27, kdf(ws, DOM_OP, 0, 27, self.cfg))
        self.oi = inv(self.op_perm)
        self.ibop = inv(lfisher(9, kdf(ws, DOM_OP, 101, 9, self.cfg)))
        self.icmp = inv(lfisher(8, kdf(ws, DOM_OP, 102, 8, self.cfg)))
        self.iuop = inv(lfisher(3, kdf(ws, DOM_OP, 103, 3, self.cfg)))
        self.icap = inv(lfisher(3, kdf(ws, DOM_OP, 104, 3, self.cfg)))
        self.irt = inv(lfisher(5, kdf(ws, DOM_OP, 105, 5, self.cfg)))
        self.ict = inv(lfisher(9, kdf(ws, DOM_OP, 106, 9, self.cfg)))

    def m8(self, pc):
        k = kdf(self.ws, DOM_OP, pc, 1, self.cfg)
        return fold8(k)

    def am(self, pc):
        k = kdf(self.ws, DOM_OPERAND, pc, 1, self.cfg)
        return fold8(k)

    def decode_bytes(self, data, domain, nonce):
        ln = len(data)
        state = kdf(self.ws, domain, nonce, ln, self.cfg)
        out = bytearray()
        for i in range(ln):
            state = lcg_step(state)
            sk = mix_cfg(state ^ ((i * 0x9E3779B9) & MASK32), self.cfg)
            out.append(data[i] ^ fold8(sk))
        return bytes(out)

def decode_proto_at(bc_full, proto_off, wsv, cache):
    ws = wsv.ws
    view = cache.setdefault('view', bytearray(bc_full))
    if proto_off != wsv.main_off:
        slice_len = struct.unpack('<I', bytes(view[proto_off:proto_off + 4]))[0] ^ kdf(ws, DOM_JUMP, proto_off, 4, wsv.cfg)
        pid = struct.unpack('<H', bytes(view[proto_off + 4:proto_off + 6]))[0] ^ (kdf(ws, DOM_JUMP, proto_off + 4, 4, wsv.cfg) & 0xFFFF)
        # in-place decrypt for the image view
        st = kdf(ws, DOM_PROTO, pid, slice_len, wsv.cfg)
        for i in range(slice_len):
            st = lcg_step(st)
            view[proto_off + 6 + i] ^= fold8(st)
    else:
        slice_len = struct.unpack('<I', bytes(view[proto_off:proto_off + 4]))[0]
        pid = struct.unpack('<H', bytes(view[proto_off + 4:proto_off + 6]))[0]

    base = proto_off + 6
    slots, params = view[base], view[base + 1]
    vararg, uv = view[base + 2], view[base + 3]
    kcnt = struct.unpack('<H', bytes(view[base + 4:base + 6]))[0]
    cur = base + 6
    consts = []
    for ki in range(kcnt):
        nonce = const_nonce(pid, ki)
        tag = wsv.ict[view[cur]]; cur += 1
        if tag == 0:
            consts.append(('nil', None))
        elif tag == 1:
            consts.append(('bool', view[cur] == 1)); cur += 1
        elif tag == 2:
            raw = bytes(view[cur:cur + 8]); cur += 8
            dec = wsv.decode_bytes(raw, DOM_CONST, nonce)
            consts.append(('num', struct.unpack('<d', dec)[0]))
        elif tag == 3:
            fl = view[cur]; cur += 1
            slen = struct.unpack('<H', bytes(view[cur:cur + 2]))[0] ^ (kdf(ws, DOM_CONST, nonce, 2, wsv.cfg) & 0xFFFF)
            cur += 2
            raw = bytes(view[cur:cur + slen]); cur += slen
            consts.append(('str', wsv.decode_bytes(raw, DOM_CONST, nonce), fl))
        elif tag == 6:
            child_off = struct.unpack('<I', bytes(view[cur:cur + 4]))[0] ^ kdf(ws, DOM_CLOSURE, cur, 4, wsv.cfg); cur += 4
            consts.append(('closure', child_off))
        elif tag == 7:
            raw = bytes(view[cur:cur + 24]); cur += 24
            dec = wsv.decode_bytes(raw, DOM_CONST, nonce)
            consts.append(('vec', struct.unpack('<ddd', dec)))
        elif tag == 8:
            ecnt = struct.unpack('<H', bytes(view[cur:cur + 2]))[0] ^ (kdf(ws, DOM_CONST, nonce, 2, wsv.cfg) & 0xFFFF)
            cur += 2
            raw = bytes(view[cur:cur + 4 * ecnt]); cur += 4 * ecnt
            dec = wsv.decode_bytes(raw, DOM_CONST, (nonce + 32768) & MASK32)
            entries = []
            for e in range(ecnt):
                kidx, vidx = struct.unpack('<Hh', dec[e * 4:e * 4 + 4])
                entries.append((kidx, vidx))
            consts.append(('shape', entries))
        else:
            raise ValueError(f'bad const tag {tag} at {cur}')
    code_start = cur
    return {'pid': pid, 'slots': slots, 'params': params, 'vararg': vararg,
            'upvalues': uv, 'consts': consts, 'code_start': code_start,
            'slice_len': slice_len, 'proto_off': proto_off}

OPS_WITH_A = {1,2,3,4,5,6,7,8,9,10,11,12,13,17,18,19,20,21,22,23,24,26}
OP_NAMES = {0:'Noop',1:'Assign',2:'Binary',3:'GlobalRead',4:'GlobalWrite',5:'UpvalueRead',
            6:'UpvalueWrite',7:'CloseCells',8:'IndexRead',9:'IndexWrite',10:'Closure',
            11:'PrepareMethod',12:'Invoke',13:'Return',14:'Jump',15:'BranchTruth',
            16:'BranchCompare',17:'Concat',18:'Unary',19:'NewTable',20:'CloneTable',
            21:'WriteList',22:'NumericInit',23:'NumericAdvance',24:'Iterate',
            25:'IterationBoundary',26:'Varargs'}

def walk_instructions(view, code_start, proto_end, wsv, protos=None):
    pc = code_start
    out = []
    while pc < proto_end:
        raw_op = view[pc]
        op = wsv.oi[raw_op ^ wsv.m8(pc)] if (raw_op ^ wsv.m8(pc)) < 27 else None
        if op is None:
            out.append((pc, 'INVALID', raw_op))
            break
        start_pc = pc
        pc += 1
        a = None
        if op in OPS_WITH_A:
            a = view[pc] ^ wsv.am(pc)
            pc += 1
        def rd_ref(p):
            tag = wsv.irt[view[p]]
            return p + {0: 2, 1: 3, 2: 9, 3: 1, 4: 2}[tag]
        if op == 1:
            pc = rd_ref(pc)
        elif op == 2:
            pc = rd_ref(pc); pc = rd_ref(pc); pc += 1
        elif op in (3, 4):
            ln = struct.unpack('<H', bytes(view[pc + 1:pc + 3]))[0] ^ (kdf(wsv.ws, DOM_STR, pc, 2, wsv.cfg) & 0xFFFF)
            pc += 3 + ln
        elif op in (5, 6):
            pc += 1
        elif op == 7:
            pass
        elif op in (8, 9):
            pc = rd_ref(pc); pc = rd_ref(pc)
        elif op == 10:
            child = struct.unpack('<I', bytes(view[pc:pc + 4]))[0] ^ kdf(wsv.ws, DOM_CLOSURE, pc, 4, wsv.cfg)
            pc += 4
            pc += 2
            n_caps = view[pc]; pc += 1 + 2 * n_caps
            if protos is not None and 32 <= child < len(view):
                protos.append(child)
        elif op == 11:
            pc = rd_ref(pc)
            ln = struct.unpack('<H', bytes(view[pc + 1:pc + 3]))[0] ^ (kdf(wsv.ws, DOM_STR, pc, 2, wsv.cfg) & 0xFFFF)
            pc += 3 + ln
        elif op == 12:
            pc += 4
        elif op == 13:
            pc += 2
        elif op == 14:
            pc += 4
        elif op == 15:
            pc = rd_ref(pc); pc += 5
        elif op == 16:
            pc = rd_ref(pc); pc = rd_ref(pc); pc += 5
        elif op == 17:
            pc += 2
        elif op == 18:
            pc = rd_ref(pc); pc += 1
        elif op == 19:
            pc += 8
        elif op == 20:
            pc += 2
        elif op == 21:
            pc += 5
        elif op in (22, 23):
            pc += 4
        elif op == 24:
            pc += 13
        elif op == 25:
            pass
        elif op == 26:
            pc += 2
        out.append((start_pc, OP_NAMES[op], a))
        if op == 13:
            break
    return out

def full_recovery(artifact_path):
    """Ceiling attack: full-artifact devirtualization. Returns metrics dict."""
    text = Path(artifact_path).read_text(encoding='utf-8', errors='ignore')
    bc = extract_buffer(text)
    if bc is None:
        return {'ok': False, 'reason': 'buffer not found'}
    ws, info = resolve_working_state(bc, text)
    if ws is None:
        return {'ok': False, **info}
    hdr = info['header']
    wsv = WS(ws)
    wsv.main_off = hdr.main_off
    cache = {}
    pending = [hdr.main_off]
    visited = set()
    total_inst = 0
    protos = 0
    strings = []
    while pending:
        p = pending.pop()
        if p in visited or p >= len(bc):
            continue
        visited.add(p)
        pv = decode_proto_at(bc, p, wsv, cache)
        view = cache['view']
        proto_end = pv['proto_off'] + 6 + pv['slice_len']
        insts = walk_instructions(view, pv['code_start'], proto_end, wsv, protos=pending)
        total_inst += len(insts)
        protos += 1
        for c in pv['consts']:
            if c[0] == 'str':
                strings.append(c[1])
    return {'ok': True, 'ws': ws, 'cfg': wsv.cfg, 'mode': info['mode'], 'ksplit': info['ksplit'],
            'candidates_tried': info['candidates_tried'],
            'prototypes': protos, 'instructions': total_inst,
            'strings': strings, 'header_slots': (hdr.slot_main, hdr.slot_s0, hdr.slot_s1, hdr.slot_chk),
            'op_perm': wsv.op_perm}

if __name__ == '__main__':
    import sys, json
    r = full_recovery(sys.argv[1])
    r['strings'] = [len(s) for s in r.get('strings', [])]
    print(json.dumps({k: v for k, v in r.items() if k != 'op_perm'}, indent=2, default=str))
