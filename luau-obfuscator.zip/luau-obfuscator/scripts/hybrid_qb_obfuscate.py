#!/usr/bin/env python3
"""
hybrid_qb_obfuscate.py
Automated pipeline for hybrid Luau obfuscation:
  - Leaves high-frequency math/solver routines (e.g. QBSolve.lua) in native Luau with basic obfuscation
    (hex-encoded string literals, mangled internal identifiers, comment stripping, 1-line minification)
    so it runs with 100% native C++ SIMD speed and zero VM overhead.
  - Virtualizes the entire rest of the script inside the custom VM with Balanced BST dispatching,
    dynamic Fisher-Yates opcode permutation, and 32-bit KDF constant encryption.
  - Emits an exact 1-line minified production deliverable satisfying all Roblox runtime constraints.
"""

import argparse
import os
import re
import subprocess
import sys
from pathlib import Path

def strip_comments(src: str) -> str:
    out = []
    i = 0
    n = len(src)
    in_str = None
    while i < n:
        if in_str:
            if src[i] == '\\':
                out.append(src[i:i+2])
                i += 2
                continue
            elif src[i] == in_str:
                out.append(src[i])
                in_str = None
                i += 1
                continue
            else:
                out.append(src[i])
                i += 1
                continue
        if src[i] in ('"', "'"):
            in_str = src[i]
            out.append(src[i])
            i += 1
            continue
        if src[i:i+4] == '--[[':
            end_c = src.find(']]', i+4)
            if end_c != -1:
                i = end_c + 2
                continue
            else:
                break
        if src[i:i+2] == '--':
            end_nl = src.find('\n', i+2)
            if end_nl != -1:
                i = end_nl
                continue
            else:
                break
        out.append(src[i])
        i += 1
    return ''.join(out)

def obfuscate_strings(src: str) -> str:
    out = []
    i = 0
    n = len(src)
    while i < n:
        if src[i] in ('"', "'"):
            q = src[i]
            end_q = i + 1
            while end_q < n:
                if src[end_q] == '\\':
                    end_q += 2
                elif src[end_q] == q:
                    break
                else:
                    end_q += 1
            raw_content = src[i+1:end_q]
            hex_str = '"' + ''.join(f'\\x{ord(c):02x}' for c in raw_content.encode('utf-8').decode('latin-1')) + '"'
            out.append(hex_str)
            i = end_q + 1
            continue
        else:
            out.append(src[i])
            i += 1
    return ''.join(out)

def basic_obfuscate_qb(code: str) -> str:
    code = strip_comments(code)
    code = obfuscate_strings(code)
    rename_map = {
        'finite': '_0xf1',
        'bounded': '_0xb2',
        'unitOr': '_0xu3',
        'addRoot': '_0xr4',
        'polynomial': '_0xp5',
        'polynomialRoots': '_0xr6',
        'mappedSpeed': '_0xs7',
        'mappedCommand': '_0xc8',
        'fitAngleFor': '_0xa9',
        'powerForAngle': '_0xpA',
        'smartFit': '_0xsF',
    }
    for old_name, new_name in rename_map.items():
        code = re.sub(r'\b' + old_name + r'\b', new_name, code)
    
    lines_min = [l.strip() for l in code.splitlines() if l.strip()]
    return ' '.join(lines_min)

def main():
    parser = argparse.ArgumentParser(description="Hybrid VM + Native Luau Obfuscator")
    parser.add_argument('input', help='Input script path (e.g. KZ_QBA_Fixed.txt)')
    parser.add_argument('-o', '--output', required=True, help='Output obfuscated script path')
    parser.add_argument('--binary', default=None, help='Path to luau-obfuscate executable')
    parser.add_argument('--profile', default='balanced', choices=['balanced', 'strong', 'maximum'])
    args = parser.parse_args()

    input_path = Path(args.input).resolve()
    output_path = Path(args.output).resolve()

    if not input_path.exists():
        print(f"Error: Input file {input_path} not found.", file=sys.stderr)
        sys.exit(1)

    bin_path = args.binary
    if not bin_path:
        search_paths = [
            Path(__file__).resolve().parents[1] / 'bin' / 'luau-obfuscate',
            Path('/home/user/luau-obfuscator-research/phase7/bin/luau-obfuscate'),
            Path('./bin/luau-obfuscate')
        ]
        for p in search_paths:
            if p.exists() and os.access(p, os.X_OK):
                bin_path = str(p)
                break
    
    if not bin_path or not os.path.exists(bin_path):
        print("Error: luau-obfuscate binary not found. Specify via --binary.", file=sys.stderr)
        sys.exit(1)

    print(f"[*] Reading input script: {input_path} ({input_path.stat().st_size:,} bytes)")
    lines = open(input_path, 'r', encoding='utf-8', errors='ignore').readlines()

    # Find QBSolve boundaries
    start_idx, end_idx = None, None
    for idx, l in enumerate(lines):
        if '__kzModC["games/ff3/src/engine/QBSolve.lua"]' in l and '(function()' in l:
            start_idx = idx
            break

    if start_idx is not None:
        for idx in range(start_idx, min(start_idx + 2500, len(lines))):
            if 'return M' in lines[idx] and idx + 1 < len(lines) and 'end)()' in lines[idx + 1]:
                end_idx = idx + 1
                break

    if start_idx is not None and end_idx is not None:
        print(f"[*] Detected QBSolve.lua at lines {start_idx + 1}..{end_idx + 1}")
        qb_raw = ''.join(lines[start_idx + 1 : end_idx])
        print(f"[*] Applying basic native obfuscation to QBSolve ({len(qb_raw):,} chars)...")
        one_line_qb = basic_obfuscate_qb(qb_raw)
        native_qb_stmt = f'local __native_qb = (function(){one_line_qb} end); '

        # Prepare virtual input
        virt_lines = (
            ['local __KZ_QBSOLVE = ...\n'] +
            lines[:start_idx] +
            ['\t__kzModC["games/ff3/src/engine/QBSolve.lua"] = __KZ_QBSOLVE()\n'] +
            lines[end_idx + 1:]
        )
        virt_code = ''.join(virt_lines)
    else:
        print("[*] No distinct QBSolve module detected; proceeding with whole-script virtualization.")
        native_qb_stmt = ''
        virt_code = ''.join(lines)

    tmp_in = output_path.with_suffix('.tmp_in.luau')
    tmp_out = output_path.with_suffix('.tmp_out.luau')
    tmp_in.write_text(virt_code, encoding='utf-8')

    print(f"[*] Virtualizing script via {bin_path} (--profile {args.profile} --minify)...")
    cmd = [bin_path, str(tmp_in), '-o', str(tmp_out), '--profile', args.profile, '--minify']
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        print("Error in obfuscator:", res.stderr, file=sys.stderr)
        tmp_in.unlink(missing_ok=True)
        tmp_out.unlink(missing_ok=True)
        sys.exit(res.returncode)

    virt_obf = tmp_out.read_text(encoding='utf-8').strip()
    tmp_in.unlink(missing_ok=True)
    tmp_out.unlink(missing_ok=True)

    if native_qb_stmt:
        if virt_obf.endswith('(...)') or virt_obf.endswith('(...)\n'):
            if virt_obf.endswith('(...)\n'):
                vm_stmt = virt_obf[:-6] + '(__native_qb, ...)'
            else:
                vm_stmt = virt_obf[:-5] + '(__native_qb, ...)'
        else:
            vm_stmt = virt_obf
        final_code = native_qb_stmt + vm_stmt
    else:
        final_code = virt_obf

    final_code = final_code.replace('\r', '').replace('\n', ' ')
    output_path.write_text(final_code, encoding='utf-8')

    print(f"[+] Success! Obfuscated script written to: {output_path}")
    print(f"    Size: {output_path.stat().st_size:,} bytes ({round(output_path.stat().st_size / 1024 / 1024, 2)} MB)")
    print(f"    Lines: {len(open(output_path).readlines())} (single continuous line)")

if __name__ == '__main__':
    main()
