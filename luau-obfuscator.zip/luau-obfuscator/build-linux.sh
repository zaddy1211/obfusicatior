#!/usr/bin/env bash
# =============================================================================
# luau-obfuscate Linux Build Script
# Phase 7 Production Release
# Pinned Compiler: 32c28089305f488f901aaf1dbf3fd1cb65fa3d11
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "${SCRIPT_DIR}")"
BUILD_DIR="${SCRIPT_DIR}/build"
BIN_DIR="${SCRIPT_DIR}/bin"
LUAU_SOURCE="${ROOT_DIR}/upstream-v2/luau-lang--luau"

echo "==============================================================================="
echo " Building luau-obfuscate (Phase 7 Production Release) for Linux x86_64"
echo "==============================================================================="

if ! command -v cmake &> /dev/null; then
    echo "ERROR: cmake is not installed or not in PATH." >&2
    exit 1
fi

if ! command -v g++ &> /dev/null && ! command -v clang++ &> /dev/null; then
    echo "ERROR: C++17 compiler (g++ or clang++) not found." >&2
    exit 1
fi

if [ ! -f "${LUAU_SOURCE}/CMakeLists.txt" ]; then
    echo "ERROR: Pinned Luau source tree not found at ${LUAU_SOURCE}" >&2
    exit 1
fi

mkdir -p "${BUILD_DIR}"
mkdir -p "${BIN_DIR}"

echo "--> Configuring CMake in ${BUILD_DIR}..."
cmake -B "${BUILD_DIR}" -S "${SCRIPT_DIR}" \
    -DCMAKE_BUILD_TYPE=Release \
    -DLUAU_SOURCE_DIR="${LUAU_SOURCE}"

echo "--> Compiling Release binary..."
cmake --build "${BUILD_DIR}" --config Release --target luau-obfuscate luau-lab -j"$(nproc || echo 4)"

cp "${BUILD_DIR}/luau-obfuscate" "${BIN_DIR}/luau-obfuscate"
cp "${BUILD_DIR}/luau-lab" "${BIN_DIR}/luau-lab"
chmod +x "${BIN_DIR}/luau-obfuscate" "${BIN_DIR}/luau-lab"

echo "--> Build successful!"
echo "    Executable installed: ${BIN_DIR}/luau-obfuscate"
echo "    Lab runner installed: ${BIN_DIR}/luau-lab"
echo "    Version check:"
"${BIN_DIR}/luau-obfuscate" --info
echo "==============================================================================="
